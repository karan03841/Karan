#!/usr/bin/env bash
# Run this from the pendrive to start the Portable CTF (v2 - 58 challenges).
#
# Prefers your system's Python if it already has Flask (common on Kali via
# `sudo apt install python3-flask`, or if you've used Flask before) -- that
# way it works with ZERO internet, every time, forever.
# Only falls back to creating a venv + pip-installing Flask (which needs
# internet ONE TIME, the very first run only) if Flask isn't already there.
set -e

cd "$(dirname "$0")"

PYBIN=""
if python3 -c "import flask" 2>/dev/null; then
    echo "[*] System Python already has Flask -- using it directly (no internet needed)."
    PYBIN="python3"
else
    if [ ! -d "venv" ]; then
        echo "[*] Flask not found on system Python."
        echo "[*] First run: creating a virtual environment on the pendrive (needs internet this one time)..."
        python3 -m venv venv
        ./venv/bin/pip install --upgrade pip >/dev/null
        if ! ./venv/bin/pip install -r requirements.txt; then
            echo ""
            echo "[!] Could not install Flask -- no internet connection available right now."
            echo "[!] Either connect to the internet once and re-run this script, or run:"
            echo "    sudo apt install python3-flask"
            echo "    on this machine (uses apt's offline cache / local mirror if you have one), then re-run."
            exit 1
        fi
    fi
    PYBIN="./venv/bin/python3"
fi

if [ ! -f "ctf.db" ]; then
    echo "[*] Creating challenge database (58 challenges)..."
    "$PYBIN" init_db.py
fi

NET_PIDS=()
cleanup() {
    echo ""
    echo "[*] Stopping network challenge services..."
    for pid in "${NET_PIDS[@]}"; do
        kill "$pid" 2>/dev/null || true
    done
}
trap cleanup EXIT INT TERM

echo "[*] Starting network challenge services (nc-solvable, ids 57-58)..."
chmod +x challenges/net57 challenges/net58 2>/dev/null || true
"$PYBIN" services/tcp_bridge.py 9101 "$(pwd)/challenges/net57" > /tmp/portablectf_net57.log 2>&1 &
NET_PIDS+=($!)
"$PYBIN" services/tcp_bridge.py 9102 "$(pwd)/challenges/net58" > /tmp/portablectf_net58.log 2>&1 &
NET_PIDS+=($!)
sleep 1
echo "    -> nc 127.0.0.1 9101   (Remote Access Gate)"
echo "    -> nc 127.0.0.1 9102   (Remote Overflow)"

echo "[*] Starting Practice Lab netcat service (non-scored)..."
chmod +x practice_files/tool-netcat/practice_banner_service 2>/dev/null || true
"$PYBIN" services/tcp_bridge.py 9103 "$(pwd)/practice_files/tool-netcat/practice_banner_service" > /tmp/portablectf_practice_nc.log 2>&1 &
NET_PIDS+=($!)
sleep 1
echo "    -> nc 127.0.0.1 9103   (Practice Lab: nc tool lab)"

echo "[*] Starting PortableCTF v2..."
echo "[*] Open this in your browser: http://127.0.0.1:5000"
"$PYBIN" app.py
