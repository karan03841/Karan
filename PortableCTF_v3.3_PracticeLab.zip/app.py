import sqlite3
import hashlib
import os
from datetime import datetime
from flask import Flask, render_template, request, send_from_directory, redirect, url_for, flash, abort

from practice_data import MODULES as PRACTICE_MODULES, TOOLS_ARSENAL

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ctf.db")
CHAL_DIR = os.path.join(BASE_DIR, "challenges")
PRACTICE_DIR = os.path.join(BASE_DIR, "practice_files")
PRACTICE_BY_SLUG = {m["slug"]: m for m in PRACTICE_MODULES}

app = Flask(__name__)
app.secret_key = "karan-portable-ctf-v3-local-only"

CATEGORIES = ["Reverse Engineering", "Binary Exploitation", "Cryptography", "Forensics", "Network"]
# Progressive unlock order within a category: Easy challenges are always open;
# all Easy in a category must be solved before Medium unlocks; all Medium before Hard.
DIFF_ORDER = ["Easy", "Medium", "Hard"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def flag_hash(flag):
    return hashlib.sha256(flag.strip().encode()).hexdigest()


def stage_progress(conn, chal_ids=None):
    """Returns {chal_id: solved_stage_count} from stage_solves."""
    rows = conn.execute("SELECT challenge_id, COUNT(*) AS n FROM stage_solves GROUP BY challenge_id").fetchall()
    return {r["challenge_id"]: r["n"] for r in rows}


def fully_solved_ids(challenges, progress):
    """A challenge counts as solved only once every one of its stages is solved."""
    return {c["id"] for c in challenges if progress.get(c["id"], 0) >= c["stage_count"]}


def compute_locks(challenges, solved_ids):
    """Returns {chal_id: True/False} -- True means LOCKED (not yet accessible)."""
    by_cat = {}
    for c in challenges:
        by_cat.setdefault(c["category"], {}).setdefault(c["difficulty"], []).append(c)

    locked = {}
    for cat, by_diff in by_cat.items():
        prev_tier_all_solved = True
        for tier in DIFF_ORDER:
            tier_chals = by_diff.get(tier, [])
            for c in tier_chals:
                locked[c["id"]] = not prev_tier_all_solved
            if tier_chals:
                prev_tier_all_solved = all(c["id"] in solved_ids for c in tier_chals)
    return locked


def effective_points(chal, stage_points_earned, solved_ids, hinted_ids):
    """stage_points_earned: points already earned from solved stages of this challenge."""
    pts = stage_points_earned
    if chal["id"] in solved_ids and chal["id"] in hinted_ids:
        pts -= chal["hint_cost"]
    return max(pts, 0)


def stage_points_sum(conn, chal_id, solved_stage_indexes):
    if not solved_stage_indexes:
        return 0
    qmarks = ",".join("?" * len(solved_stage_indexes))
    row = conn.execute(
        f"SELECT COALESCE(SUM(points),0) AS s FROM subflags WHERE challenge_id = ? AND stage_index IN ({qmarks})",
        (chal_id, *solved_stage_indexes),
    ).fetchone()
    return row["s"]


@app.route("/")
def index():
    conn = get_db()
    challenges = conn.execute("SELECT * FROM challenges ORDER BY id").fetchall()
    progress = stage_progress(conn)
    hinted_rows = conn.execute("SELECT challenge_id FROM hints_used").fetchall()
    hinted_ids = {r["challenge_id"] for r in hinted_rows}
    solved_ids = fully_solved_ids(challenges, progress)
    locked = compute_locks(challenges, solved_ids)

    # earned points per challenge = sum of points of its solved stages, minus hint cost once fully solved
    stage_pts_rows = conn.execute(
        "SELECT ss.challenge_id AS cid, COALESCE(SUM(sf.points),0) AS pts "
        "FROM stage_solves ss JOIN subflags sf "
        "  ON sf.challenge_id = ss.challenge_id AND sf.stage_index = ss.stage_index "
        "GROUP BY ss.challenge_id"
    ).fetchall()
    stage_pts_map = {r["cid"]: r["pts"] for r in stage_pts_rows}
    conn.close()

    total_points = sum(c["points"] for c in challenges)
    earned_points = sum(
        effective_points(c, stage_pts_map.get(c["id"], 0), solved_ids, hinted_ids) for c in challenges
    )

    by_category = {}
    for c in challenges:
        by_category.setdefault(c["category"], []).append(c)

    cat_progress = {}
    for cat, chals in by_category.items():
        done = sum(1 for c in chals if c["id"] in solved_ids)
        cat_progress[cat] = (done, len(chals))

    return render_template(
        "index.html",
        by_category=by_category,
        categories=CATEGORIES,
        cat_progress=cat_progress,
        solved_ids=solved_ids,
        progress=progress,
        locked=locked,
        total_points=total_points,
        earned_points=earned_points,
        total_chals=len(challenges),
        solved_count=len(solved_ids),
    )


@app.route("/chal/<int:chal_id>")
def challenge(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    if chal is None:
        conn.close()
        return "Challenge not found", 404

    all_chals = conn.execute("SELECT * FROM challenges").fetchall()
    progress = stage_progress(conn)
    solved_ids = fully_solved_ids(all_chals, progress)
    locked = compute_locks(all_chals, solved_ids)

    if locked.get(chal_id):
        conn.close()
        flash("That challenge is locked. Solve the easier challenges in this category first.", "error")
        return redirect(url_for("index"))

    # track first view time (for time-to-solve stats), ignore if already recorded
    conn.execute(
        "INSERT OR IGNORE INTO views (challenge_id, first_viewed_at) VALUES (?, datetime('now','localtime'))",
        (chal_id,),
    )
    conn.commit()

    stages = conn.execute(
        "SELECT * FROM subflags WHERE challenge_id = ? ORDER BY stage_index", (chal_id,)
    ).fetchall()
    solved_stage_rows = conn.execute(
        "SELECT stage_index FROM stage_solves WHERE challenge_id = ?", (chal_id,)
    ).fetchall()
    solved_stage_set = {r["stage_index"] for r in solved_stage_rows}

    solved = chal_id in solved_ids
    hinted = conn.execute("SELECT 1 FROM hints_used WHERE challenge_id = ?", (chal_id,)).fetchone()
    conn.close()
    return render_template(
        "challenge.html",
        chal=chal,
        stages=stages,
        solved_stage_set=solved_stage_set,
        solved=solved,
        hinted=bool(hinted),
    )


@app.route("/hint/<int:chal_id>", methods=["POST"])
def reveal_hint(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    if chal is None:
        conn.close()
        return "Challenge not found", 404
    conn.execute(
        "INSERT OR IGNORE INTO hints_used (challenge_id, used_at) VALUES (?, datetime('now','localtime'))",
        (chal_id,),
    )
    conn.commit()
    conn.close()
    flash(f"Hint revealed. -{chal['hint_cost']} points once you fully solve this challenge.", "info")
    return redirect(url_for("challenge", chal_id=chal_id))


@app.route("/files/<int:chal_id>")
def download_file(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    conn.close()
    if chal is None:
        return "Challenge not found", 404
    return send_from_directory(CHAL_DIR, chal["filename"], as_attachment=True)


@app.route("/submit/<int:chal_id>/<int:stage_index>", methods=["POST"])
def submit(chal_id, stage_index):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    if chal is None:
        conn.close()
        return "Challenge not found", 404

    sub = conn.execute(
        "SELECT * FROM subflags WHERE challenge_id = ? AND stage_index = ?", (chal_id, stage_index)
    ).fetchone()
    if sub is None:
        conn.close()
        return "Stage not found", 404

    already = conn.execute(
        "SELECT 1 FROM stage_solves WHERE challenge_id = ? AND stage_index = ?", (chal_id, stage_index)
    ).fetchone()
    if already:
        flash(f"Stage {stage_index} already solved.", "info")
        conn.close()
        return redirect(url_for("challenge", chal_id=chal_id))

    submitted = request.form.get("flag", "")
    if flag_hash(submitted) == sub["flag_hash"]:
        conn.execute(
            "INSERT INTO stage_solves (challenge_id, stage_index, solved_at) VALUES (?, ?, datetime('now','localtime'))",
            (chal_id, stage_index),
        )
        conn.commit()

        solved_count = conn.execute(
            "SELECT COUNT(*) AS n FROM stage_solves WHERE challenge_id = ?", (chal_id,)
        ).fetchone()["n"]
        if solved_count >= chal["stage_count"]:
            hinted = conn.execute("SELECT 1 FROM hints_used WHERE challenge_id = ?", (chal_id,)).fetchone()
            total_pts = conn.execute(
                "SELECT COALESCE(SUM(points),0) AS s FROM subflags WHERE challenge_id = ?", (chal_id,)
            ).fetchone()["s"]
            final_pts = max(total_pts - (chal["hint_cost"] if hinted else 0), 0)
            flash(f"Correct! Stage {stage_index}/{chal['stage_count']} done -- challenge fully solved! +{final_pts} total points.", "success")
        else:
            flash(f"Correct! Stage {stage_index}/{chal['stage_count']} done. +{sub['points']} points so far.", "success")
    else:
        flash(f"Wrong flag for stage {stage_index}. Try again.", "error")
    conn.close()
    return redirect(url_for("challenge", chal_id=chal_id))


@app.route("/scoreboard")
def scoreboard():
    conn = get_db()
    challenges = conn.execute("SELECT * FROM challenges ORDER BY category, id").fetchall()
    progress = stage_progress(conn)
    solved_ids = fully_solved_ids(challenges, progress)
    hinted_rows = conn.execute("SELECT challenge_id FROM hints_used").fetchall()
    hinted_ids = {r["challenge_id"] for r in hinted_rows}
    view_rows = conn.execute("SELECT challenge_id, first_viewed_at FROM views").fetchall()
    viewed_map = {r["challenge_id"]: r["first_viewed_at"] for r in view_rows}

    # last stage-solve timestamp per challenge = when it became fully solved
    last_solve_rows = conn.execute(
        "SELECT challenge_id, MAX(solved_at) AS last_at FROM stage_solves GROUP BY challenge_id"
    ).fetchall()
    last_solve_map = {r["challenge_id"]: r["last_at"] for r in last_solve_rows}

    stage_pts_rows = conn.execute(
        "SELECT ss.challenge_id AS cid, COALESCE(SUM(sf.points),0) AS pts "
        "FROM stage_solves ss JOIN subflags sf "
        "  ON sf.challenge_id = ss.challenge_id AND sf.stage_index = ss.stage_index "
        "GROUP BY ss.challenge_id"
    ).fetchall()
    stage_pts_map = {r["cid"]: r["pts"] for r in stage_pts_rows}
    conn.close()

    total_points = sum(c["points"] for c in challenges)
    earned_points = sum(
        effective_points(c, stage_pts_map.get(c["id"], 0), solved_ids, hinted_ids) for c in challenges
    )

    # time-to-solve per category (minutes), only counting challenges FULLY solved
    FMT = "%Y-%m-%d %H:%M:%S"
    cat_times = {}
    for c in challenges:
        cid = c["id"]
        if cid in solved_ids and cid in viewed_map and cid in last_solve_map:
            try:
                t0 = datetime.strptime(viewed_map[cid], FMT)
                t1 = datetime.strptime(last_solve_map[cid], FMT)
                mins = max((t1 - t0).total_seconds() / 60.0, 0)
                cat_times.setdefault(c["category"], []).append(mins)
            except Exception:
                pass
    cat_avg_time = {cat: (sum(v) / len(v)) for cat, v in cat_times.items() if v}

    return render_template(
        "scoreboard.html",
        challenges=challenges,
        solved_ids=solved_ids,
        progress=progress,
        hinted_ids=hinted_ids,
        stage_pts_map=stage_pts_map,
        last_solve_map=last_solve_map,
        total_points=total_points,
        earned_points=earned_points,
        cat_avg_time=cat_avg_time,
    )


@app.route("/practice")
def practice_index():
    tool_labs = sorted([m for m in PRACTICE_MODULES if m["kind"] == "tool"], key=lambda m: m["order"])
    attack_labs = sorted([m for m in PRACTICE_MODULES if m["kind"] == "attack"], key=lambda m: m["order"])
    return render_template("practice_index.html", tool_labs=tool_labs, attack_labs=attack_labs, arsenal=TOOLS_ARSENAL)


@app.route("/practice/<slug>")
def practice_detail(slug):
    mod = PRACTICE_BY_SLUG.get(slug)
    if mod is None:
        abort(404)
    same_kind = sorted([m for m in PRACTICE_MODULES if m["kind"] == mod["kind"]], key=lambda m: m["order"])
    idx = same_kind.index(mod)
    prev_mod = same_kind[idx - 1] if idx > 0 else None
    next_mod = same_kind[idx + 1] if idx < len(same_kind) - 1 else None
    return render_template("practice_detail.html", mod=mod, prev_mod=prev_mod, next_mod=next_mod)


@app.route("/practice/files/<slug>/<path:filename>")
def practice_download(slug, filename):
    mod = PRACTICE_BY_SLUG.get(slug)
    if mod is None or filename not in mod["files"]:
        abort(404)
    folder = os.path.join(PRACTICE_DIR, slug)
    return send_from_directory(folder, filename, as_attachment=True)


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        print("No database found. Run init_db.py first (start_ctf.sh does this automatically).")
    app.run(host="127.0.0.1", port=5000, debug=False)
