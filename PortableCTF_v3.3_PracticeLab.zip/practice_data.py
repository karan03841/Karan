# -*- coding: utf-8 -*-
"""Practice Lab content -- v2: fully atomic. ONE tool or ONE technique per
lab, each deep on its own, instead of several tools bundled into one
level. No DB, no flags, no scoring -- every "reveal" is plain client-side
<details>, so it works 100% offline. kind="tool" or kind="attack".
Folder for each lab's files == its own slug under practice_files/<slug>/."""

TOOL_LABS = [
    dict(
        slug="tool-file", kind="tool", order=1, difficulty="Easy", color="cat0",
        title="file", tagline="The very first command to run on anything unknown.",
        tools=["file"],
        tutorial=[
            ("What it actually does",
             "<code>file</code> reads the first few bytes of a file (its \"magic number\") and tells "
             "you its real type -- regardless of extension, or even with NO extension at all. It "
             "never trusts a filename."),
            ("Exact syntax",
             "<code>file &lt;filename&gt;</code> for one file, <code>file *</code> for every file in "
             "the current directory at once. Add <code>-z</code> to also look inside common "
             "compressed formats."),
        ],
        task=(
            "Run <code>file</code> on all four files in this lab. For each one, write down (even just "
            "mentally) what <code>file</code> told you: architecture/bit-ness for the ELF binary, "
            "encoding for the text file, archive type for the zip, and what it says (or doesn't say) "
            "about the mystery <code>.bin</code> file."
        ),
        commands=["file password_checker_stripped message_reversed_bytes.txt password_protected_notes.zip embedded_archive_scan_target.bin"],
        hints=[
            "An ELF binary's `file` output tells you 32 vs 64-bit, dynamically/statically linked, and "
            "whether it's stripped -- all without opening anything else yet.",
            "A password-protected zip is still correctly identified as a Zip archive by `file` -- it "
            "just can't tell you the password. The mystery .bin file will likely just say \"data\" -- "
            "that's `file`'s honest way of saying \"I don't recognize a clean signature here\", which "
            "is exactly when you reach for binwalk next.",
        ],
        answer=(
            "password_checker_stripped: ELF 64-bit LSB executable, dynamically linked, stripped. "
            "message_reversed_bytes.txt: ASCII text. password_protected_notes.zip: Zip archive data. "
            "embedded_archive_scan_target.bin: data (no single clean signature at the very start -- "
            "correct, since the real zip signature is buried partway through it)."
        ),
        files=["password_checker_stripped", "message_reversed_bytes.txt", "password_protected_notes.zip", "embedded_archive_scan_target.bin"],
    ),
    dict(
        slug="tool-strings", kind="tool", order=2, difficulty="Easy", color="cat0",
        title="strings", tagline="Pull every human-readable fragment out of a binary.",
        tools=["strings"],
        tutorial=[
            ("What it does and why it works on stripped binaries",
             "<code>strings</code> scans a file for runs of printable characters of a minimum length "
             "and prints them. Stripping a binary removes its SYMBOL TABLE (function/variable names) "
             "-- it does NOT touch string literals sitting in the .rodata data section, so "
             "<code>strings</code> finds those exactly the same either way."),
            ("Useful flags",
             "<code>-n 8</code> only shows strings 8+ characters (cuts noise from short garbage "
             "matches). <code>-a</code> scans the WHOLE file instead of just the typical string-"
             "bearing sections (needed for data hidden in weird places). Pipe into "
             "<code>| grep -i &lt;word&gt;</code> to search directly."),
        ],
        task=(
            "Run plain <code>strings</code> on <code>password_checker_stripped</code>, then "
            "<code>strings -n 8</code>, then grep for anything password-shaped. Find the one "
            "unusual word hiding among normal program strings (Usage messages, format strings, "
            "libc artifacts)."
        ),
        commands=[
            "strings password_checker_stripped | less",
            "strings -n 8 password_checker_stripped",
            "strings password_checker_stripped | grep -vi usage",
        ],
        hints=[
            "Ignore anything that reads like a normal sentence or a %s/%d format specifier -- those "
            "are totally ordinary C runtime strings, not secrets.",
            "There's exactly one lowercase word+digits combination that doesn't belong with the rest.",
        ],
        answer="The odd string is <code>sunrise77</code> -- the program's hardcoded access code, found without ever running or disassembling it.",
        files=["password_checker_stripped"],
    ),
    dict(
        slug="tool-objdump", kind="tool", order=3, difficulty="Easy", color="cat0",
        title="objdump", tagline="Turn machine code back into readable assembly.",
        tools=["objdump -d", "objdump -M intel"],
        tutorial=[
            ("Disassembling", "<code>objdump -d &lt;binary&gt;</code> disassembles every function it "
             "can find, AT&amp;T syntax by default (source, then destination: <code>mov eax, 5</code> "
             "becomes <code>mov $0x5,%eax</code>)."),
            ("Switching to Intel syntax", "Add <code>-M intel</code> if you find destination-first "
             "syntax easier (matches what gdb and Ghidra show by default too): "
             "<code>objdump -d -M intel &lt;binary&gt;</code>."),
            ("Narrowing the output", "Pipe into <code>| less</code> to page through, or "
             "<code>-j .text</code> to only disassemble the main code section."),
        ],
        task=(
            "Disassemble both binaries with <code>-M intel</code>. In "
            "<code>age_eligibility_check</code>, find the exact hex constant main compares the "
            "(atoi'd) argument against before the conditional jump. In "
            "<code>grade_lookup_switch</code>, find the chain of comparisons and work out every "
            "grade boundary -- remember the input is divided by 10 first."
        ),
        commands=[
            "objdump -d -M intel age_eligibility_check | less",
            "objdump -d -M intel grade_lookup_switch | less",
        ],
        hints=[
            "`cmp eax, 0x12` is the line to find in age_eligibility_check -- convert 0x12 from hex to "
            "decimal yourself rather than guessing.",
            "In grade_lookup_switch the compared values are 10, 9, 8, 7, 6 -- but that's score/10, so "
            "multiply back out to get the real score ranges.",
        ],
        answer="Age threshold is 18 (0x12). Grade boundaries: 90-100=A, 80-89=B, 70-79=C, 60-69=D, below 60=F.",
        files=["age_eligibility_check", "grade_lookup_switch"],
    ),
    dict(
        slug="tool-readelf", kind="tool", order=4, difficulty="Easy", color="cat0",
        title="readelf", tagline="Inspect the ELF file format itself, not just the code inside it.",
        tools=["readelf -h", "readelf -S", "readelf -d", "readelf -l"],
        tutorial=[
            ("-h: ELF header", "<code>readelf -h &lt;bin&gt;</code> shows the entry point address, "
             "ELF type (EXEC vs DYN/PIE), and target architecture."),
            ("-S: section headers", "<code>readelf -S &lt;bin&gt;</code> lists every section "
             "(.text, .data, .rodata, .symtab if present...) with its size and address."),
            ("-d: dynamic section", "<code>readelf -d &lt;bin&gt;</code> lists shared library "
             "dependencies and dynamic linking flags -- the same NEEDED entries <code>ldd</code> "
             "resolves for you."),
            ("-l: program headers", "<code>readelf -l &lt;bin&gt;</code> shows segments, including "
             "whether the GNU_STACK segment is executable (a clue about NX, covered properly in the "
             "checksec lab)."),
        ],
        task=(
            "Run all four readelf flags on BOTH password_checker_debug and "
            "password_checker_stripped. Compare the section list (<code>-S</code>) between them -- "
            "find the section that's present in one and completely missing in the other, and explain "
            "why in your own words."
        ),
        commands=[
            "readelf -h password_checker_debug",
            "readelf -S password_checker_debug password_checker_stripped",
            "readelf -d password_checker_debug",
            "readelf -l password_checker_debug",
        ],
        hints=[
            "Look specifically for `.symtab` and `.strtab` in the debug build's section list -- those "
            "are exactly what stripping deletes.",
        ],
        answer="`.symtab`/`.strtab` (the symbol table and its string table) appear in password_checker_debug's section list and are gone entirely from password_checker_stripped -- that IS what \"stripped\" means at the ELF-section level.",
        files=["password_checker_debug", "password_checker_stripped"],
    ),
    dict(
        slug="tool-nm", kind="tool", order=5, difficulty="Easy", color="cat0",
        title="nm", tagline="List a binary's symbol table directly.",
        tools=["nm", "nm -D"],
        tutorial=[
            ("Plain nm", "<code>nm &lt;bin&gt;</code> lists every symbol (function and global "
             "variable name) the binary's symbol table knows about, with a letter code for each "
             "(T=defined function in .text, U=undefined/external, etc)."),
            ("-D for dynamic symbols", "<code>nm -D &lt;bin&gt;</code> shows the DYNAMIC symbol "
             "table instead -- symbols needed for/exported to shared linking. This table survives "
             "stripping in a normal dynamically-linked binary, unlike the regular one."),
        ],
        task=(
            "Run plain <code>nm</code> on both password_checker_debug and "
            "password_checker_stripped and compare. Then run <code>nm -D</code> on the stripped one "
            "and notice it's NOT empty, even though plain <code>nm</code> basically is."
        ),
        commands=["nm password_checker_debug", "nm password_checker_stripped", "nm -D password_checker_stripped"],
        hints=["\"no symbols\" from plain nm on the stripped binary is the expected, correct result -- that's the entire point of this comparison."],
        answer="password_checker_debug lists main, plus libc-related symbols. password_checker_stripped's plain nm reports no symbols at all -- but nm -D still shows dynamic entries like printf/strcmp, because those are needed at runtime for dynamic linking regardless of stripping.",
        files=["password_checker_debug", "password_checker_stripped"],
    ),
    dict(
        slug="tool-ldd", kind="tool", order=6, difficulty="Easy", color="cat0",
        title="ldd", tagline="See exactly which shared libraries a binary needs.",
        tools=["ldd"],
        tutorial=[
            ("What it shows", "<code>ldd &lt;bin&gt;</code> lists every shared library "
             "(.so file) the dynamic linker will load at runtime, and the exact path it resolves to "
             "on THIS machine."),
            ("Why it matters for RE", "A binary that needs an unusual/uncommon library is a big "
             "lead -- it tells you what functionality to expect before you've disassembled anything."),
        ],
        task=(
            "Run <code>ldd</code> on both binaries. Confirm both are dynamically linked against the "
            "same core library and note its resolved path."
        ),
        commands=["ldd password_checker_debug", "ldd inventory_stock_manager"],
        hints=["Both are ordinary gcc-compiled C programs with no extra libraries deliberately linked in, so you should see essentially the same libc + dynamic linker entries for each."],
        answer="Both link against libc.so.6 and the dynamic linker (ld-linux-x86-64.so.2) -- there's nothing exotic here, which itself is a useful piece of recon (no unusual library = no unusual functionality to chase).",
        files=["password_checker_debug", "inventory_stock_manager"],
    ),
    dict(
        slug="tool-checksec", kind="tool", order=7, difficulty="Medium", color="cat1",
        title="checksec", tagline="Read a binary's security mitigations at a glance.",
        tools=["checksec"],
        tutorial=[
            ("The four mitigations it reports", "Stack Canary (detects stack buffer overflows before "
             "a corrupted return address is used), NX/DEP (marks the stack non-executable, so you "
             "can't just jump into injected shellcode), PIE (the whole binary loads at a randomized "
             "base address each run), RELRO (makes parts of the dynamic linking tables read-only "
             "after startup, protecting against some overwrite techniques)."),
            ("Why this lab exists in a RE/practice context",
             "Before even thinking about exploiting anything, the FIRST thing a vulnerability "
             "researcher does on a new target is run checksec -- it tells you which attack "
             "techniques are even possible before you invest time in anything else."),
            ("No checksec installed?", "Fall back to readelf: <code>readelf -l &lt;bin&gt;</code> "
             "and look at the GNU_STACK segment's flags (RWE = executable stack = no NX) and "
             "<code>readelf -h &lt;bin&gt;</code>'s Type field (DYN = PIE, EXEC = no PIE)."),
        ],
        task=(
            "Run <code>checksec --file=password_checker_debug</code> and "
            "<code>checksec --file=buffer_overflow_crash_demo</code>. Both were deliberately "
            "compiled with <code>-fno-stack-protector -no-pie</code> for this lab -- confirm checksec "
            "actually reports that correctly, and understand why a weakened binary like this is "
            "exactly what's used later in the buffer-overflow-intro attack lab."
        ),
        commands=["checksec --file=password_checker_debug", "checksec --file=buffer_overflow_crash_demo"],
        hints=["Both should show Canary: No, NX: (depends on your distro default), PIE: No -- that's intentional for this practice binary, real-world binaries you'll meet later are usually hardened with all four on."],
        answer="Both binaries show Canary: No and PIE: No (deliberately, for teaching purposes) -- a production binary on a modern distro would normally show Canary: Yes, PIE: Yes by default, which is exactly why real exploitation is harder than this practice lab.",
        files=["password_checker_debug", "buffer_overflow_crash_demo"],
    ),
    dict(
        slug="tool-gdb", kind="tool", order=8, difficulty="Medium", color="cat1",
        title="gdb", tagline="Stop reading code -- watch it execute, one instruction at a time.",
        tools=["gdb: break/run/next/step/continue", "info registers", "x/ (examine memory)"],
        tutorial=[
            ("Starting and breakpoints", "<code>gdb ./secret_number_guesser</code> opens it. "
             "<code>disas main</code> shows main's assembly with addresses. <code>break *0xADDRESS</code> "
             "sets a breakpoint there, or just <code>break main</code> for the function start."),
            ("Stepping", "<code>run</code> starts the program. <code>next</code>/<code>n</code> "
             "steps over one line without entering calls. <code>step</code>/<code>s</code> steps "
             "INTO calls. <code>continue</code>/<code>c</code> resumes to the next breakpoint or "
             "exit."),
            ("Reading state", "<code>info registers</code> dumps every general-purpose register's "
             "live value. <code>x/4dw $rsp</code> examines memory: 4 units, decimal, word-sized (4 "
             "bytes), starting at the stack pointer. Swap <code>d</code> for <code>x</code> for hex, "
             "or <code>s</code> for a string."),
        ],
        task=(
            "secret_number_guesser picks a hidden 4-digit number and only gives higher/lower hints "
            "forever -- use gdb to break right at its comparison and read the secret straight out of "
            "a register, instead of guessing in the terminal. stack_buffer_peek_demo has a local "
            "<code>buffer[16]</code> and a separate local <code>marker</code> int living nearby on "
            "the stack -- use <code>x/</code> to find the marker's exact value."
        ),
        commands=[
            "gdb ./secret_number_guesser",
            "(gdb) disas main",
            "(gdb) break *<address of the cmp>",
            "(gdb) run",
            "(gdb) info registers",
            "gdb ./stack_buffer_peek_demo -ex 'break show_buffer' -ex run -ex 'x/8dw $rsp'",
        ],
        hints=[
            "For stack_buffer_peek_demo, break right AFTER the strcpy call completes so the buffer is "
            "already filled, then scan several words around $rsp -- the marker is a plain small int, "
            "look for a suspiciously \"round\" 4-byte value among the string bytes.",
        ],
        answer="secret_number_guesser's hidden value is 8249. stack_buffer_peek_demo's marker is 777333 -- both read directly out of live memory without ever seeing the source.",
        files=["secret_number_guesser", "stack_buffer_peek_demo"],
    ),
    dict(
        slug="tool-ltrace", kind="tool", order=9, difficulty="Medium", color="cat1",
        title="ltrace", tagline="Watch every library call a program makes, with real arguments.",
        tools=["ltrace"],
        tutorial=[
            ("What it does", "<code>ltrace ./binary [args]</code> runs the program and prints every "
             "call into a shared library (strcmp, printf, malloc, scanf...) along with the actual "
             "argument values and return value -- often reveals comparisons/secrets instantly, with "
             "zero manual disassembly."),
            ("Why it's often faster than gdb", "No breakpoints to set, no addresses to find -- just "
             "run it and read the trace. The tradeoff: it only shows LIBRARY calls, not the program's "
             "own internal logic between them."),
        ],
        task=(
            "Run <code>ltrace ./secret_number_guesser</code>, enter a couple of guesses, and read "
            "the trace output. Find where the comparison against the secret number happens in the "
            "trace and read its actual value directly from the call arguments."
        ),
        commands=["ltrace ./secret_number_guesser"],
        hints=["scanf's trace line shows the address it wrote your guess to, and a later comparison call/line shows both values involved -- you don't even need to type the right guess to see the secret."],
        answer="The trace reveals the comparison happening against 8249, the same value found via gdb in the gdb lab -- confirming ltrace is a valid faster alternative for this kind of target.",
        files=["secret_number_guesser"],
    ),
    dict(
        slug="tool-strace", kind="tool", order=10, difficulty="Medium", color="cat1",
        title="strace", tagline="Watch every system call -- the layer below library calls.",
        tools=["strace"],
        tutorial=[
            ("What it does", "<code>strace ./binary</code> traces SYSTEM calls (read, write, open, "
             "execve, mmap...) instead of library calls -- the actual requests the program makes to "
             "the Linux kernel."),
            ("When to reach for it over ltrace", "Use strace for I/O-heavy or file/network-touching "
             "programs; use ltrace when you care about library-level logic like string comparisons. "
             "Many real investigations use both together."),
        ],
        task=(
            "Run <code>strace ./interactive_stdin_prompt</code>, type a name and a pin when prompted, "
            "and read the raw <code>read()</code> syscalls in the trace -- confirm you can see "
            "exactly what bytes the program actually received from your terminal at the syscall "
            "level."
        ),
        commands=["strace ./interactive_stdin_prompt"],
        hints=["Look for `read(0, ...)` lines -- file descriptor 0 is stdin, and the trace shows the literal bytes read, including your typed name and pin."],
        answer="You should see `read(0, \"yourname\\n\", ...)` and a second `read(0, \"yourpin\\n\", ...)` -- strace proves, at the lowest level, exactly what input the program consumed.",
        files=["interactive_stdin_prompt"],
    ),
    dict(
        slug="tool-ghidra", kind="tool", order=11, difficulty="Medium", color="cat0",
        title="Ghidra", tagline="Let the decompiler turn stripped assembly back into readable C.",
        tools=["Ghidra: Import, Decompile window, Rename (L), Cross-References, Graph view"],
        tutorial=[
            ("Import and auto-analyze", "File &rarr; New Project &rarr; Import File &rarr; pick the "
             "binary &rarr; double-click it in the project tree &rarr; say Yes to \"Analyze?\" with "
             "default options, then wait for the progress bar to finish."),
            ("Decompile + Listing, cross-checked", "The Listing (middle) shows raw disassembly; the "
             "Decompile window (right, or Window &rarr; Decompile) shows reconstructed C. When the "
             "decompiler's guess looks odd, the raw listing is the ground truth to fall back on."),
            ("Renaming as you go", "Press <kbd>L</kbd> on a selected variable/parameter/function to "
             "rename it. Do this immediately as you figure each one out -- every later reference "
             "becomes self-documenting."),
            ("Cross-references (XREFs)", "Right-click a function/variable &rarr; References &rarr; "
             "Show References To (or just read the inline XREF count) to see everywhere else it's "
             "used."),
            ("Graph view", "Window &rarr; Function Graph shows control flow as connected boxes -- "
             "often faster than reading raw disassembly for the overall if/loop/switch shape."),
        ],
        task=(
            "Both binaries are stripped and multi-function. Decompile <code>inventory_stock_manager</code> "
            "and identify its add/remove/check-stock sub-commands by renaming the generic "
            "<code>FUN_xxxxxxxx</code> names. Decompile <code>temperature_unit_converter</code> and "
            "recover the EXACT conversion formula from the decompiled C, not from memory."
        ),
        commands=["ghidraRun   # all actual work happens in the GUI for this lab"],
        hints=[
            "Look for a function doing three strcmp()s against literal strings like \"add\" and "
            "\"remove\" -- that's main(), and the strcmp targets are your three sub-commands.",
            "The temperature functions show floating-point math with constants 9.0, 5.0 and 32.0 -- "
            "which order they appear in (multiply-then-add vs subtract-then-multiply) tells you which "
            "formula belongs to which direction, no manual translation needed.",
        ],
        answer="inventory_stock_manager takes add/remove/check as argv[1]. temperature_unit_converter: F = C*9/5+32 for c2f, C = (F-32)*5/9 for f2c -- confirmed directly from decompiled source, not guessed.",
        files=["inventory_stock_manager", "temperature_unit_converter"],
    ),
    dict(
        slug="tool-xxd-hexdump", kind="tool", order=12, difficulty="Easy", color="cat3",
        title="xxd / hexdump", tagline="See and reconstruct a file's exact raw bytes.",
        tools=["xxd", "hexdump -C"],
        tutorial=[
            ("What they show", "Both print a file's raw bytes as hex pairs with an ASCII preview "
             "alongside -- <code>xxd &lt;file&gt;</code> or <code>hexdump -C &lt;file&gt;</code> "
             "(the <code>-C</code> \"canonical\" form is the readable one, always use it)."),
            ("Going the other way: xxd -r", "<code>xxd -r &lt;hexdump-file&gt; &gt; output.bin</code> "
             "reconstructs the original binary bytes FROM a hex dump -- useful when a challenge gives "
             "you a hex dump as text and you need the real bytes back."),
        ],
        task=(
            "Run <code>xxd</code> and <code>hexdump -C</code> on <code>message_bit_rotated_hex.txt</code> "
            "(itself just hex text -- note that running hex tools ON hex text shows you the ASCII "
            "digits '0'-'9'/'a'-'f', NOT the bytes those digits represent; you'd need to "
            "<code>xxd -r -p</code> or Python's <code>bytes.fromhex()</code> first to see the real "
            "underlying bytes)."
        ),
        commands=["xxd message_bit_rotated_hex.txt | head", "hexdump -C message_bit_rotated_hex.txt | head", "xxd -r -p message_bit_rotated_hex.txt | xxd | head   # the REAL underlying bytes"],
        hints=["The key realization this lab is testing: a file of hex-looking TEXT and the actual bytes that hex represents are two different things until you explicitly decode one into the other."],
        answer="xxd/hexdump on the raw .txt file just shows you the ASCII characters '0'-'9ab...' byte by byte -- decoding with `xxd -r -p` first gives you the real encoded message bytes (which still need bit-rotation decoding, covered in the bit-rotation attack lab).",
        files=["message_bit_rotated_hex.txt"],
    ),
    dict(
        slug="tool-binwalk", kind="tool", order=13, difficulty="Medium", color="cat3",
        title="binwalk", tagline="Find file signatures buried inside another file.",
        tools=["binwalk", "binwalk -e"],
        tutorial=[
            ("What it does", "<code>binwalk &lt;file&gt;</code> scans the ENTIRE file byte-by-byte "
             "for known file-format signatures (zip headers, image headers, filesystem headers...) "
             "wherever they appear -- not just at offset 0, unlike <code>file</code>."),
            ("Extracting automatically", "<code>binwalk -e &lt;file&gt;</code> both finds AND "
             "attempts to carve out/extract each embedded file it recognizes, into a new "
             "<code>_filename.extracted/</code> folder."),
        ],
        task=(
            "<code>embedded_archive_scan_target.bin</code> is random-looking noise bytes with a real "
            "zip archive hidden partway through it. Use binwalk to find the exact byte offset where "
            "the embedded zip starts, then extract it and read what's inside."
        ),
        commands=["binwalk embedded_archive_scan_target.bin", "binwalk -e embedded_archive_scan_target.bin", "unzip _embedded_archive_scan_target.bin.extracted/*.zip -d out/ && cat out/hidden_note.txt"],
        hints=["`file`'s honest \"data\" verdict on this same file in the tool-file lab is exactly the signal that something buried/non-standard is going on -- binwalk is the direct follow-up tool for that situation."],
        answer="binwalk reports a Zip archive signature starting partway into the file (not at offset 0); extracting it reveals hidden_note.txt confirming the tool is mastered.",
        files=["embedded_archive_scan_target.bin"],
    ),
    dict(
        slug="tool-zip2john-john", kind="tool", order=14, difficulty="Medium", color="cat3",
        title="zip2john + john", tagline="Crack a weak zip password offline.",
        tools=["zip2john", "john"],
        tutorial=[
            ("The two-step pattern", "<code>zip2john &lt;file.zip&gt; &gt; hash.txt</code> extracts "
             "the zip's password hash into a format John the Ripper understands. "
             "<code>john hash.txt</code> then runs John's default wordlist/rules against it."),
            ("Seeing the cracked result", "<code>john --show hash.txt</code> prints the recovered "
             "password once John has found it (it caches results in <code>~/.john/john.pot</code>, "
             "so re-running john on the same hash instantly shows \"already cracked\")."),
            ("When this realistically works", "Only against WEAK, dictionary-guessable passwords -- "
             "exactly the kind seen in beginner-friendly forensics challenges (and this lab)."),
        ],
        task=(
            "<code>password_protected_notes.zip</code> has a short, weak, dictionary-guessable "
            "password. Crack it with zip2john + john, then unzip it with the recovered password and "
            "read the note inside."
        ),
        commands=["zip2john password_protected_notes.zip > hash.txt", "john hash.txt", "john --show hash.txt", "unzip -P <recovered password> password_protected_notes.zip"],
        hints=["If john's default run seems slow or inconclusive, try `john --wordlist=/usr/share/wordlists/rockyou.txt hash.txt` if that wordlist is present on your Kali install -- this password is deliberately on the common-offline-CTF-password side."],
        answer="The zip's password is pendrive99. Unzipping with it reveals secret_note.txt confirming the tool is mastered.",
        files=["password_protected_notes.zip"],
    ),
    dict(
        slug="tool-netcat", kind="tool", order=15, difficulty="Easy", color="cat4",
        title="nc (netcat)", tagline="Talk directly to a raw TCP service -- the way every live challenge is solved.",
        tools=["nc"],
        tutorial=[
            ("Why netcat matters", "nc is how you connect to ANY raw TCP service and talk to its "
             "stdin/stdout directly -- exactly how every live \"Network\" category challenge on this "
             "platform (and every real-world pwn/network CTF challenge) is actually solved."),
            ("Basic syntax", "<code>nc &lt;host&gt; &lt;port&gt;</code> connects. Once connected, "
             "whatever you type is sent, and whatever the service prints comes straight back to your "
             "terminal -- it's a two-way pipe, nothing fancier than that."),
        ],
        task=(
            "start_ctf.sh runs a small, always-on, non-scored practice banner service on port 9103 "
            "(separate from the real scored Network challenges on 9101/9102). Connect to it with nc, "
            "read its prompt, and try its three commands."
        ),
        commands=["nc 127.0.0.1 9103", "HELLO", "TIME", "QUIT"],
        hints=["If the connection seems to hang after connecting, that's normal -- the service is waiting for YOUR first line of input before it responds to anything."],
        answer="Typing HELLO/TIME/QUIT each get a distinct scripted reply, and QUIT closes the connection cleanly from the server side -- confirming you can drive a raw TCP service purely with nc, the same skill the real Network category challenges need.",
        files=["practice_banner_service"],
        live_port=9103,
    ),
]

ATTACK_LABS = [
    dict(
        slug="attack-reverse-text", kind="attack", order=1, difficulty="Easy", color="cat2",
        title="Reverse", tagline="The simplest possible transform -- flip the whole string.",
        tools=["Python: text[::-1]", "Linux: rev"],
        tutorial=[("How to spot it", "If reversing the visible text instantly makes it readable English, you're done -- no byte-level analysis needed at all. Always try this first on any short garbled-looking text file.")],
        task="Decode message_reversed_bytes.txt.",
        commands=["python3 -c \"print(open('message_reversed_bytes.txt').read()[::-1])\"", "rev message_reversed_bytes.txt"],
        hints=["Literally just reverse the whole string character by character -- there's no key, no shift, nothing else going on here."],
        answer="Decodes to: \"flag practice this is not a real flag just text for you to decode\".",
        files=["message_reversed_bytes.txt"],
    ),
    dict(
        slug="attack-base64", kind="attack", order=2, difficulty="Easy", color="cat2",
        title="Base64 encoding", tagline="The single most common text-safe encoding you'll ever meet.",
        tools=["Python: base64.b64decode"],
        tutorial=[("Recognizing it", "Alphabet is A-Z, a-z, 0-9, plus <code>+</code> and <code>/</code>, often padded with one or two trailing <code>=</code> signs. Length is always a multiple of 4.")],
        task="Decode message_base64_encoded.txt.",
        commands=["python3 -c \"import base64; print(base64.b64decode(open('message_base64_encoded.txt').read()).decode())\""],
        hints=["If it decodes to garbage, double check you copied the WHOLE string including any trailing = padding."],
        answer="Decodes to: \"mastering base64 is step one of every encoding puzzle you will ever see\".",
        files=["message_base64_encoded.txt"],
    ),
    dict(
        slug="attack-hex", kind="attack", order=3, difficulty="Easy", color="cat2",
        title="Hex encoding", tagline="Every byte written out as two base-16 digits.",
        tools=["Python: bytes.fromhex"],
        tutorial=[("Recognizing it", "Alphabet is ONLY 0-9 and a-f (or A-F), always an even number of characters total (two hex digits per original byte).")],
        task="Decode message_hex_encoded.txt.",
        commands=["python3 -c \"print(bytes.fromhex(open('message_hex_encoded.txt').read()).decode())\""],
        hints=["If the character count is odd, you've mis-copied something -- valid hex-encoded bytes always come in pairs."],
        answer="Decodes to: \"hex encoding is just every byte written as two base sixteen digits\".",
        files=["message_hex_encoded.txt"],
    ),
    dict(
        slug="attack-xor-single-byte", kind="attack", order=4, difficulty="Medium", color="cat2",
        title="Single-byte XOR", tagline="XOR every byte against one repeating key byte.",
        tools=["Python: crib-dragging"],
        tutorial=[
            ("The crib-drag technique", "If you can guess ANY plaintext substring (here: the message "
             "starts with the word \"flag\"), XOR those guessed plaintext bytes against the matching "
             "ciphertext bytes at the same position -- the result IS the key, directly, with zero "
             "brute force needed."),
            ("Why XOR is reversible with the same key", "XOR-ing twice with the same key returns the "
             "original: <code>(P xor K) xor K == P</code> -- that's the entire mathematical reason "
             "this cipher family works both ways with one key."),
        ],
        task="The file is hex-encoded XOR'd bytes. Recover the single-byte key and decode the message.",
        commands=["python3 -c \"d=bytes.fromhex(open('message_single_byte_xor.txt').read()); print([hex(d[i]^ord('flag practice'[i])) for i in range(5)])\"  # crib-drag the key", "python3 -c \"d=bytes.fromhex(open('message_single_byte_xor.txt').read()); print(bytes(b^0x2B for b in d))\""],
        hints=["Hex-decode first -- this is layered on top of hex encoding. Then XOR the first handful of decoded bytes against the guessed crib \"flag \" to recover the single repeating key byte."],
        answer="Key is 0x2B. Decodes to: \"flag practice this is not a real flag just text for you to decode\".",
        files=["message_single_byte_xor.txt"],
    ),
    dict(
        slug="attack-caesar-shift", kind="attack", order=5, difficulty="Easy", color="cat2",
        title="Caesar / ROT shift", tagline="Every character shifted by a fixed amount -- here, across the FULL printable ASCII range.",
        tools=["Python: brute-force all shifts"],
        tutorial=[("Important twist on this platform", "Classic Caesar only shifts a-z/A-Z. This file's variant shifts the FULL printable ASCII range (32-126) with wraparound -- so spaces and punctuation move too. Don't assume letters-only just because it looks like a normal Caesar cipher.")],
        task="Decode message_caesar_shift.txt by brute-forcing every shift amount 1-94 programmatically.",
        commands=["python3 -c \"\nimport sys\ns=open('message_caesar_shift.txt').read()\nfor shift in range(95):\n  out=''.join(chr(32+(ord(c)-32-shift)%95) if 32<=ord(c)<=126 else c for c in s)\n  if ' is ' in out: print(shift, out)\n\""],
        hints=["Don't try to do this by hand -- loop all 95 possible shifts in a script and filter for one that contains ordinary English words."],
        answer="Shift used was 13 (mod 95). Decodes to: \"flag practice this is not a real flag just text for you to decode\".",
        files=["message_caesar_shift.txt"],
    ),
    dict(
        slug="attack-bit-rotation", kind="attack", order=6, difficulty="Medium", color="cat2",
        title="Bit rotation", tagline="Every byte's bits rotated, not shifted in value -- a different kind of scrambling entirely.",
        tools=["Python: bitwise rotate"],
        tutorial=[("Why it's reversible", "Rotating a byte's bits LEFT by N undoes with a RIGHT rotation by that same N (mod 8) -- rotation never loses information, it just repositions bits around the 8-bit boundary.")],
        task="The file is hex-encoded, bit-rotated bytes. Hex-decode, then brute-force rotation amounts 1-7.",
        commands=["python3 -c \"\nd=bytes.fromhex(open('message_bit_rotated_hex.txt').read())\nfor n in range(1,8):\n  out=bytes(((b>>n)|(b<<(8-n)))&0xFF for b in d)\n  if b'flag' in out: print(n, out)\n\""],
        hints=["Hex-decode FIRST (that layer is separate from the rotation), then try every right-rotation amount 1 through 7 on the resulting bytes."],
        answer="Bytes were left-rotated by 3 to encode, so decode with a right-rotation by 3. Decodes to: \"flag practice this is not a real flag just text for you to decode\".",
        files=["message_bit_rotated_hex.txt"],
    ),
    dict(
        slug="attack-substitution-cipher", kind="attack", order=7, difficulty="Medium", color="cat2",
        title="Fixed substitution cipher", tagline="Every letter swapped 1:1 for a different fixed letter -- NOT a shift.",
        tools=["Frequency analysis", "pattern recognition"],
        tutorial=[("Why brute-forcing a shift won't work here", "This is a full substitution table (arbitrary letter-to-letter mapping), not a Caesar-style uniform shift -- there's no single number to brute force. Frequency analysis (the most common cipher letter is probably 'e' in English) or just recognizing short common words (\"the\", \"is\", \"a\") by their letter pattern is the real technique.")],
        task="Decode message_substitution_cipher.txt.",
        commands=["python3 -c \"import collections; print(collections.Counter(open('message_substitution_cipher.txt').read().lower()).most_common(8))\"  # frequency analysis starting point"],
        hints=["The message is short enough that spotting one recognizable short word (a 2-3 letter one) and working outward from it is faster than full frequency analysis here."],
        answer="Decodes to: \"flag practice this is not a real flag just text for you to decode\" (table used: a&harr;q, b&harr;w, and so on across the alphabet).",
        files=["message_substitution_cipher.txt"],
    ),
    dict(
        slug="attack-vigenere", kind="attack", order=8, difficulty="Hard", color="cat2",
        title="Vigenere (repeating-key shift)", tagline="A different shift amount per character, cycling through a secret key.",
        tools=["Python: crib-dragging the key"],
        tutorial=[
            ("How it differs from Caesar", "Caesar uses ONE shift for the whole message. Vigenere "
             "cycles through a short KEY, using each key letter's alphabet position as that "
             "character's individual shift amount -- far harder to brute force by trying single "
             "shift values."),
            ("Crib-dragging the key", "If you know the plaintext starts with a certain word (here: "
             "\"practice\"), subtract that guessed plaintext from the ciphertext letter-by-letter -- "
             "the result IS the repeating key, revealed directly."),
        ],
        task="Decode message_vigenere_cipher.txt. You don't know the key length in advance -- recover it from the crib.",
        commands=["python3 -c \"\nc=open('message_vigenere_cipher.txt').read()\ncrib='practice'\nkey=''.join(chr((ord(c[i])-ord(crib[i]))%26+97) for i in range(len(crib)))\nprint('recovered key fragment:', key)\n\""],
        hints=["Only alphabetic characters consume a key position -- spaces pass through untouched and don't advance the key index, so align your crib carefully against letters only."],
        answer="Key is \"zerodays\" (8 letters, repeating). Decodes to: \"practice vigenere decoding using a short repeating key hunt it down carefully\".",
        files=["message_vigenere_cipher.txt"],
    ),
    dict(
        slug="attack-chained-layers", kind="attack", order=9, difficulty="Hard", color="cat3",
        title="Chained / layered encoding", tagline="Two+ encodings stacked -- stop decoding by hand, write the script.",
        tools=["Python: scripted multi-layer decode"],
        tutorial=[
            ("Peeling layers outside-in", "Look at the raw file's character set first to identify the "
             "OUTERMOST layer, decode it, look at what's left, and repeat. Never assume the layer "
             "order from context alone -- verify it from what the data actually looks like at each "
             "step."),
            ("Why automate this specifically", "Real challenges routinely stack 2-3 encodings -- "
             "doing that by hand with a web tool doesn't scale. The moment you've manually decoded "
             "one layer, write the three lines of Python that do it, so the next similar challenge is "
             "instant."),
        ],
        task="layered_encoding_challenge.txt has two layers stacked. Write ONE script that decodes both automatically.",
        commands=["python3 -c \"print(open('layered_encoding_challenge.txt').read()[:50])\"  # look at the raw shape first", "# hex-decode -> XOR every byte against a candidate key -> base64-decode"],
        hints=[
            "The raw file is pure hex digits in pairs -- that's always the outermost layer, decode it first.",
            "What's left after hex-decoding isn't readable yet, but IS valid base64-alphabet bytes once "
            "XORed against the right single-byte key -- try keys 0x00-0xFF programmatically and check "
            "which produces valid base64 characters only; the correct key is 0x11.",
        ],
        answer="Full script: <code>d=bytes.fromhex(open('layered_encoding_challenge.txt').read())<br>x=bytes(b^0x11 for b in d)<br>import base64; print(base64.b64decode(x).decode())</code><br>Result: \"flag practice this is not a real flag just text for you to decode\".",
        files=["layered_encoding_challenge.txt"],
    ),
    dict(
        slug="attack-checksum-gate", kind="attack", order=10, difficulty="Medium", color="cat1",
        title="ASCII checksum gate", tagline="Any input whose byte values sum to a fixed target unlocks it.",
        tools=["Python: construct a matching string"],
        tutorial=[("The logic pattern", "The program sums the ASCII (byte) value of every character in your argv[1] and compares the total against a hardcoded target -- infinitely many strings can satisfy one target sum, you just need to construct any ONE that works.")],
        task="Find any argv[1] for checksum_lock whose characters sum to exactly 1186.",
        commands=["python3 -c \"\ntarget=1186\nn=20\nbase=target//n\nrem=target-base*n\ns=chr(base+rem)+chr(base)*(n-1)\nprint(sum(ord(c) for c in s), repr(s))\n\"", "./checksum_lock '<the string your script built>'"],
        hints=["Don't try to guess a real word -- just build 15-20 repeated/adjusted characters programmatically until the sum matches exactly."],
        answer="Any string summing to exactly 1186 works -- e.g. a script-generated string of repeated characters with one adjusted to hit the exact total. \"Lock opens!\" confirms it.",
        files=["checksum_lock"],
    ),
    dict(
        slug="attack-getenv-gate", kind="attack", order=11, difficulty="Medium", color="cat1",
        title="getenv gate", tagline="Reads a secret from an ENVIRONMENT VARIABLE -- not argv, not stdin.",
        tools=["objdump", "shell environment variables"],
        tutorial=[("The trap this tests for", "If a binary's disassembly shows a call to `getenv@plt`, running it normally will NEVER unlock it, no matter what command-line arguments or stdin input you try -- you must set the right environment variable first: `VAR=value ./program`.")],
        task="Find which environment variable env_var_secret_gate reads, and what value unlocks it.",
        commands=["objdump -d -M intel env_var_secret_gate | grep -B2 -A2 getenv", "strings env_var_secret_gate | grep -i key", "GATE_KEY=guess ./env_var_secret_gate"],
        hints=["The exact variable NAME it calls getenv() with is sitting as a plain readable string in the binary -- find it with strings/objdump before trying to guess the VALUE."],
        answer="`GATE_KEY=midnight ./env_var_secret_gate` prints \"Gate unlocked!\".",
        files=["env_var_secret_gate"],
    ),
    dict(
        slug="attack-stdin-gate", kind="attack", order=12, difficulty="Medium", color="cat1",
        title="Interactive stdin gate", tagline="Wants input typed in live while it runs -- not as an argument.",
        tools=["static reading (objdump/Ghidra)", "running it interactively"],
        tutorial=[("Recognizing this pattern", "A `scanf(\"%d\", &pin)`-style program expects input typed in WHILE it runs -- running it with command-line arguments or redirected stdin without matching its exact prompt sequence won't work the same way.")],
        task="Find the correct PIN interactive_stdin_prompt wants, without brute-forcing all 10000 combinations live.",
        commands=["./interactive_stdin_prompt", "objdump -d -M intel interactive_stdin_prompt | grep -B3 -A3 cmp"],
        hints=["Brute-forcing 0000-9999 by typing is impractical -- reading the compare instruction directly in objdump/Ghidra gives you the exact number instantly instead."],
        answer="PIN is 4321 -- found by reading the disassembled comparison directly, not by guessing live.",
        files=["interactive_stdin_prompt"],
    ),
    dict(
        slug="attack-recursive-math-gate", kind="attack", order=13, difficulty="Medium", color="cat1",
        title="Recursive math gate (Fibonacci)", tagline="Solve the math yourself instead of brute-forcing the binary.",
        tools=["Python (solve mathematically)", "objdump (spot the self-call)"],
        tutorial=[("Recognizing recursion in disassembly", "A recursive function compiles into a function that CALLS ITSELF -- recognizable as a `call` instruction whose target address is the function's own starting address. If a gate's condition is \"does fib(n) equal some fixed target\", solve it mathematically -- far faster than running the binary repeatedly with different n.")],
        task="Find which n makes fib(n) match fibonacci_sequence_gate's hardcoded target.",
        commands=["python3 -c \"\nfib=lambda n: n if n<2 else fib(n-1)+fib(n-2)\nprint([n for n in range(25) if fib(n)==377])\n\""],
        hints=["Just compute fib(0) through fib(20) or so in a one-line Python script and see which n gives exactly the gate's target -- no need to touch the binary at all until you're confirming the answer."],
        answer="n=14 (fib(14)=377). `./fibonacci_sequence_gate 14` prints \"Gate accepts n=14 (fib=377). Unlocked!\".",
        files=["fibonacci_sequence_gate"],
    ),
    dict(
        slug="attack-buffer-overflow-intro", kind="attack", order=14, difficulty="Hard", color="cat1",
        title="Buffer overflow (introductory)", tagline="Your bridge from Reverse Engineering into real Binary Exploitation.",
        tools=["gdb", "checksec (recap)", "a long input string"],
        tutorial=[
            ("The bug pattern", "<code>strcpy(buffer, input)</code> into a fixed-size local "
             "<code>char buffer[32]</code> with NO length check is the single most classic memory-"
             "corruption bug in C. Give it more than 32 bytes and it keeps writing past the buffer's "
             "end, overwriting whatever sits next on the stack -- eventually the saved return address "
             "itself."),
            ("Why it crashes (safely, here)", "Overwriting the return address with garbage (like a "
             "string of 'A's -- 0x41414141 repeated) makes the function try to \"return\" to an "
             "invalid address, causing a segmentation fault. This is the exact mechanism (just not "
             "yet weaponized into controlled code execution) behind classic stack-based buffer "
             "overflow exploits."),
            ("The bridge forward", "Recall the checksec lab: Canary/NX/PIE/RELRO exist SPECIFICALLY "
             "to make this exact bug much harder to turn into real code execution on modern "
             "binaries. This practice binary intentionally has all of them off, so you can see the "
             "raw, unmitigated mechanism clearly before meeting hardened real-world targets."),
        ],
        task=(
            "Run buffer_overflow_crash_demo with a short, then a very long (150+ character) argument "
            "and observe the difference. Then run it under gdb with the long input and inspect the "
            "crash: find what value ended up in the instruction pointer (RIP) at the moment of the "
            "segfault, and confirm it's built entirely from your own input bytes."
        ),
        commands=[
            "./buffer_overflow_crash_demo hello",
            "./buffer_overflow_crash_demo $(python3 -c \"print('A'*150)\")",
            "gdb -ex 'run $(python3 -c \"print(chr(39)+chr(39))\")' ./buffer_overflow_crash_demo   # (see note below)",
            "gdb --args ./buffer_overflow_crash_demo $(python3 -c \"print('A'*150)\")",
            "(gdb) run",
            "(gdb) info registers rip",
        ],
        hints=[
            "A short argument runs and returns completely normally -- the crash only appears once your "
            "input is longer than the 32-byte buffer plus whatever padding/saved registers sit "
            "between it and the return address.",
            "Once it segfaults inside gdb, `info registers rip` (or just the crash message gdb prints) "
            "will show an address built from repeated 0x41 bytes -- that's the literal ASCII value of "
            "'A', proving your own overflowing input directly overwrote the return address.",
        ],
        answer=(
            "Short input: runs fine, prints normally, exits 0. Long (150+ 'A') input: segmentation "
            "fault, exit code 139 -- and under gdb, RIP ends up containing 0x4141414141414141 "
            "(repeated 'A' = 0x41 bytes), direct proof the overflow overwrote the saved return address "
            "with attacker-controlled data. This is the foundational concept behind every stack-based "
            "exploit in the real Binary Exploitation category and beyond."
        ),
        files=["buffer_overflow_crash_demo"],
    ),
]

MODULES = TOOL_LABS + ATTACK_LABS

TOOLS_ARSENAL = [
    ("Static recon", [
        ("file <bin>", "Identify file type, architecture, linking, stripped/not-stripped at a glance."),
        ("strings [-n 8] <bin>", "Print embedded human-readable text, works even on stripped binaries."),
        ("objdump -d [-M intel] <bin>", "Full disassembly listing. Add -M intel for Intel-syntax asm."),
        ("readelf -h / -d / -S / -l <bin>", "Inspect ELF header, dynamic section, section headers, or program headers."),
        ("nm [-D] <bin>", "List symbol table (function/variable names) -- empty/sparse on stripped binaries; -D shows dynamic symbols."),
        ("ldd <bin>", "List shared library dependencies and where they resolve."),
        ("checksec --file=<bin>", "Report security mitigations: canary, NX, PIE, RELRO."),
    ]),
    ("Dynamic analysis", [
        ("gdb <bin>", "Interactive debugger: break, run, next, step, continue, info registers, x/."),
        ("ltrace <bin>", "Trace every library call (strcmp, malloc, printf...) with its arguments."),
        ("strace <bin>", "Trace every system call (read, write, open, connect...) with its arguments."),
    ]),
    ("Forensics", [
        ("file / strings / strings -a / grep -a", "Identify and search files, forcing text mode on binary-looking data."),
        ("xxd <file> / hexdump -C <file>", "Hex + ASCII dump of any file's raw bytes."),
        ("unzip <file> (rename to .zip first if no extension)", "Extract zip archives, including nested ones."),
        ("zip2john <file> > hash.txt && john hash.txt", "Crack a password-protected zip's weak password."),
        ("binwalk [-e] <file>", "Scan for (and optionally extract) embedded file signatures inside another file."),
    ]),
    ("Crypto / encoding", [
        ("python3 -c \"import base64; ...\"", "Base64 encode/decode one-liners."),
        ("python3 -c \"bytes.fromhex(...)\"", "Hex-decode raw bytes for further processing."),
        ("rev <file>", "Reverse each line of text (Linux coreutils)."),
        ("echo <text> | tr 'A-Za-z' 'N-ZA-Mn-za-m'", "Quick ROT13 on the command line."),
    ]),
    ("Network", [
        ("nc <host> <port>", "Connect to a live TCP service -- the way every Network-category challenge (and this lab's practice service) is solved."),
    ]),
]
