import sqlite3
import hashlib
import os
from datetime import datetime
from flask import Flask, render_template, request, send_from_directory, redirect, url_for, flash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ctf.db")
CHAL_DIR = os.path.join(BASE_DIR, "challenges")

app = Flask(__name__)
app.secret_key = "karan-portable-ctf-v2-local-only"

CATEGORIES = ["Reverse Engineering", "Binary Exploitation", "Cryptography", "Forensics", "Network"]
# Progressive unlock order within a category: Easy challenges are always open;
# all Easy in a category must be solved before Medium unlocks; all Medium before Hard.
DIFF_ORDER = ["Easy", "Medium", "Hard"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def flag_hash(flag):
    return hashlib.sha256(flag.strip().encode()).hexdigest()


def compute_locks(challenges, solved_ids):
    """Returns {chal_id: True/False} -- True means LOCKED (not yet accessible)."""
    by_cat = {}
    for c in challenges:
        by_cat.setdefault(c["category"], {}).setdefault(c["difficulty"], []).append(c)

    locked = {}
    for cat, by_diff in by_cat.items():
        prev_tier_all_solved = True
        for tier in DIFF_ORDER:
            tier_chals = by_diff.get(tier, [])
            for c in tier_chals:
                locked[c["id"]] = not prev_tier_all_solved
            if tier_chals:
                prev_tier_all_solved = all(c["id"] in solved_ids for c in tier_chals)
    return locked


def effective_points(chal, solved_ids, hinted_ids):
    if chal["id"] not in solved_ids:
        return 0
    pts = chal["points"]
    if chal["id"] in hinted_ids:
        pts -= chal["hint_cost"]
    return max(pts, 0)


@app.route("/")
def index():
    conn = get_db()
    challenges = conn.execute("SELECT * FROM challenges ORDER BY id").fetchall()
    solved_rows = conn.execute("SELECT challenge_id FROM solves").fetchall()
    hinted_rows = conn.execute("SELECT challenge_id FROM hints_used").fetchall()
    conn.close()
    solved_ids = {r["challenge_id"] for r in solved_rows}
    hinted_ids = {r["challenge_id"] for r in hinted_rows}
    locked = compute_locks(challenges, solved_ids)

    total_points = sum(c["points"] for c in challenges)
    earned_points = sum(effective_points(c, solved_ids, hinted_ids) for c in challenges)

    by_category = {}
    for c in challenges:
        by_category.setdefault(c["category"], []).append(c)

    cat_progress = {}
    for cat, chals in by_category.items():
        done = sum(1 for c in chals if c["id"] in solved_ids)
        cat_progress[cat] = (done, len(chals))

    return render_template(
        "index.html",
        by_category=by_category,
        categories=CATEGORIES,
        cat_progress=cat_progress,
        solved_ids=solved_ids,
        locked=locked,
        total_points=total_points,
        earned_points=earned_points,
        total_chals=len(challenges),
        solved_count=len(solved_ids),
    )


@app.route("/chal/<int:chal_id>")
def challenge(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    if chal is None:
        conn.close()
        return "Challenge not found", 404

    all_chals = conn.execute("SELECT * FROM challenges").fetchall()
    solved_rows = conn.execute("SELECT challenge_id FROM solves").fetchall()
    solved_ids = {r["challenge_id"] for r in solved_rows}
    locked = compute_locks(all_chals, solved_ids)

    if locked.get(chal_id):
        conn.close()
        flash("That challenge is locked. Solve the easier challenges in this category first.", "error")
        return redirect(url_for("index"))

    # track first view time (for time-to-solve stats), ignore if already recorded
    conn.execute(
        "INSERT OR IGNORE INTO views (challenge_id, first_viewed_at) VALUES (?, datetime('now','localtime'))",
        (chal_id,),
    )
    conn.commit()

    solved = chal_id in solved_ids
    hinted = conn.execute("SELECT 1 FROM hints_used WHERE challenge_id = ?", (chal_id,)).fetchone()
    conn.close()
    return render_template("challenge.html", chal=chal, solved=solved, hinted=bool(hinted))


@app.route("/hint/<int:chal_id>", methods=["POST"])
def reveal_hint(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    if chal is None:
        conn.close()
        return "Challenge not found", 404
    conn.execute(
        "INSERT OR IGNORE INTO hints_used (challenge_id, used_at) VALUES (?, datetime('now','localtime'))",
        (chal_id,),
    )
    conn.commit()
    conn.close()
    flash(f"Hint revealed. -{chal['hint_cost']} points when you solve this one.", "info")
    return redirect(url_for("challenge", chal_id=chal_id))


@app.route("/files/<int:chal_id>")
def download_file(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    conn.close()
    if chal is None:
        return "Challenge not found", 404
    return send_from_directory(CHAL_DIR, chal["filename"], as_attachment=True)


@app.route("/submit/<int:chal_id>", methods=["POST"])
def submit(chal_id):
    conn = get_db()
    chal = conn.execute("SELECT * FROM challenges WHERE id = ?", (chal_id,)).fetchone()
    if chal is None:
        conn.close()
        return "Challenge not found", 404

    already = conn.execute("SELECT 1 FROM solves WHERE challenge_id = ?", (chal_id,)).fetchone()
    if already:
        flash("You already solved this one.", "info")
        conn.close()
        return redirect(url_for("challenge", chal_id=chal_id))

    submitted = request.form.get("flag", "")
    if flag_hash(submitted) == chal["flag_hash"]:
        conn.execute(
            "INSERT INTO solves (challenge_id, solved_at) VALUES (?, datetime('now', 'localtime'))",
            (chal_id,),
        )
        conn.commit()
        hinted = conn.execute("SELECT 1 FROM hints_used WHERE challenge_id = ?", (chal_id,)).fetchone()
        pts = chal["points"] - (chal["hint_cost"] if hinted else 0)
        flash(f"Correct! +{max(pts,0)} points.", "success")
    else:
        flash("Wrong flag. Try again.", "error")
    conn.close()
    return redirect(url_for("challenge", chal_id=chal_id))


@app.route("/scoreboard")
def scoreboard():
    conn = get_db()
    challenges = conn.execute("SELECT * FROM challenges ORDER BY category, id").fetchall()
    solved_rows = conn.execute("SELECT challenge_id, solved_at FROM solves").fetchall()
    hinted_rows = conn.execute("SELECT challenge_id FROM hints_used").fetchall()
    view_rows = conn.execute("SELECT challenge_id, first_viewed_at FROM views").fetchall()
    conn.close()

    solved_map = {r["challenge_id"]: r["solved_at"] for r in solved_rows}
    hinted_ids = {r["challenge_id"] for r in hinted_rows}
    viewed_map = {r["challenge_id"]: r["first_viewed_at"] for r in view_rows}

    total_points = sum(c["points"] for c in challenges)
    earned_points = sum(
        effective_points(c, set(solved_map.keys()), hinted_ids) for c in challenges
    )

    # time-to-solve per category (minutes), where both a view and a solve timestamp exist
    FMT = "%Y-%m-%d %H:%M:%S"
    cat_times = {}
    for c in challenges:
        cid = c["id"]
        if cid in solved_map and cid in viewed_map:
            try:
                t0 = datetime.strptime(viewed_map[cid], FMT)
                t1 = datetime.strptime(solved_map[cid], FMT)
                mins = max((t1 - t0).total_seconds() / 60.0, 0)
                cat_times.setdefault(c["category"], []).append(mins)
            except Exception:
                pass
    cat_avg_time = {cat: (sum(v) / len(v)) for cat, v in cat_times.items() if v}

    return render_template(
        "scoreboard.html",
        challenges=challenges,
        solved_map=solved_map,
        hinted_ids=hinted_ids,
        total_points=total_points,
        earned_points=earned_points,
        cat_avg_time=cat_avg_time,
    )


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        print("No database found. Run init_db.py first (start_ctf.sh does this automatically).")
    app.run(host="127.0.0.1", port=5000, debug=False)
