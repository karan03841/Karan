#!/usr/bin/env python3
"""PortableCTF v2 - database seed script. Safe to re-run (upserts)."""
import sqlite3, hashlib, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ctf.db")

def flag_hash(flag):
    return hashlib.sha256(flag.strip().encode()).hexdigest()

CHALLENGES = [
    {
        "id": 1,
        "title": """Vault Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """A tiny gatekeeper program checks a password you give it on the command line.
Find the correct password hidden inside the binary and run it to get the flag.

Usage: ./chal1 <password>""",
        "filename": """chal1""",
        "flag": """flag{str1ngs_4re_y0ur_fr1end}""",
        "hint": """Open the binary in a text tool that shows readable text inside binaries. Look near 'Correct!'.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy

Approach that solves this challenge:
Open the binary in a text tool that shows readable text inside binaries. Look near 'Correct!'.


Flag: flag{str1ngs_4re_y0ur_fr1end}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 2,
        "title": """Mirror Check""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """This program reverses whatever you type before comparing it to the real password.
Figure out what string, when reversed, matches the target — then give that as input.""",
        "filename": """chal2""",
        "flag": """flag{m1rr0r_m1rr0r_0n_th3_w4ll}""",
        "hint": """The binary stores the *reversed* password as a string literal. You need to reverse it back yourself before typing it in.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy

Approach that solves this challenge:
The binary stores the *reversed* password as a string literal. You need to reverse it back yourself before typing it in.


Flag: flag{m1rr0r_m1rr0r_0n_th3_w4ll}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 3,
        "title": """Checksum Gate v1""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """This gate doesn't check an exact password — it only checks that the ASCII values
of your input sum to a magic target number (and that length >= 4).

Find the target number in the binary, then craft ANY string whose byte values add up to it.""",
        "filename": """chal3""",
        "flag": """flag{ch3cksum_1s_n0t_s3cur1ty}""",
        "hint": """Disassemble and find the compared constant. Any combination of characters whose ASCII codes add to that number works — doesn't have to be the original password.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy

Approach that solves this challenge:
Disassemble and find the compared constant. Any combination of characters whose ASCII codes add to that number works — doesn't have to be the original password.


Flag: flag{ch3cksum_1s_n0t_s3cur1ty}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 4,
        "title": """Checksum Gate v2""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 80,
        "hint_cost": 12,
        "description": """This checker multiplies each character's ASCII value by its 1-indexed position
before summing — a 'weighted' checksum. Find the target sum and construct a
string whose weighted sum matches it exactly.""",
        "filename": """chal4""",
        "flag": """flag{w31ght3d_sums_4re_tr1cky}""",
        "hint": """position_weight * ascii_value, summed across all characters (position starts at 1, not 0). Write a small Python script to search for a matching string once you have the target.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
position_weight * ascii_value, summed across all characters (position starts at 1, not 0). Write a small Python script to search for a matching string once you have the target.


Flag: flag{w31ght3d_sums_4re_tr1cky}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 5,
        "title": """Case Confusion""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """This one lowercases both your input and the stored password before comparing.
Find the stored password string (case doesn't matter when you type it).""",
        "filename": """chal5""",
        "flag": """flag{c4se_d0esnt_m4tter_here}""",
        "hint": """strings on the binary will show the password string directly in its original mixed case — but you can type it in any case.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy

Approach that solves this challenge:
strings on the binary will show the password string directly in its original mixed case — but you can type it in any case.


Flag: flag{c4se_d0esnt_m4tter_here}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 6,
        "title": """Multi-Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 55,
        "hint_cost": 8,
        "description": """This program needs exactly THREE command-line arguments and checks several
conditions on them at once: a length check, an exact word match, a magic
number, and a first-letter check. Find all of them and satisfy every condition.""",
        "filename": """chal6""",
        "flag": """flag{3v3ry_c0nd1t10n_m4tters}""",
        "hint": """Usage: ./chal6 <word1> <word2> <number>. Read the disassembly carefully — there are 4 separate checks that must ALL pass.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy

Approach that solves this challenge:
Usage: ./chal6 <word1> <word2> <number>. Read the disassembly carefully — there are 4 separate checks that must ALL pass.


Flag: flag{3v3ry_c0nd1t10n_m4tters}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 7,
        "title": """XOR Lock Alpha""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 85,
        "hint_cost": 13,
        "description": """Your input is XORed byte-by-byte with a single-byte key, then compared against
a stored encoded array. Find the key and the target bytes in the binary, then
XOR them together yourself to recover the real password.""",
        "filename": """chal7""",
        "flag": """flag{x0r_1s_revers1ble_t00}""",
        "hint": """The XOR key is a single byte used as an immediate value in the comparison instruction. XOR is its own inverse: target[i] ^ key = original character.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
The XOR key is a single byte used as an immediate value in the comparison instruction. XOR is its own inverse: target[i] ^ key = original character.


Flag: flag{x0r_1s_revers1ble_t00}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 8,
        "title": """XOR Lock Beta""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 85,
        "hint_cost": 13,
        "description": """Same idea as the previous XOR lock, but a different key and a different target.
Don't assume the key is reused — read this binary fresh.""",
        "filename": """chal8""",
        "flag": """flag{tw0_k3ys_tw0_ch4ll3nges}""",
        "hint": """Dump the bytes being compared and the XOR key used in this specific binary; it is not the same key as any other challenge.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
Dump the bytes being compared and the XOR key used in this specific binary; it is not the same key as any other challenge.


Flag: flag{tw0_k3ys_tw0_ch4ll3nges}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 9,
        "title": """Caesar Gate I""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 85,
        "hint_cost": 13,
        "description": """This program applies a Caesar (alphabet-shift) cipher to your input, then
compares it against a stored shifted string: "jhlzhynhalrlf".
Find the shift amount used, then shift the stored string BACKWARD to recover
the real password.""",
        "filename": """chal9""",
        "flag": """flag{c4es4r_w4s_h3re_f1rst}""",
        "hint": """The shift amount is a small immediate constant (added mod 26) you'll see in the comparison logic. Shift the target string backward by that amount.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
The shift amount is a small immediate constant (added mod 26) you'll see in the comparison logic. Shift the target string backward by that amount.


Flag: flag{c4es4r_w4s_h3re_f1rst}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 10,
        "title": """Caesar Gate II (ROT13)""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 80,
        "hint_cost": 12,
        "description": """Another alphabet-shift cipher, this time with a famous shift value.
Stored target: "ebgngrtngrgjb". Work out the shift and decode it.""",
        "filename": """chal10""",
        "flag": """flag{3v3ry_sh1ft_1s_d1ff3rent}""",
        "hint": """This shift value is the same one used by the classic 'ROT13' cipher. Shifting by it twice gets you back to plaintext.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
This shift value is the same one used by the classic 'ROT13' cipher. Shifting by it twice gets you back to plaintext.


Flag: flag{3v3ry_sh1ft_1s_d1ff3rent}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 11,
        "title": """Substitution Table""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 95,
        "hint_cost": 14,
        "description": """This program substitutes each lowercase letter of your input using a 26-entry
lookup table stored in the binary, then compares to target "eqmstltd".
Extract the table (a-z mapped to new letters) and invert it to decode the target.""",
        "filename": """chal11""",
        "flag": """flag{t4bles_h1de_th3_truth}""",
        "hint": """The table is a global array 'sub_table[26]' indexed by (char - 'a'). Dump all 26 bytes, build the forward mapping a->?, then invert it to decode.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
The table is a global array 'sub_table[26]' indexed by (char - 'a'). Dump all 26 bytes, build the forward mapping a->?, then invert it to decode.


Flag: flag{t4bles_h1de_th3_truth}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 12,
        "title": """Bitwise OR Puzzle""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 70,
        "hint_cost": 10,
        "description": """Give exactly four numbers (0-255 each). The program OR's them all together
bitwise and checks if the result is 255 (all 8 bits set). Find any 4 numbers
that together cover every bit.""",
        "filename": """chal12""",
        "flag": """flag{b1ts_c0mb1ne_1nt0_truth}""",
        "hint": """255 = 0b11111111. You just need the bitwise OR of your 4 numbers to set every one of the 8 bits, e.g. think in terms of which bits each number contributes.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
255 = 0b11111111. You just need the bitwise OR of your 4 numbers to set every one of the 8 bits, e.g. think in terms of which bits each number contributes.


Flag: flag{b1ts_c0mb1ne_1nt0_truth}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 13,
        "title": """Transform Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """Each byte of your input gets run through a math transform (multiply, add,
mod 256) before being compared to a stored array. Reverse the math to recover
the original bytes.""",
        "filename": """chal13""",
        "flag": """flag{1ndex1ng_1nt0_th3_truth}""",
        "hint": """Transform is: v = (byte * 3 + 7) mod 256. To invert, you need the modular inverse of 3 mod 256 — or just brute-force each byte 0-255 and see which gives the target.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
Transform is: v = (byte * 3 + 7) mod 256. To invert, you need the modular inverse of 3 mod 256 — or just brute-force each byte 0-255 and see which gives the target.


Flag: flag{1ndex1ng_1nt0_th3_truth}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 14,
        "title": """Environment Check""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 75,
        "hint_cost": 11,
        "description": """This program doesn't read a command-line argument at all — it reads an
environment variable called CTF_KEY. Find the expected value in the binary,
then set the variable before running it (e.g. CTF_KEY=value ./chal14).""",
        "filename": """chal14""",
        "flag": """flag{env1ronment_var1ables_c0unt}""",
        "hint": """Look for the getenv() call and the string it's compared against. Set it like: export CTF_KEY="..." then run the binary, or CTF_KEY="..." ./chal14""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
Look for the getenv() call and the string it's compared against. Set it like: export CTF_KEY="..." then run the binary, or CTF_KEY="..." ./chal14


Flag: flag{env1ronment_var1ables_c0unt}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 15,
        "title": """Interactive Prompt""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 75,
        "hint_cost": 11,
        "description": """This one doesn't take a command-line argument — it prompts you interactively
and reads from stdin. Run it normally (./chal15) and type the password when asked.""",
        "filename": """chal15""",
        "flag": """flag{st1ll_w4nt1ng_1nput}""",
        "hint": """Find the compared string in the binary, then just run it directly and type the answer at the prompt (no argv needed).""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
Find the compared string in the binary, then just run it directly and type the answer at the prompt (no argv needed).


Flag: flag{st1ll_w4nt1ng_1nput}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 16,
        "title": """Two-Stage Pipeline""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 140,
        "hint_cost": 21,
        "description": """This checker runs your input through TWO transforms before comparing: first
it reverses the string, then XORs each byte with a key. Work backward through
both stages (undo XOR first, then un-reverse) to recover the real password.""",
        "filename": """chal16""",
        "flag": """flag{p1pel1nes_st4ck_tr4nsf0rms}""",
        "hint": """Order matters when undoing a pipeline — undo the LAST operation first. XOR the stored target with the key to get the reversed password, then reverse that result.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard

Approach that solves this challenge:
Order matters when undoing a pipeline — undo the LAST operation first. XOR the stored target with the key to get the reversed password, then reverse that result.


Flag: flag{p1pel1nes_st4ck_tr4nsf0rms}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 17,
        "title": """Caesar-Then-Add Pipeline""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 150,
        "hint_cost": 22,
        "description": """A Caesar shift is applied to your input, and THEN each resulting byte has a
small constant added to it (mod 256), before comparing to a stored array.
Undo the addition first, then undo the Caesar shift.""",
        "filename": """chal17""",
        "flag": """flag{thr33_st4ges_d3ep3r_n0w}""",
        "hint": """Work backward: subtract the add-constant from each stored byte (mod 256) to get the Caesar-shifted string, then shift that back by the Caesar amount.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard

Approach that solves this challenge:
Work backward: subtract the add-constant from each stored byte (mod 256) to get the Caesar-shifted string, then shift that back by the Caesar amount.


Flag: flag{thr33_st4ges_d3ep3r_n0w}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 18,
        "title": """Mystery Recursion""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 120,
        "hint_cost": 18,
        "description": """This program calls a recursive function on a number you provide and checks if
the result matches a hidden target. Figure out what mathematical sequence the
recursive function computes, then find which input produces the target value.""",
        "filename": """chal18""",
        "flag": """flag{recurs10n_h1des_l0g1c}""",
        "hint": """Trace the recursive calls: mystery(n) = mystery(n-1) + mystery(n-2), with mystery(0)=0 and mystery(1)=1. That's a very famous sequence — find which index gives the target shown in the output when you try wrong guesses.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard

Approach that solves this challenge:
Trace the recursive calls: mystery(n) = mystery(n-1) + mystery(n-2), with mystery(0)=0 and mystery(1)=1. That's a very famous sequence — find which index gives the target shown in the output when you try wrong guesses.


Flag: flag{recurs10n_h1des_l0g1c}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 19,
        "title": """Finite State Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 130,
        "hint_cost": 20,
        "description": """This program is a tiny finite state machine: each character you type moves it
between numbered states via a switch statement. Only one exact sequence of
characters walks it all the way to the accepting state. Trace the transitions.""",
        "filename": """chal19""",
        "flag": """flag{st4te_m4ch1nes_4re_puzzl3s}""",
        "hint": """Draw out the state diagram from the switch statement: state 0 needs a specific char to go to state 1, state 1 needs another to go to state 2, and so on, until state 4 (accept).""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard

Approach that solves this challenge:
Draw out the state diagram from the switch statement: state 0 needs a specific char to go to state 1, state 1 needs another to go to state 2, and so on, until state 4 (accept).


Flag: flag{st4te_m4ch1nes_4re_puzzl3s}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 20,
        "title": """Rule Table""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 110,
        "hint_cost": 16,
        "description": """Four numbers are validated against four range-rules stored in a struct array
in the binary (each rule has a low and high bound). Give any 4 numbers that
each satisfy their corresponding rule.""",
        "filename": """chal20""",
        "flag": """flag{structs_h0ld_th3_rul3s}""",
        "hint": """Dump the 'rules' array — it's 4 pairs of (lo, hi) integers. Any value within each range for its position works; it doesn't have to be an exact number.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard

Approach that solves this challenge:
Dump the 'rules' array — it's 4 pairs of (lo, hi) integers. Any value within each range for its position works; it doesn't have to be an exact number.


Flag: flag{structs_h0ld_th3_rul3s}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 21,
        "title": """Overflow I: Name Tag""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This program reads your name into a fixed-size stack buffer using scanf("%s", buf) — which does NOT check length. Right after the buffer, it declares an integer 'authenticated' that starts at 0 and unlocks the flag if it becomes nonzero.

Classic stack buffer overflow: if you type MORE characters than the buffer can hold, the extra bytes spill into adjacent stack memory — including that integer. Find out how many bytes of padding it takes to reach and overwrite it.

Run it interactively (./chal21) and type a long string of a repeated character to test your theory.""",
        "filename": """chal21""",
        "flag": """flag{st4ck_sm4sh1ng_101}""",
        "hint": """The buffer is 64 bytes. Try feeding it progressively longer strings of the same character (e.g. 70, 80, 90 'A's) and watch when the message changes from 'Access still locked' to 'UNLOCKED'. You don't need an exact byte value, any nonzero value written into that integer works.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium

Approach that solves this challenge:
The buffer is 64 bytes. Try feeding it progressively longer strings of the same character (e.g. 70, 80, 90 'A's) and watch when the message changes from 'Access still locked' to 'UNLOCKED'. You don't need an exact byte value, any nonzero value written into that integer works.

This demonstrates why bounds-unchecked reads (gets/scanf %s without a width limit) are dangerous: anything placed after the buffer on the stack -- another local variable, a saved frame pointer, or eventually the return address -- can be overwritten by sending enough input.

Flag: flag{st4ck_sm4sh1ng_101}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 22,
        "title": """Overflow II: Short Buffer""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 110,
        "hint_cost": 16,
        "description": """This program reads your name into a fixed-size stack buffer using scanf("%s", buf) — which does NOT check length. Right after the buffer, it declares an integer 'access_granted' that starts at 0 and unlocks the flag if it becomes nonzero.

Classic stack buffer overflow: if you type MORE characters than the buffer can hold, the extra bytes spill into adjacent stack memory — including that integer. Find out how many bytes of padding it takes to reach and overwrite it.

Run it interactively (./chal22) and type a long string of a repeated character to test your theory.""",
        "filename": """chal22""",
        "flag": """flag{0verfl0w_th3_g4t3}""",
        "hint": """The buffer is 32 bytes. Try feeding it progressively longer strings of the same character (e.g. 70, 80, 90 'A's) and watch when the message changes from 'Access still locked' to 'UNLOCKED'. You don't need an exact byte value, any nonzero value written into that integer works.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium

Approach that solves this challenge:
The buffer is 32 bytes. Try feeding it progressively longer strings of the same character (e.g. 70, 80, 90 'A's) and watch when the message changes from 'Access still locked' to 'UNLOCKED'. You don't need an exact byte value, any nonzero value written into that integer works.

This demonstrates why bounds-unchecked reads (gets/scanf %s without a width limit) are dangerous: anything placed after the buffer on the stack -- another local variable, a saved frame pointer, or eventually the return address -- can be overwritten by sending enough input.

Flag: flag{0verfl0w_th3_g4t3}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 23,
        "title": """Overflow III: Admin Flag""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 110,
        "hint_cost": 16,
        "description": """This program reads your name into a fixed-size stack buffer using scanf("%s", buf) — which does NOT check length. Right after the buffer, it declares an integer 'is_admin' that starts at 0 and unlocks the flag if it becomes nonzero.

Classic stack buffer overflow: if you type MORE characters than the buffer can hold, the extra bytes spill into adjacent stack memory — including that integer. Find out how many bytes of padding it takes to reach and overwrite it.

Run it interactively (./chal23) and type a long string of a repeated character to test your theory.""",
        "filename": """chal23""",
        "flag": """flag{adj4c3nt_mem0ry_1s_n0t_s4fe}""",
        "hint": """The buffer is 48 bytes. Try feeding it progressively longer strings of the same character (e.g. 70, 80, 90 'A's) and watch when the message changes from 'Access still locked' to 'UNLOCKED'. You don't need an exact byte value, any nonzero value written into that integer works.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium

Approach that solves this challenge:
The buffer is 48 bytes. Try feeding it progressively longer strings of the same character (e.g. 70, 80, 90 'A's) and watch when the message changes from 'Access still locked' to 'UNLOCKED'. You don't need an exact byte value, any nonzero value written into that integer works.

This demonstrates why bounds-unchecked reads (gets/scanf %s without a width limit) are dangerous: anything placed after the buffer on the stack -- another local variable, a saved frame pointer, or eventually the return address -- can be overwritten by sending enough input.

Flag: flag{adj4c3nt_mem0ry_1s_n0t_s4fe}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 24,
        "title": """Format String I: Loose Lips""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This program takes a line of text and passes it DIRECTLY to printf() as the format string, instead of using printf("%s", buf) safely. That's a classic format string vulnerability: if your input contains format specifiers like %x or %s, printf will happily read them and leak whatever happens to be on the stack nearby — including a secret string stored in a local variable just before your buffer.

Try feeding it a string full of %x (or %s) specifiers and see what leaks out. The secret is stored as readable ASCII text, so once you leak enough stack words in hex you can convert them back to text to read the hidden message (which is part of the flag).""",
        "filename": """chal24""",
        "flag": """flag{p3rcent_x_l3aks_st4ck}""",
        "hint": """Input like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (many repeated %x, separated for readability) will dump raw stack words as hex. Convert hex back to ASCII (remember x86-64 is little-endian, so bytes in each 8-byte word are reversed) to read the leaked text.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium

Approach that solves this challenge:
Input like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (many repeated %x, separated for readability) will dump raw stack words as hex. Convert hex back to ASCII (remember x86-64 is little-endian, so bytes in each 8-byte word are reversed) to read the leaked text.

Format string bugs are dangerous because the attacker controls what printf reads as arguments, letting you read (and, with %n, even write) arbitrary stack/memory. Any time user input reaches a printf-family call as the format string itself (instead of as a %s argument), treat it as vulnerable.

Flag: flag{p3rcent_x_l3aks_st4ck}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 25,
        "title": """Format String II: Stack Peek""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 110,
        "hint_cost": 16,
        "description": """This program takes a line of text and passes it DIRECTLY to printf() as the format string, instead of using printf("%s", buf) safely. That's a classic format string vulnerability: if your input contains format specifiers like %x or %s, printf will happily read them and leak whatever happens to be on the stack nearby — including a secret string stored in a local variable just before your buffer.

Try feeding it a string full of %x (or %s) specifiers and see what leaks out. The secret is stored as readable ASCII text, so once you leak enough stack words in hex you can convert them back to text to read the hidden message (which is part of the flag).""",
        "filename": """chal25""",
        "flag": """flag{pr1ntf_tru3ts_y0u_t00_much}""",
        "hint": """Input like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (many repeated %x, separated for readability) will dump raw stack words as hex. Convert hex back to ASCII (remember x86-64 is little-endian, so bytes in each 8-byte word are reversed) to read the leaked text.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium

Approach that solves this challenge:
Input like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (many repeated %x, separated for readability) will dump raw stack words as hex. Convert hex back to ASCII (remember x86-64 is little-endian, so bytes in each 8-byte word are reversed) to read the leaked text.

Format string bugs are dangerous because the attacker controls what printf reads as arguments, letting you read (and, with %n, even write) arbitrary stack/memory. Any time user input reaches a printf-family call as the format string itself (instead of as a %s argument), treat it as vulnerable.

Flag: flag{pr1ntf_tru3ts_y0u_t00_much}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 26,
        "title": """Format String III: Deep Leak""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 120,
        "hint_cost": 18,
        "description": """This program takes a line of text and passes it DIRECTLY to printf() as the format string, instead of using printf("%s", buf) safely. That's a classic format string vulnerability: if your input contains format specifiers like %x or %s, printf will happily read them and leak whatever happens to be on the stack nearby — including a secret string stored in a local variable just before your buffer.

Try feeding it a string full of %x (or %s) specifiers and see what leaks out. The secret is stored as readable ASCII text, so once you leak enough stack words in hex you can convert them back to text to read the hidden message (which is part of the flag).""",
        "filename": """chal26""",
        "flag": """flag{n3v3r_pr1ntf_user_1nput}""",
        "hint": """Input like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (many repeated %x, separated for readability) will dump raw stack words as hex. Convert hex back to ASCII (remember x86-64 is little-endian, so bytes in each 8-byte word are reversed) to read the leaked text.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium

Approach that solves this challenge:
Input like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (many repeated %x, separated for readability) will dump raw stack words as hex. Convert hex back to ASCII (remember x86-64 is little-endian, so bytes in each 8-byte word are reversed) to read the leaked text.

Format string bugs are dangerous because the attacker controls what printf reads as arguments, letting you read (and, with %n, even write) arbitrary stack/memory. Any time user input reaches a printf-family call as the format string itself (instead of as a %s argument), treat it as vulnerable.

Flag: flag{n3v3r_pr1ntf_user_1nput}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 27,
        "title": """Ret2Win I: Redirect""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 140,
        "hint_cost": 21,
        "description": """This binary has a 'win()' function that prints the flag — but main() never calls it. The vuln() function reads your input into a 40-byte stack buffer with ZERO bounds checking (a hand-rolled unsafe reader). On a non-PIE binary like this one, every function lives at a fixed, predictable address.

Classic ret2win: if you overflow the buffer far enough, you overwrite the saved return address on the stack. Overwrite it with win()'s address, and when vuln() returns, it 'returns' into win() instead of back to main().

You'll need: (1) objdump/nm to find win()'s address, (2) gdb (run with a cyclic pattern) to find the exact offset from the start of the buffer to the saved return address, then (3) Python (pwntools or just struct.pack) to build a payload of junk + the address (little-endian, 8 bytes) and pipe it in.""",
        "filename": """chal27""",
        "flag": """flag{r3t2w1n_cl4ss1c}""",
        "hint": """objdump -d chal27 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal27""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard

Approach that solves this challenge:
objdump -d chal27 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal27

This is the classic 'ret2win' primitive: a non-PIE binary has a function that's never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into it. The same idea (control-flow hijack via a corrupted return address) underlies almost all stack-based memory-corruption exploitation, including ROP chains later on.

Flag: flag{r3t2w1n_cl4ss1c}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 28,
        "title": """Ret2Win II: Longer Jump""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 150,
        "hint_cost": 22,
        "description": """This binary has a 'win()' function that prints the flag — but main() never calls it. The vuln() function reads your input into a 56-byte stack buffer with ZERO bounds checking (a hand-rolled unsafe reader). On a non-PIE binary like this one, every function lives at a fixed, predictable address.

Classic ret2win: if you overflow the buffer far enough, you overwrite the saved return address on the stack. Overwrite it with win()'s address, and when vuln() returns, it 'returns' into win() instead of back to main().

You'll need: (1) objdump/nm to find win()'s address, (2) gdb (run with a cyclic pattern) to find the exact offset from the start of the buffer to the saved return address, then (3) Python (pwntools or just struct.pack) to build a payload of junk + the address (little-endian, 8 bytes) and pipe it in.""",
        "filename": """chal28""",
        "flag": """flag{c0ntr0l_fl0w_h1j4ck}""",
        "hint": """objdump -d chal28 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal28""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard

Approach that solves this challenge:
objdump -d chal28 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal28

This is the classic 'ret2win' primitive: a non-PIE binary has a function that's never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into it. The same idea (control-flow hijack via a corrupted return address) underlies almost all stack-based memory-corruption exploitation, including ROP chains later on.

Flag: flag{c0ntr0l_fl0w_h1j4ck}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 29,
        "title": """Ret2Win III: Tight Buffer""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 160,
        "hint_cost": 24,
        "description": """This binary has a 'win()' function that prints the flag — but main() never calls it. The vuln() function reads your input into a 24-byte stack buffer with ZERO bounds checking (a hand-rolled unsafe reader). On a non-PIE binary like this one, every function lives at a fixed, predictable address.

Classic ret2win: if you overflow the buffer far enough, you overwrite the saved return address on the stack. Overwrite it with win()'s address, and when vuln() returns, it 'returns' into win() instead of back to main().

You'll need: (1) objdump/nm to find win()'s address, (2) gdb (run with a cyclic pattern) to find the exact offset from the start of the buffer to the saved return address, then (3) Python (pwntools or just struct.pack) to build a payload of junk + the address (little-endian, 8 bytes) and pipe it in.""",
        "filename": """chal29""",
        "flag": """flag{y0u_0wn_th3_r3turn_4ddr3ss}""",
        "hint": """objdump -d chal29 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal29""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard

Approach that solves this challenge:
objdump -d chal29 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal29

This is the classic 'ret2win' primitive: a non-PIE binary has a function that's never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into it. The same idea (control-flow hijack via a corrupted return address) underlies almost all stack-based memory-corruption exploitation, including ROP chains later on.

Flag: flag{y0u_0wn_th3_r3turn_4ddr3ss}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 30,
        "title": """Ret2Win IV: Final Boss""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 170,
        "hint_cost": 26,
        "description": """This binary has a 'win()' function that prints the flag — but main() never calls it. The vuln() function reads your input into a 72-byte stack buffer with ZERO bounds checking (a hand-rolled unsafe reader). On a non-PIE binary like this one, every function lives at a fixed, predictable address.

Classic ret2win: if you overflow the buffer far enough, you overwrite the saved return address on the stack. Overwrite it with win()'s address, and when vuln() returns, it 'returns' into win() instead of back to main().

You'll need: (1) objdump/nm to find win()'s address, (2) gdb (run with a cyclic pattern) to find the exact offset from the start of the buffer to the saved return address, then (3) Python (pwntools or just struct.pack) to build a payload of junk + the address (little-endian, 8 bytes) and pipe it in.""",
        "filename": """chal30""",
        "flag": """flag{f1n4l_b0ss_0f_pwn_l1te}""",
        "hint": """objdump -d chal30 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal30""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard

Approach that solves this challenge:
objdump -d chal30 | grep -A5 '<win>:' gives you win()'s address. gdb-peda / pwndbg with 'pattern create' and 'pattern offset' (or a manual cyclic pattern) finds the offset to the saved return address. Then: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WIN_ADDR))" | ./chal30

This is the classic 'ret2win' primitive: a non-PIE binary has a function that's never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into it. The same idea (control-flow hijack via a corrupted return address) underlies almost all stack-based memory-corruption exploitation, including ROP chains later on.

Flag: flag{f1n4l_b0ss_0f_pwn_l1te}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 31,
        "title": """Encoded Note I""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 30,
        "hint_cost": 5,
        "description": """A short note was found, encoded in a common text-safe encoding:

ZmxhZ3tiNHNlNjRfMXNfbjB0X2VuY3J5cHQxMG59

Decode it to find the flag.""",
        "filename": """chal31.txt""",
        "flag": """flag{b4se64_1s_n0t_encrypt10n}""",
        "hint": """This encoding uses only A-Z, a-z, 0-9, +, / and = padding — a very recognizable alphabet. `base64 -d` is your friend.""",
        "writeup": """Category: Cryptography | Difficulty: Easy

Approach that solves this challenge:
This encoding uses only A-Z, a-z, 0-9, +, / and = padding — a very recognizable alphabet. `base64 -d` is your friend.


Flag: flag{b4se64_1s_n0t_encrypt10n}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 32,
        "title": """Encoded Note II""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 30,
        "hint_cost": 5,
        "description": """Another note, encoded differently this time:

666c61677b6865785f6431673174735f3472655f62797433735f316e5f64317367753173657d

Figure out the encoding and recover the flag.""",
        "filename": """chal32.txt""",
        "flag": """flag{hex_d1g1ts_4re_byt3s_1n_d1sgu1se}""",
        "hint": """Only the characters 0-9 and a-f appear, always in pairs. `xxd -r -p` or Python's bytes.fromhex() can convert this back to text.""",
        "writeup": """Category: Cryptography | Difficulty: Easy

Approach that solves this challenge:
Only the characters 0-9 and a-f appear, always in pairs. `xxd -r -p` or Python's bytes.fromhex() can convert this back to text.


Flag: flag{hex_d1g1ts_4re_byt3s_1n_d1sgu1se}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 33,
        "title": """Rotated Letters""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 35,
        "hint_cost": 5,
        "description": """This flag has had every letter rotated by a fixed, famous amount:

synt{pnrfne_ol_nal_bgure_anzr}

Recover the original flag.""",
        "filename": """chal33.txt""",
        "flag": """flag{caesar_by_any_other_name}""",
        "hint": """This is the classic 13-shift Caesar cipher — applying it twice gets you back to the original text, so you can decode it the same way you'd encode it.""",
        "writeup": """Category: Cryptography | Difficulty: Easy

Approach that solves this challenge:
This is the classic 13-shift Caesar cipher — applying it twice gets you back to the original text, so you can decode it the same way you'd encode it.


Flag: flag{caesar_by_any_other_name}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 34,
        "title": """Shifting Keys""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 90,
        "hint_cost": 14,
        "description": """This note is encrypted with a Vigenere cipher — a repeating-key version of the
Caesar cipher where each letter is shifted by a different amount depending on
a keyword. Non-letter characters (like { and }) are left unchanged, which
is a big clue about where the flag's structure sits.

Ciphertext: plrg{isgvnrbe_berzs_jepbeks_yynxee}
Key length: 5

Crack the key and decode the message.""",
        "filename": """chal34.txt""",
        "flag": """flag{vigenere_keeps_secrets_longer}""",
        "hint": """You know the plaintext starts with 'flag{' and ends with '}' (braces aren't shifted since they're not letters) — that alone can reveal the first few key letters. Key length is given; brute-forcing a 5-letter key alphabetically is very feasible by hand or script.""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
You know the plaintext starts with 'flag{' and ends with '}' (braces aren't shifted since they're not letters) — that alone can reveal the first few key letters. Key length is given; brute-forcing a 5-letter key alphabetically is very feasible by hand or script.


Flag: flag{vigenere_keeps_secrets_longer}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 35,
        "title": """Repeating XOR""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This flag was XORed against a short repeating key, then hex-encoded:

085f150948060b43475a474500542b1603063102073140001c5615036c175f431c0b412b020213064709

The plaintext is known to start with "flag{" — use that as a crib to recover
the key, then decrypt the rest.""",
        "filename": """chal35.txt""",
        "flag": """flag{rep34t1ng_x0r_1s_stream_c1pher_l1ght}""",
        "hint": """XOR the first few hex bytes against the known plaintext 'flag{' to recover the key bytes, then repeat that key across the whole ciphertext (XOR is symmetric — same operation decrypts).""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
XOR the first few hex bytes against the known plaintext 'flag{' to recover the key bytes, then repeat that key across the whole ciphertext (XOR is symmetric — same operation decrypts).


Flag: flag{rep34t1ng_x0r_1s_stream_c1pher_l1ght}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 36,
        "title": """Scrambled Alphabet""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 95,
        "hint_cost": 14,
        "description": """Every letter in this message has been swapped for a different, fixed letter
throughout (a simple substitution cipher, not a shift) — spaces are kept as-is:

sfscz osuusc laye uq a nwvvscsku osuusc xqkeweuskuoz

It's plain English once decoded. Frequency analysis (which letters appear
most often, common short words like 'a' and 'to') will crack it. Submit the
flag using the decoded words joined with underscores inside flag{...}.""",
        "filename": """chal36.txt""",
        "flag": """flag{every_letter_maps_to_a_different_letter_consistently}""",
        "hint": """Count letter frequency — the most common cipher letter is probably standing in for 'e', the most common letter in English. Single-letter words are almost always 'a' or 'I'.""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
Count letter frequency — the most common cipher letter is probably standing in for 'e', the most common letter in English. Single-letter words are almost always 'a' or 'I'.


Flag: flag{every_letter_maps_to_a_different_letter_consistently}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 37,
        "title": """Bit Rotation""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 95,
        "hint_cost": 14,
        "description": """Each byte of this flag had its bits rotated left by a small fixed amount,
then the result was hex-encoded:

33630b3bdb9381a30ba389733bfa1389a39bfa899bfa53ab9ba3fa6b81932bfa6ba1a343eb

Figure out the rotation amount and rotate each byte back (right) to recover
the text.""",
        "filename": """chal37.txt""",
        "flag": """flag{r0tat1ng_b1ts_1s_just_m0re_m4th}""",
        "hint": """A left bit-rotation by N is undone by a right bit-rotation by the same N (within an 8-bit byte). Try small values of N (1 through 7) with a short Python script until the output looks like readable ASCII starting with 'flag{'.""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
A left bit-rotation by N is undone by a right bit-rotation by the same N (within an 8-bit byte). Try small values of N (1 through 7) with a short Python script until the output looks like readable ASCII starting with 'flag{'.


Flag: flag{r0tat1ng_b1ts_1s_just_m0re_m4th}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 38,
        "title": """Two Layers Deep""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This flag went through two simple transforms before being saved:

fWduaXRzZXJldG5pX3RpX2VrYW1fc3JleWFse2dhbGY=

Decode the outer layer first, then figure out what's left to undo.""",
        "filename": """chal38.txt""",
        "flag": """flag{layers_make_it_interesting}""",
        "hint": """Base64-decode it first — the result will be readable-ish but backwards. Then reverse the string.""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
Base64-decode it first — the result will be readable-ish but backwards. Then reverse the string.


Flag: flag{layers_make_it_interesting}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 39,
        "title": """Triple Wrap""",
        "category": """Cryptography""",
        "difficulty": """Hard""",
        "points": 140,
        "hint_cost": 21,
        "description": """This one is wrapped three times: base64, then XOR with a short repeating key,
then base64 again:

IBUCECBLDgIePzwSGwI8DSBJQxQYFTcPIDw8DSBLNB4jL08TIko3ABk/EhQZFjRB

You know the FINAL plaintext (after fully unwrapping) starts with "flag{" — and
so does the middle layer (since base64 of "flag{..." has a predictable start
too). Use that to find the XOR key, then peel each layer off in order.""",
        "filename": """chal39.txt""",
        "flag": """flag{stack1ng_enc0d1ngs_and_c1phers}""",
        "hint": """Outer base64-decode first to get the XORed bytes. The inner plaintext (before the XOR) is itself base64 text, which always starts with predictable characters for text beginning 'flag{' — use that as your known-plaintext crib against the XORed bytes to find the key.""",
        "writeup": """Category: Cryptography | Difficulty: Hard

Approach that solves this challenge:
Outer base64-decode first to get the XORed bytes. The inner plaintext (before the XOR) is itself base64 text, which always starts with predictable characters for text beginning 'flag{' — use that as your known-plaintext crib against the XORed bytes to find the key.


Flag: flag{stack1ng_enc0d1ngs_and_c1phers}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 40,
        "title": """Raw Bytes""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 70,
        "hint_cost": 10,
        "description": """This is a raw binary file, not text — opening it in a normal text editor will
show garbage. The flag is embedded somewhere inside as plain ASCII, surrounded
by junk bytes and markers.""",
        "filename": """chal40.bin""",
        "flag": """flag{raw_byt3s_dont_care_about_text_editors}""",
        "hint": """Use `strings chal40.bin` to pull out readable text segments, or `xxd chal40.bin | less` to eyeball the hex/ASCII side-by-side view. Look between the --FLAG-- and --ENDFLAG-- markers.""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
Use `strings chal40.bin` to pull out readable text segments, or `xxd chal40.bin | less` to eyeball the hex/ASCII side-by-side view. Look between the --FLAG-- and --ENDFLAG-- markers.


Flag: flag{raw_byt3s_dont_care_about_text_editors}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 41,
        "title": """Needle in the Binary""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """A raw binary blob. Somewhere inside it is a readable ASCII string — the flag —
surrounded by non-printable bytes.""",
        "filename": """chal41.bin""",
        "flag": """flag{strings_f1nds_wh4t_eyes_m1ss}""",
        "hint": """`strings chal41.bin` extracts all printable-ASCII runs from a binary file. The flag will be one of them.""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
`strings chal41.bin` extracts all printable-ASCII runs from a binary file. The flag will be one of them.


Flag: flag{strings_f1nds_wh4t_eyes_m1ss}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 42,
        "title": """Past the End""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """A log file that looks like it ends cleanly with '=== END OF LOG ==='. Most
people would stop reading there. Don't.""",
        "filename": """chal42.log""",
        "flag": """flag{data_after_the_end_1s_st1ll_data}""",
        "hint": """Open the raw bytes (cat -A, or `strings`, or just scroll past the visible end in a hex viewer) — there's more content appended after what looks like the natural end of the file.""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
Open the raw bytes (cat -A, or `strings`, or just scroll past the visible end in a hex viewer) — there's more content appended after what looks like the natural end of the file.


Flag: flag{data_after_the_end_1s_st1ll_data}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 43,
        "title": """Backwards File""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 30,
        "hint_cost": 5,
        "description": """This text file's entire content has been reversed character by character:

}oot_der0rr1m_eb_n4c_stn3tnoc_elif{galf

Reverse it back to read the flag.""",
        "filename": """chal43.txt""",
        "flag": """flag{file_cont3nts_c4n_be_m1rr0red_too}""",
        "hint": """`rev chal43.txt` on Linux reverses each line, or just reverse the string by hand/Python: text[::-1].""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
`rev chal43.txt` on Linux reverses each line, or just reverse the string by hand/Python: text[::-1].


Flag: flag{file_cont3nts_c4n_be_m1rr0red_too}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 44,
        "title": """Not Actually a Text File""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """This file is named chal44.txt, but opening it in a text editor shows garbled
binary junk instead of text. The extension is lying to you.""",
        "filename": """chal44.txt""",
        "flag": """flag{extens10ns_are_just_s4ggest10ns}""",
        "hint": """Run `file chal44.txt` to see what the file ACTUALLY is based on its magic bytes, regardless of its name. Rename it (or just unzip it directly) to extract the real content.""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
Run `file chal44.txt` to see what the file ACTUALLY is based on its magic bytes, regardless of its name. Rename it (or just unzip it directly) to extract the real content.


Flag: flag{extens10ns_are_just_s4ggest10ns}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 45,
        "title": """Matryoshka Archive""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 70,
        "hint_cost": 10,
        "description": """A zip file containing a zip file containing a zip file containing the flag.
Keep extracting until there's nothing left to extract.""",
        "filename": """chal45.zip""",
        "flag": """flag{n3sted_arch1ves_take_pat1ence}""",
        "hint": """`unzip chal45.zip`, then unzip whatever comes out of that, and repeat. Three layers total.""",
        "writeup": """Category: Forensics | Difficulty: Medium

Approach that solves this challenge:
`unzip chal45.zip`, then unzip whatever comes out of that, and repeat. Three layers total.


Flag: flag{n3sted_arch1ves_take_pat1ence}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 46,
        "title": """Weak Password Zip""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 65,
        "hint_cost": 10,
        "description": """A password-protected zip archive. The password is short and was reused from a
common CTF convention — a small wordlist or a bit of guessing will crack it.""",
        "filename": """chal46.zip""",
        "flag": """flag{weak_z1p_passw0rds_fall_f4st}""",
        "hint": """Try `zip2john chal46.zip > hash.txt && john hash.txt` if you have John the Ripper, or just try common CTF-style passwords by hand (year + event name style guesses) with `unzip -P <guess> chal46.zip`.""",
        "writeup": """Category: Forensics | Difficulty: Medium

Approach that solves this challenge:
Try `zip2john chal46.zip > hash.txt && john hash.txt` if you have John the Ripper, or just try common CTF-style passwords by hand (year + event name style guesses) with `unzip -P <guess> chal46.zip`.


Flag: flag{weak_z1p_passw0rds_fall_f4st}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 47,
        "title": """Haystack Log""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """A 300-line server log file, almost entirely routine heartbeat messages. One
line, somewhere in the middle, is different and contains the flag.""",
        "filename": """chal47.log""",
        "flag": """flag{grep_1s_f4ster_than_sc0ll1ng}""",
        "hint": """Don't scroll through 300 lines by eye. `grep flag chal47.log` (or `grep -i flag`) finds the one line that matters instantly.""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
Don't scroll through 300 lines by eye. `grep flag chal47.log` (or `grep -i flag`) finds the one line that matters instantly.


Flag: flag{grep_1s_f4ster_than_sc0ll1ng}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 48,
        "title": """Hexdump Reconstruction""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 60,
        "hint_cost": 9,
        "description": """This file is a hex dump (offset, hex bytes, ASCII preview) — the kind of output
you'd get from a tool like `xxd`. Reconstruct the original text from the hex
bytes shown.""",
        "filename": """chal48.txt""",
        "flag": """flag{xxd_turns_hex_back_1nto_text}""",
        "hint": """The ASCII column on the right already shows most of it readably, but if any bytes render as '.', convert those specific hex pairs by hand (or write a quick script) to be sure you have it exactly right.""",
        "writeup": """Category: Forensics | Difficulty: Medium

Approach that solves this challenge:
The ASCII column on the right already shows most of it readably, but if any bytes render as '.', convert those specific hex pairs by hand (or write a quick script) to be sure you have it exactly right.


Flag: flag{xxd_turns_hex_back_1nto_text}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 49,
        "title": """Binary Noise""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 55,
        "hint_cost": 8,
        "description": """A file of mostly random binary noise. A readable marker-wrapped flag is
buried in the middle, but normal `grep` might refuse to search a file it
thinks is binary.""",
        "filename": """chal49.dat""",
        "flag": """flag{grep_dash_a_reads_b1n4ry_as_text}""",
        "hint": """`grep -a flag chal49.dat` forces grep to treat the file as text even though it looks binary. Or just use `strings chal49.dat | grep flag`.""",
        "writeup": """Category: Forensics | Difficulty: Medium

Approach that solves this challenge:
`grep -a flag chal49.dat` forces grep to treat the file as text even though it looks binary. Or just use `strings chal49.dat | grep flag`.


Flag: flag{grep_dash_a_reads_b1n4ry_as_text}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 50,
        "title": """The Full Chain""",
        "category": """Forensics""",
        "difficulty": """Hard""",
        "points": 120,
        "hint_cost": 18,
        "description": """A zip archive containing a README and a 'photo.jpg' that refuses to open in
any image viewer. Figure out what it actually is, extract what's really
inside, and decode the final layer to get the flag.""",
        "filename": """chal50.zip""",
        "flag": """flag{ch4ined_steps_are_the_real_ctf}""",
        "hint": """Unzip the outer archive first. Then run `file photo.jpg` — its real type will not be JPEG. Rename/treat it as what `file` says it is, extract again, and you'll find one more encoding layer (a very recognizable text-safe one) to undo before you see 'flag{'.""",
        "writeup": """Category: Forensics | Difficulty: Hard

Approach that solves this challenge:
Unzip the outer archive first. Then run `file photo.jpg` — its real type will not be JPEG. Rename/treat it as what `file` says it is, extract again, and you'll find one more encoding layer (a very recognizable text-safe one) to undo before you see 'flag{'.

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{ch4ined_steps_are_the_real_ctf}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 51,
        "title": """Chain Gate I: The Easy Door""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 50,
        "hint_cost": 8,
        "description": """First half of a two-stage binary. Pass one argument and crack the first password to get this stage's flag. Pay close attention to the output once you're in -- it hints at more.""",
        "filename": """chain_re""",
        "flag": """flag{chain_stage1_found_the_easy_door}""",
        "hint": """Straightforward strcmp against argv[1]. strings on the binary shows it directly.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy

Approach that solves this challenge:
Straightforward strcmp against argv[1]. strings on the binary shows it directly.

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{chain_stage1_found_the_easy_door}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 52,
        "title": """Chain Gate II: Going Deeper""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This is STAGE 2 of the SAME binary as 'Chain Gate I' (download that one first if you haven't). Once you have stage 1's password, pass it as the first argument AND figure out a second password derived from it to pass as the second argument:

    ./chain_re <stage1_password> <stage2_password>

The second password isn't stored as its own plain string -- it's generated FROM the first one by a simple transform. This is real bug-chaining practice: one finding (stage 1's password) becomes the input you need to work out stage 2.""",
        "filename": """chain_re""",
        "flag": """flag{chain_stage2_went_deeper_than_most}""",
        "hint": """The stage-2 check compares argv[2] against a Caesar-shifted version of the stage-1 password (shift of 1). Apply that same shift to the password you already found.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium

Approach that solves this challenge:
The stage-2 check compares argv[2] against a Caesar-shifted version of the stage-1 password (shift of 1). Apply that same shift to the password you already found.

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{chain_stage2_went_deeper_than_most}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 53,
        "title": """Chain Cipher I: The Key Inside""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """A base64-encoded note:

ZmxhZ3tjaGFpbl9jcnlwdG9fZGVjb2RlX21lX2ZpcnN0fQpLRVk6Q0hBSU5LRVk5OQo=

Decode it. Besides the flag, it contains something else you'll need for the NEXT challenge -- don't throw it away.""",
        "filename": """chain_crypto1.txt""",
        "flag": """flag{chain_crypto_decode_me_first}""",
        "hint": """Standard base64 decode. The decoded text has two lines: the flag, and a line starting with 'KEY:' -- remember that key.""",
        "writeup": """Category: Cryptography | Difficulty: Easy

Approach that solves this challenge:
Standard base64 decode. The decoded text has two lines: the flag, and a line starting with 'KEY:' -- remember that key.

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{chain_crypto_decode_me_first}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 54,
        "title": """Chain Cipher II: Using the Clue""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 90,
        "hint_cost": 14,
        "description": """This file is encrypted with a repeating-key XOR, hex-encoded:

2524202e35282d3850571c2b33303e3f2a064c4a262c1e3d262e1a3a554c26173526112d2c37504a2b35

You don't need to brute-force the key -- you already found it while solving 'Chain Cipher I'. Use that key to decrypt this one.""",
        "filename": """chain_crypto2.txt""",
        "flag": """flag{chain_crypto_used_the_clue_to_finish}""",
        "hint": """Hex-decode first, then XOR against the key you extracted from the first challenge's decoded note (repeating it across all bytes).""",
        "writeup": """Category: Cryptography | Difficulty: Medium

Approach that solves this challenge:
Hex-decode first, then XOR against the key you extracted from the first challenge's decoded note (repeating it across all bytes).

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{chain_crypto_used_the_clue_to_finish}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 55,
        "title": """Chain Box I: The Outer Box""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """A zip archive. Extract it and read what's inside -- it has this stage's flag, plus something you'll need for the next one.""",
        "filename": """chain_box1.zip""",
        "flag": """flag{chain_forensics_opened_the_outer_box}""",
        "hint": """unzip it and read README.txt. It directly tells you the password needed for 'Chain Box II'.""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
unzip it and read README.txt. It directly tells you the password needed for 'Chain Box II'.

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{chain_forensics_opened_the_outer_box}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 56,
        "title": """Chain Box II: The Inner Vault""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 55,
        "hint_cost": 8,
        "description": """A password-protected zip. You don't need to crack this password by brute force -- it was handed to you in 'Chain Box I'.""",
        "filename": """chain_box2.zip""",
        "flag": """flag{chain_forensics_cracked_the_inner_vault}""",
        "hint": """unzip -P <password> chain_box2.zip, using the exact password string you found in README.txt from the previous challenge.""",
        "writeup": """Category: Forensics | Difficulty: Easy

Approach that solves this challenge:
unzip -P <password> chain_box2.zip, using the exact password string you found in README.txt from the previous challenge.

This is deliberate bug-chaining practice: a real vulnerability research engagement rarely ends at one finding. One weakness (or one decoded clue) becomes the key that unlocks the next stage. Training yourself to carry findings forward, rather than treating each bug in isolation, is exactly the muscle real zero-day hunting needs.

Flag: flag{chain_forensics_cracked_the_inner_vault}""",
        "is_network": 0,
        "port": 0,
    },
    {
        "id": 57,
        "title": """Remote Access Gate""",
        "category": """Network""",
        "difficulty": """Easy""",
        "points": 60,
        "hint_cost": 9,
        "description": """This challenge is NOT a file to download — it's a live service running on this machine. Connect to it with netcat:

    nc 127.0.0.1 9101

It's the same kind of password-gate logic you've already cracked locally, but now you're interacting with it over a network socket, exactly like a real remote CTF pwn challenge. You still need to find the password — but this time there's no binary to download and reverse engineer first, so think about what else could reveal it, or just try common passwords referencing this platform/year.""",
        "filename": """net57""",
        "flag": """flag{nc_is_your_first_remote_tool}""",
        "hint": """This service is started automatically by start_ctf.sh in the background. If 'nc 127.0.0.1 9101' refuses to connect, the service may not be running yet — check that start_ctf.sh's output mentioned starting network services. The password itself follows a 'word_word_year' pattern themed around this exact feature (remote access).""",
        "writeup": """Category: Network | Difficulty: Easy

Approach that solves this challenge:
This service is started automatically by start_ctf.sh in the background. If 'nc 127.0.0.1 9101' refuses to connect, the service may not be running yet — check that start_ctf.sh's output mentioned starting network services. The password itself follows a 'word_word_year' pattern themed around this exact feature (remote access).

This is exactly how real remote CTF infrastructure works: a vulnerable program's stdin/stdout piped straight to a TCP socket. Everything you know about exploiting a local binary transfers directly -- you just send your input over the wire instead of to a local process.

Flag: flag{nc_is_your_first_remote_tool}""",
        "is_network": 1,
        "port": 9101,
    },
    {
        "id": 58,
        "title": """Remote Overflow""",
        "category": """Network""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """Another live service, no file to download:

    nc 127.0.0.1 9102

This is the exact same unbounded scanf() stack-overflow pattern from the local 'Overflow' challenges you already solved — except now you're sending your overflow payload over a socket connection instead of piping it to a local binary. The same offset-finding approach applies: feed it progressively longer input over the connection and watch when the locked message flips.""",
        "filename": """net58""",
        "flag": """flag{overflow_works_the_same_over_a_socket}""",
        "hint": """You can pipe input into nc the same way you piped it into the local binary: python3 -c "print('A'*90)" | nc 127.0.0.1 9102   — try a few different lengths around 60-100 characters until the integer right after the buffer flips to nonzero.""",
        "writeup": """Category: Network | Difficulty: Medium

Approach that solves this challenge:
You can pipe input into nc the same way you piped it into the local binary: python3 -c "print('A'*90)" | nc 127.0.0.1 9102   — try a few different lengths around 60-100 characters until the integer right after the buffer flips to nonzero.

This is exactly how real remote CTF infrastructure works: a vulnerable program's stdin/stdout piped straight to a TCP socket. Everything you know about exploiting a local binary transfers directly -- you just send your input over the wire instead of to a local process.

Flag: flag{overflow_works_the_same_over_a_socket}""",
        "is_network": 1,
        "port": 9102,
    },
]

def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS challenges (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            difficulty TEXT NOT NULL,
            points INTEGER NOT NULL,
            hint_cost INTEGER NOT NULL DEFAULT 0,
            description TEXT NOT NULL,
            filename TEXT NOT NULL,
            flag_hash TEXT NOT NULL,
            hint TEXT,
            writeup TEXT,
            is_network INTEGER NOT NULL DEFAULT 0,
            port INTEGER NOT NULL DEFAULT 0
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS solves (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            challenge_id INTEGER NOT NULL,
            solved_at TEXT NOT NULL,
            UNIQUE(challenge_id)
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS hints_used (
            challenge_id INTEGER PRIMARY KEY,
            used_at TEXT NOT NULL
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS views (
            challenge_id INTEGER PRIMARY KEY,
            first_viewed_at TEXT NOT NULL
        )
    ''')
    for c in CHALLENGES:
        cur.execute('''
            INSERT INTO challenges
                (id, title, category, difficulty, points, hint_cost, description, filename,
                 flag_hash, hint, writeup, is_network, port)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title=excluded.title, category=excluded.category, difficulty=excluded.difficulty,
                points=excluded.points, hint_cost=excluded.hint_cost, description=excluded.description,
                filename=excluded.filename, flag_hash=excluded.flag_hash, hint=excluded.hint,
                writeup=excluded.writeup, is_network=excluded.is_network, port=excluded.port
        ''', (c["id"], c["title"], c["category"], c["difficulty"], c["points"], c["hint_cost"],
              c["description"], c["filename"], flag_hash(c["flag"]), c["hint"], c["writeup"],
              c["is_network"], c["port"]))
    conn.commit()
    conn.close()
    print(f"Seeded {len(CHALLENGES)} challenges into {DB_PATH}")

if __name__ == "__main__":
    main()
