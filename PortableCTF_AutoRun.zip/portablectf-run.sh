#!/usr/bin/env bash
# Runs as root under a systemd transient unit (started by udev on plug-in).
# Mounts the pendrive and runs start_ctf.sh in the foreground, so stopping
# this unit (on unplug) cleanly tears down everything underneath it too.
set -e

DEVNAME="$1"     # e.g. /dev/sdb1
MOUNT="/mnt/pendrive"
PROJECT_DIR="PortableCTF"   # folder name inside the pendrive

mkdir -p "$MOUNT"
mount "$DEVNAME" "$MOUNT"

cd "$MOUNT/$PROJECT_DIR"
exec ./start_ctf.sh
