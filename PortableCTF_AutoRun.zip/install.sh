#!/usr/bin/env bash
# Run ONCE on your Kali laptop (as root / with sudo) to install the
# plug-in-and-it-just-works automation for PortableCTF.
set -e

if [ "$EUID" -ne 0 ]; then
    echo "Run this with sudo: sudo ./install.sh"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[*] Installing scripts to /usr/local/bin ..."
install -m 755 "$SCRIPT_DIR/portablectf-run.sh" /usr/local/bin/portablectf-run.sh
install -m 755 "$SCRIPT_DIR/portablectf-udev-add.sh" /usr/local/bin/portablectf-udev-add.sh
install -m 755 "$SCRIPT_DIR/portablectf-udev-remove.sh" /usr/local/bin/portablectf-udev-remove.sh

echo "[*] Installing udev rule ..."
install -m 644 "$SCRIPT_DIR/99-portablectf.rules" /etc/udev/rules.d/99-portablectf.rules

echo "[*] Reloading udev rules ..."
udevadm control --reload-rules
udevadm trigger

echo ""
echo "Done! Make sure your pendrive's ext4 partition has the label CTFDRIVE:"
echo "    lsblk -f"
echo "(If it doesn't, relabel it with: sudo e2label /dev/sdXN CTFDRIVE)"
echo ""
echo "Also make sure the folder name inside the pendrive is exactly 'PortableCTF'"
echo "(i.e. /PortableCTF/start_ctf.sh must exist at the pendrive's root)."
echo ""
echo "From now on: plug the pendrive in, wait ~2-3 seconds, then open"
echo "http://127.0.0.1:5000 in your browser. Unplug it and everything stops"
echo "and unmounts on its own."
