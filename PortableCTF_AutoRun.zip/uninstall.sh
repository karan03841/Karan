#!/usr/bin/env bash
# Removes the auto-run automation completely, if you ever want to go back
# to the manual "ctf" command (or plain mount/cd/run).
set -e

if [ "$EUID" -ne 0 ]; then
    echo "Run this with sudo: sudo ./uninstall.sh"
    exit 1
fi

rm -f /etc/udev/rules.d/99-portablectf.rules
rm -f /usr/local/bin/portablectf-run.sh
rm -f /usr/local/bin/portablectf-udev-add.sh
rm -f /usr/local/bin/portablectf-udev-remove.sh
systemctl stop portablectf 2>/dev/null || true
udevadm control --reload-rules

echo "Auto-run automation removed."
