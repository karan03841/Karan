PortableCTF — Fully Automatic Plug/Unplug (udev + systemd)
=============================================================

What this does
---------------
- Plug the pendrive in  -> within a couple seconds, Linux auto-mounts it,
  auto-starts the two network challenge services AND the web app.
- Unplug the pendrive    -> everything stops and unmounts itself. Nothing
  stays running, nothing stays mounted. Exactly what you asked for.

You just open http://127.0.0.1:5000 in your browser after plugging in —
that one click is the only manual step left (auto-launching a browser
from a background root process is unreliable across desktop setups, so
it's intentionally left out rather than giving you something flaky).

How it works (so you're not just copy-pasting blind)
------------------------------------------------------
1. A udev rule watches for any block device appearing with filesystem
   label "CTFDRIVE" (the label you already set with mkfs.ext4 -L CTFDRIVE).
2. When it appears, udev runs portablectf-udev-add.sh, which starts a
   tracked systemd service ("portablectf") running portablectf-run.sh.
3. portablectf-run.sh mounts the drive to /mnt/pendrive and runs
   start_ctf.sh from inside it (same script as before — it still creates
   its own venv on the pendrive the first time, starts the two nc
   services, then starts the Flask app).
4. When you unplug, udev fires a "remove" event. portablectf-udev-remove.sh
   checks if the removed device matches what was recorded, and if so stops
   the "portablectf" systemd service (which kills start_ctf.sh and
   everything under it -- Flask + both network bridges) and unmounts.

One-time install (on your Kali laptop)
-----------------------------------------
1. Extract this whole AutoRunSetup folder somewhere on your Kali laptop
   (NOT on the pendrive -- this must live on the laptop itself).
2. Double-check your pendrive's partition is labeled CTFDRIVE:
       lsblk -f
   If it isn't, label it:
       sudo e2label /dev/sdXN CTFDRIVE
3. Double-check the folder on the pendrive is named exactly "PortableCTF"
   at the pendrive's root (i.e. mounting the drive should show
   <mountpoint>/PortableCTF/start_ctf.sh).
4. Run:
       cd AutoRunSetup
       sudo ./install.sh

That's it. From now on: plug in -> wait a couple seconds -> open browser.
Unplug -> it's gone, like it was never there.

Uninstalling
-------------
    cd AutoRunSetup
    sudo ./uninstall.sh

Troubleshooting
-----------------
- Nothing happens when you plug in: check `lsblk -f` shows label CTFDRIVE
  on the right partition, and run `sudo udevadm monitor` while plugging in
  to see if the ADD event fires at all (hardware/driver issue if not).
- Check if the service is running: `systemctl status portablectf`
- See its live output: `journalctl -u portablectf -f`
- If www.start_ctf.sh errors out (e.g. missing python3-venv), the systemd
  unit will just exit -- check the journalctl output above for the real
  error, fix it, then unplug/replug to retry.
- "Address already in use" on port 5000 after re-plugging quickly: the old
  service may still be shutting down; wait a couple seconds and retry, or
  run `sudo systemctl stop portablectf` manually first.
