#!/usr/bin/env bash
# Called by udev the instant the CTFDRIVE-labeled partition appears.
# Records the device node, then launches the real mount+run script as a
# tracked systemd transient unit (so we can cleanly stop it later on unplug).
DEVNAME="/dev/$1"   # udev passes the kernel name, e.g. sdb1

echo "$DEVNAME" > /run/portablectf.dev

systemd-run --unit=portablectf --collect --quiet \
    /usr/local/bin/portablectf-run.sh "$DEVNAME"
