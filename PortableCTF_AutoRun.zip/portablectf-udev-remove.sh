#!/usr/bin/env bash
# Called by udev on EVERY block device removal (remove events can't see the
# filesystem label anymore, so we check against what we recorded at mount time).
KERNEL_NAME="$1"      # udev passes e.g. sdb1
CANDIDATE="/dev/$KERNEL_NAME"
RECORDED="$(cat /run/portablectf.dev 2>/dev/null || true)"

if [ -n "$RECORDED" ] && [ "$RECORDED" = "$CANDIDATE" ]; then
    systemctl stop portablectf 2>/dev/null || true
    umount -l /mnt/pendrive 2>/dev/null || true
    rm -f /run/portablectf.dev
fi
