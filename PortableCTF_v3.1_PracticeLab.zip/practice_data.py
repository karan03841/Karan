# -*- coding: utf-8 -*-
"""Static content for the Practice Lab -- a non-scored, no-pressure learning
section inside PortableCTF. No DB rows, no flags to submit to a server:
every "reveal answer" here is plain client-side <details>, so it works
100% offline with zero extra backend state. Order is easiest -> hardest,
matching the main CTF's own progressive-difficulty philosophy."""

MODULES = [
    dict(
        slug="static-recon",
        level=1,
        difficulty="Easy",
        color="cat0",
        title="Static Recon",
        tagline="Read a binary without ever running it.",
        tools=["file", "strings", "objdump", "readelf", "nm", "ldd"],
        tutorial=[
            ("What \"static analysis\" means",
             "Static analysis = learning everything you can about a program by reading its bytes on "
             "disk, never executing it. It's always your first move on an unknown binary, because "
             "running something you don't understand yet can be risky, and because a lot of useful "
             "information (readable text, library dependencies, function names) is sitting right "
             "there in the file whether you run it or not."),
            ("file &mdash; identify what you're even looking at",
             "<code>file password_checker_debug</code> tells you the architecture (x86-64), whether "
             "it's dynamically or statically linked, and whether debug info / symbols are still "
             "present. Always your very first command on any new file."),
            ("strings &mdash; find human-readable text",
             "<code>strings password_checker_debug</code> prints every run of printable characters in "
             "the file. Error messages, format strings, and sometimes secrets a developer forgot to "
             "remove, all live here. Add <code>-n 8</code> to only show strings 8+ characters long and "
             "cut down noise; pipe into <code>| less</code> or <code>| grep -i pass</code> to search."),
            ("objdump -d &mdash; disassemble the code",
             "<code>objdump -d password_checker_debug</code> shows every function as x86-64 assembly "
             "(AT&amp;T syntax by default). Add <code>-M intel</code> for Intel syntax if you find that "
             "easier to read (<code>objdump -d -M intel password_checker_debug</code>)."),
            ("readelf -h / -d &mdash; inspect the ELF structure itself",
             "<code>readelf -h password_checker_debug</code> shows the ELF header (entry point, type, "
             "architecture). <code>readelf -d password_checker_debug</code> shows dynamic section info "
             "-- which shared libraries it needs at runtime."),
            ("nm &mdash; list symbols",
             "<code>nm password_checker_debug</code> lists function and variable names compiled into "
             "the binary. Try the exact same command on <code>password_checker_stripped</code> and "
             "compare the output -- that difference *is* what \"stripped\" means."),
            ("ldd &mdash; shared library dependencies",
             "<code>ldd password_checker_debug</code> lists which shared libraries (like libc) the "
             "binary needs at runtime and where they resolve to on this system."),
        ],
        task=(
            "Two binaries are provided: <code>password_checker_debug</code> (compiled normally) and "
            "<code>password_checker_stripped</code> (compiled identically, then stripped of symbols). "
            "Both take one command-line argument -- an access code. <strong>Without running either "
            "program</strong>, use the tools above to find the exact access code both binaries are "
            "checking for. Do it on the stripped one too, not just the debug build -- that's the "
            "real point of this exercise."
        ),
        commands=[
            "file password_checker_debug password_checker_stripped",
            "nm password_checker_debug      # compare this...",
            "nm password_checker_stripped   # ...against this",
            "strings -n 5 password_checker_stripped | grep -vi usage",
            "objdump -d -M intel password_checker_stripped | less",
        ],
        hints=[
            "strings works on a stripped binary exactly the same as an unstripped one -- stripping "
            "removes the SYMBOL TABLE (function/variable names), not string literals sitting in the "
            ".rodata section. They're two completely different things.",
            "Scan the strings output for anything that doesn't look like a normal English sentence or "
            "format string (%s, Usage: etc). There's exactly one odd-looking word left over.",
        ],
        answer=(
            "The access code is <code>sunrise77</code>. Confirm it by actually running the program "
            "now that you've found it statically: <code>./password_checker_stripped sunrise77</code> "
            "&rarr; \"Access granted. Welcome back.\""
        ),
        files=["password_checker_debug", "password_checker_stripped"],
    ),
    dict(
        slug="assembly-reading",
        level=2,
        difficulty="Easy",
        color="cat0",
        title="Reading x86-64 Assembly",
        tagline="Turn cmp/jcc/jmp back into the if/loop/switch it came from.",
        tools=["objdump -d -M intel", "gdb disassemble"],
        tutorial=[
            ("The calling convention you need to know",
             "On x86-64 Linux (System V ABI), the first few function arguments are passed in "
             "registers, not on the stack: <code>rdi, rsi, rdx, rcx, r8, r9</code> in that order. For "
             "<code>main(int argc, char **argv)</code>, that means <code>edi</code> holds argc and "
             "<code>rsi</code> holds argv at function entry."),
            ("cmp + jcc = if/else",
             "<code>cmp eax, 0x12</code> followed by a conditional jump (<code>jl</code>, <code>jge</code>, "
             "<code>je</code>, <code>jne</code>...) is the assembly shape of an <code>if</code>. The "
             "constant being compared against (here, 0x12 = 18 decimal) is exactly the threshold the C "
             "source used."),
            ("A backward jmp/jcc = loop",
             "If you see a conditional jump whose target address is <em>earlier</em> in the "
             "disassembly than the jump instruction itself, that's a loop, not an if -- it's jumping "
             "backward to repeat a block of code."),
            ("A string of cmp/je pairs, or a jump table = switch",
             "A C <code>switch</code> statement compiles either to a chain of <code>cmp</code>/"
             "<code>je</code> pairs (for a few cases) or a jump table indexed by the switch value (for "
             "many sequential cases) -- <code>jmp [rax*8 + table_addr]</code> is the signature of a "
             "jump table."),
        ],
        task=(
            "Three small programs. For each one, determine the exact logic from the disassembly "
            "ALONE first (don't just run it and guess-and-check), then run it with different "
            "arguments to confirm you read it correctly: <code>age_eligibility_check</code> (find the "
            "exact age threshold), <code>repeated_greeting_loop</code> (find the default number of "
            "greetings printed when run with no arguments, and how the loop condition looks in "
            "assembly), <code>grade_lookup_switch</code> (find every grade boundary)."
        ),
        commands=[
            "objdump -d -M intel age_eligibility_check | less",
            "objdump -d -M intel repeated_greeting_loop | less",
            "objdump -d -M intel grade_lookup_switch | less",
            "./age_eligibility_check 17   # confirm your read once you have a theory",
            "./repeated_greeting_loop     # no args -- watch the default",
        ],
        hints=[
            "In age_eligibility_check, find the `cmp` right after argv is converted with atoi -- the "
            "hex constant it compares against IS the age threshold, just convert it from hex.",
            "In repeated_greeting_loop, a register gets initialized to a value, incremented each "
            "pass, and compared against another value before a backward conditional jump -- both of "
            "those values together tell you the default loop count.",
            "In grade_lookup_switch, the input is divided by 10 before the comparisons -- so each "
            "`cmp`/`je` case corresponds to a *range* of raw scores, not single values.",
        ],
        answer=(
            "Threshold is <strong>18</strong> (&ge;18 passes). Default loop count with no arguments is "
            "<strong>3</strong>. Grade boundaries: 90&ndash;100&nbsp;=&nbsp;A, 80s&nbsp;=&nbsp;B, "
            "70s&nbsp;=&nbsp;C, 60s&nbsp;=&nbsp;D, below&nbsp;60&nbsp;=&nbsp;F."
        ),
        files=["age_eligibility_check", "repeated_greeting_loop", "grade_lookup_switch"],
    ),
    dict(
        slug="ghidra-practice",
        level=3,
        difficulty="Medium",
        color="cat0",
        title="Ghidra Mastery",
        tagline="Let the decompiler turn stripped assembly back into readable C.",
        tools=["Ghidra (CodeBrowser)", "Decompile window", "Listing window", "Cross-References"],
        tutorial=[
            ("Import and auto-analyze",
             "Open Ghidra &rarr; File &rarr; New Project &rarr; Import File &rarr; pick the binary "
             "&rarr; double-click it in the project tree to open CodeBrowser &rarr; say Yes to "
             "\"Analyze?\" and accept the defaults. Wait for analysis to finish (progress bar, bottom "
             "right)."),
            ("Decompile + Listing side by side",
             "The Listing window (middle) shows raw disassembly; the Decompile window (right, or "
             "Window &rarr; Decompile if closed) shows Ghidra's best-effort reconstructed C. Click any "
             "function in the left-hand Symbol Tree &rarr; Functions list, or double-click a call in "
             "the listing, to jump both windows to it. Cross-check: when the decompiler's guess looks "
             "odd, the raw listing is the ground truth."),
            ("Renaming things as you figure them out",
             "Press <kbd>L</kbd> with a variable, parameter, or function name selected in either "
             "window to rename it. Do this constantly -- renaming <code>FUN_00101189</code> to "
             "<code>add_item</code> the moment you understand it makes every later cross-reference to "
             "it self-documenting."),
            ("Cross-references (XREFs)",
             "Right-click any function or variable &rarr; References &rarr; Show References To, (or "
             "just hover -- Ghidra shows an XREF count in the decompile view) to see every place that "
             "symbol is used elsewhere in the binary. Essential for figuring out which of several "
             "unnamed functions is the \"real\" entry point for a given feature."),
            ("Graph view",
             "Window &rarr; Function Graph shows a function's control flow as connected boxes -- "
             "often faster than reading raw disassembly to spot the overall if/loop/switch shape "
             "before diving into details."),
        ],
        task=(
            "Both binaries here are stripped (no symbol names) and multi-function. Open each in "
            "Ghidra, use the decompiler to work out what every function does, and rename the "
            "generic <code>FUN_xxxxxxxx</code> names to meaningful ones as you go. For "
            "<code>inventory_stock_manager</code>: identify the add/remove/check-stock functions "
            "and the usage pattern (<code>./inventory_stock_manager add 10</code>, etc). For "
            "<code>temperature_unit_converter</code>: recover the EXACT formula used in each "
            "direction (C&rarr;F and F&rarr;C) straight from the decompiled C, not from memory."
        ),
        commands=[
            "# all work for this level happens inside the Ghidra GUI, not the shell",
            "ghidraRun   # if Ghidra isn't already open",
        ],
        hints=[
            "Look for a function that does three strcmp()s against the literal strings \"add\", "
            "\"remove\", and anything else -- that's main(), and the strcmp targets tell you the exact "
            "three sub-commands.",
            "The decompiled temperature functions will show floating-point math with constants 9.0, "
            "5.0, and 32.0 -- which direction each shows up in (multiply-then-add vs subtract-then-"
            "multiply) tells you which formula is which without translating anything by hand.",
        ],
        answer=(
            "inventory_stock_manager takes <code>add &lt;qty&gt;</code>, <code>remove &lt;qty&gt;</code>, "
            "or <code>check</code> (default) as argv[1]/argv[2]. temperature_unit_converter: "
            "<code>F&nbsp;=&nbsp;C&nbsp;&times;&nbsp;9/5&nbsp;+&nbsp;32</code> for <code>c2f</code>, "
            "<code>C&nbsp;=&nbsp;(F&nbsp;&minus;&nbsp;32)&nbsp;&times;&nbsp;5/9</code> for <code>f2c</code>. "
            "Confirm: <code>./temperature_unit_converter c2f 100</code> &rarr; 212.00."
        ),
        files=["inventory_stock_manager", "temperature_unit_converter"],
    ),
    dict(
        slug="gdb-dynamic",
        level=4,
        difficulty="Medium",
        color="cat1",
        title="gdb Dynamic Analysis",
        tagline="Stop reading code and watch it run instead.",
        tools=["gdb", "break / run / next / step", "info registers", "x/ (examine memory)", "ltrace", "strace"],
        tutorial=[
            ("Starting gdb and setting a breakpoint",
             "<code>gdb ./secret_number_guesser</code> opens it. <code>disassemble main</code> (or "
             "<code>disas main</code>) shows main's assembly with addresses. Pick the address of the "
             "comparison instruction you care about, then <code>break *0x0000...1234</code> (or just "
             "<code>break main</code> to stop at the very start)."),
            ("Running and stepping",
             "<code>run</code> starts the program (stops at your breakpoint). <code>next</code> (or "
             "<code>n</code>) steps over one source/asm line without entering calls; <code>step</code> "
             "(<code>s</code>) steps INTO calls. <code>continue</code> (<code>c</code>) resumes until "
             "the next breakpoint or exit."),
            ("Inspecting registers and memory",
             "<code>info registers</code> dumps every general-purpose register's current value right "
             "where you're stopped -- this is how you read a value the program computed, instead of "
             "guessing it. <code>x/4dw $rsp</code> examines memory: <code>4</code> units, "
             "<code>d</code>ecimal format, <code>w</code>ord-sized (4 bytes), starting at the address "
             "in <code>$rsp</code> (the stack pointer). Swap <code>d</code> for <code>x</code> to see "
             "hex instead, or <code>s</code> for a string."),
            ("ltrace / strace -- a different angle entirely",
             "<code>ltrace ./binary</code> shows every library call (strcmp, printf, malloc...) the "
             "program makes, with its arguments -- often reveals secrets being compared without "
             "touching gdb at all. <code>strace ./binary</code> shows every system call (read, write, "
             "open...) instead -- useful for I/O-heavy programs."),
        ],
        task=(
            "<code>secret_number_guesser</code> picks a hidden 4-digit number and lets you guess it "
            "interactively forever (higher/lower hints) -- use gdb (or <code>ltrace</code>) to read "
            "the secret directly out of memory/registers instead of brute-force guessing in the "
            "terminal. <code>stack_buffer_peek_demo</code> has a local <code>buffer[16]</code> and a "
            "separate local <code>marker</code> variable living nearby on the stack -- use "
            "<code>x/</code> to find the marker's exact value without reading the (unavailable) "
            "source."
        ),
        commands=[
            "gdb ./secret_number_guesser",
            "(gdb) disas main",
            "(gdb) break *<address of the cmp against the secret>",
            "(gdb) run",
            "(gdb) info registers",
            "ltrace ./secret_number_guesser    # alternative: no gdb needed at all",
            "gdb ./stack_buffer_peek_demo -ex 'break show_buffer' -ex run -ex 'x/8dw $rsp'",
        ],
        hints=[
            "For secret_number_guesser: ltrace is the fast path here -- it will show the scanf and "
            "cmp-equivalent comparisons with their actual argument values as the program runs, no "
            "breakpoint math required.",
            "For stack_buffer_peek_demo: break right after the `strcpy` call so the buffer is already "
            "filled, then scan several words around $rsp with x/ -- the marker is a small plain int, "
            "so look for a suspiciously \"round\" 4-byte value sitting among the string bytes.",
        ],
        answer=(
            "secret_number_guesser's hidden value is <strong>8249</strong>. stack_buffer_peek_demo's "
            "marker is <strong>777333</strong> -- both are visible directly in memory without ever "
            "reading the (not provided) source code."
        ),
        files=["secret_number_guesser", "stack_buffer_peek_demo"],
    ),
    dict(
        slug="cipher-id",
        level=5,
        difficulty="Medium",
        color="cat2",
        title="Cipher &amp; Encoding Identification",
        tagline="Same hidden sentence, five different disguises. Learn to recognize each one on sight.",
        tools=["Python (binascii, codecs, base64)", "CyberChef (optional, offline copy if you have one)"],
        tutorial=[
            ("Recognize encodings by their character set, not by guessing",
             "This is the single most useful cipher-ID skill: look at WHICH characters appear before "
             "trying anything. Pure <code>0-9a-f</code> in pairs = hex. <code>A-Za-z0-9+/=</code> = "
             "base64. Only letters, spacing/punctuation preserved, nothing else moved = some kind of "
             "letter-shift (Caesar/ROT13/Vigenere/substitution)."),
            ("Reverse",
             "The simplest possible transform: <code>text[::-1]</code> in Python, or <code>rev</code> "
             "on the Linux command line for single lines."),
            ("Single-byte XOR",
             "<code>bytes(b ^ key for b in data)</code> -- if you know (or can guess) even a few bytes "
             "of the plaintext (a \"crib\"), XOR those plaintext bytes against the matching ciphertext "
             "bytes at the same position to recover the key directly."),
            ("Caesar-family shifts",
             "Classic Caesar only shifts <code>a-z</code>/<code>A-Z</code>; this platform's variant "
             "shifts the FULL printable ASCII range (32-126) with wraparound, so punctuation and "
             "spaces move too -- don't assume it's letters-only just because it looks like one."),
            ("Bit rotation",
             "Rotating every byte's bits left by N undoes with a right-rotation by the same N (mod "
             "8). If the ciphertext is hex-encoded bytes that don't decode to anything readable "
             "directly, try every rotation 1 through 7 after hex-decoding."),
            ("Fixed substitution cipher",
             "Every letter is swapped 1:1 for a different fixed letter (case preserved, everything "
             "else untouched) -- this is NOT a shift, so brute-forcing a shift amount won't work. "
             "Frequency analysis (the most common letter is probably 'e') is the real technique, "
             "though with a short message you may just recognize partial words."),
        ],
        task=(
            "All five files encode the SAME hidden sentence, each with one different technique. "
            "Identify and decode every one of them. Don't assume the file names are telling you the "
            "whole truth -- confirm by actually decoding, the same discipline you'd use on an unlabeled "
            "challenge."
        ),
        commands=[
            "python3 -c \"print(open('message_reversed_bytes.txt').read()[::-1])\"",
            "python3 -c \"d=bytes.fromhex(open('message_single_byte_xor.txt').read()); print(bytes(b^0x2B for b in d))\"  # once you find the key",
            "python3 -c \"import string; print(''.join(chr(32+(ord(c)-32-13)%95) if 32<=ord(c)<=126 else c for c in open('message_caesar_shift.txt').read()))\"",
            "python3 -c \"d=bytes.fromhex(open('message_bit_rotated_hex.txt').read()); print(bytes(((b>>3)|(b<<5))&0xFF for b in d))\"",
        ],
        hints=[
            "message_single_byte_xor.txt is hex-encoded bytes; you know (or can reasonably guess) the "
            "message starts with the word \"flag\" -- XOR the first few decoded bytes against that "
            "crib to get the single-byte key directly.",
            "message_caesar_shift.txt shifts the FULL ASCII range mod 95, not just letters -- try every "
            "shift 1-94 programmatically rather than by hand, and stop at the one producing normal "
            "English words.",
            "message_bit_rotated_hex.txt: it was rotated LEFT by 3 to encode, so decode with a RIGHT "
            "rotation by 3 after hex-decoding each byte.",
            "message_substitution_cipher.txt: the words are short and common enough that once you spot "
            "one real word (try matching 3-letter words to \"the\"/\"for\"/\"not\" etc) the rest of the "
            "table falls into place fast.",
        ],
        answer=(
            "All five decode to: <code>flag practice this is not a real flag just text for you to "
            "decode</code>."
        ),
        files=[
            "message_reversed_bytes.txt", "message_single_byte_xor.txt", "message_caesar_shift.txt",
            "message_bit_rotated_hex.txt", "message_substitution_cipher.txt",
        ],
    ),
    dict(
        slug="logic-puzzle-gates",
        level=6,
        difficulty="Hard",
        color="cat2",
        title="Logic Puzzle Gates",
        tagline="Four different \"unlock conditions\" -- static reading and live testing, mixed.",
        tools=["objdump / Ghidra", "gdb", "getenv / environment variables", "Python for brute force"],
        tutorial=[
            ("ASCII-sum / checksum gates",
             "Some gates sum the ASCII (byte) value of every character in your input and compare that "
             "total against a fixed target number -- infinitely many strings can satisfy one target "
             "sum, you just need any one that works."),
            ("getenv gates -- not argv!",
             "Some programs read a secret from an ENVIRONMENT VARIABLE with <code>getenv()</code>, "
             "not from a command-line argument or stdin at all. If a program's disassembly shows a "
             "call to <code>getenv@plt</code>, running it normally will never unlock it -- you need "
             "<code>VAR=value ./program</code> or <code>export VAR=value</code> first."),
            ("Interactive stdin prompts",
             "<code>scanf(\"%d\", &amp;pin)</code>-style programs want input typed in while they run, "
             "not as a command-line argument -- just run the program and type the answer when "
             "prompted."),
            ("Recursive math gates (Fibonacci etc.)",
             "A recursive function compiles into a function that calls itself -- recognizable in "
             "disassembly as a <code>call</code> to its own starting address. If a gate's condition is "
             "\"does fib(n) equal some fixed target\", you can solve it mathematically in Python "
             "(or even just by hand) far faster than brute-forcing n by running the binary "
             "repeatedly."),
        ],
        task=(
            "Find the correct unlocking input for all four programs: <code>checksum_lock</code> "
            "(what argv[1] makes the ASCII-sum match?), <code>env_var_secret_gate</code> (which "
            "environment variable, set to what value, unlocks it?), <code>interactive_stdin_prompt</code> "
            "(what PIN does it want, typed in live?), <code>fibonacci_sequence_gate</code> (what "
            "value of n makes fib(n) hit the target -- work this out mathematically, not by "
            "guessing)."
        ),
        commands=[
            "objdump -d -M intel env_var_secret_gate | grep -A3 getenv",
            "GATE_KEY=guess ./env_var_secret_gate",
            "./interactive_stdin_prompt   # then type a name and a pin when prompted",
            "python3 -c \"import sys;sys.setrecursionlimit(100)\\nfib=lambda n: n if n<2 else fib(n-1)+fib(n-2)\\nprint([n for n in range(40) if fib(n)==377])\"",
        ],
        hints=[
            "checksum_lock: any string whose characters sum to exactly 1186 works -- a quick Python "
            "loop building a string of repeated characters is the fastest way to find one.",
            "env_var_secret_gate: the disassembly calls getenv on a string you can read directly with "
            "strings/objdump -- that string IS the variable name to set.",
            "interactive_stdin_prompt: it asks for a name first (anything works) and THEN a 4-digit "
            "pin -- brute-forcing 0000-9999 by hand is impractical, but reading the stripped-down "
            "compare in objdump/Ghidra gives you the exact number instantly.",
            "fibonacci_sequence_gate: just compute fib(0) through fib(20) in Python and see which n "
            "gives exactly the gate's target -- far faster than running the binary 20 times.",
        ],
        answer=(
            "checksum_lock: any argv[1] whose bytes sum to 1186 (e.g. 14 copies of the character "
            "'Z' &#8776; 1162, adjust until exact). env_var_secret_gate: <code>GATE_KEY=midnight "
            "./env_var_secret_gate</code>. interactive_stdin_prompt: pin <strong>4321</strong>. "
            "fibonacci_sequence_gate: <strong>n=14</strong> (fib(14)=377)."
        ),
        files=["checksum_lock", "env_var_secret_gate", "interactive_stdin_prompt", "fibonacci_sequence_gate"],
    ),
    dict(
        slug="scripting-automation",
        level=7,
        difficulty="Hard",
        color="cat3",
        title="Scripting &amp; Automation",
        tagline="Stop decoding by hand -- write the script that does it for you.",
        tools=["Python (base64, binascii)", "pwntools (optional, if installed)"],
        tutorial=[
            ("Why automate at all",
             "Real challenges routinely stack 2-3 encodings on top of each other, or need the same "
             "decode run against dozens of candidate keys. Doing that by hand doesn't scale -- the "
             "moment you've manually decoded one layer of something, write the three lines of Python "
             "that do it, so the next layer (or the next similar challenge) is instant."),
            ("Peeling layers outside-in",
             "When you don't know the layer order, work from the OUTERMOST encoding inward: look at "
             "the raw file's character set first (exactly like Level 5), decode that outer layer, "
             "look at what's left, and repeat. Never assume the order from the filename or context "
             "alone -- verify it by what the data actually looks like at each step."),
            ("A reusable crib-drag / known-plaintext pattern",
             "For XOR specifically: if you can guess any substring of the plaintext (a flag format "
             "like <code>flag{</code>, a common word), XOR that guess against the ciphertext at every "
             "possible offset and see what plaintext pops out around it -- this generalizes to finding "
             "XOR keys of any length, not just single bytes."),
        ],
        task=(
            "<code>layered_encoding_challenge.txt</code> has TWO layers stacked: figure out which "
            "encoding is outermost, decode it, see what's left, then identify and decode the second "
            "layer -- write one Python script that does both steps automatically from the raw file, "
            "rather than decoding by hand with a web tool."
        ),
        commands=[
            "python3 -c \"print(open('layered_encoding_challenge.txt').read()[:50])\"  # look at the raw shape first",
            "# then write a script: hex-decode -> XOR every byte against a candidate key -> base64-decode",
        ],
        hints=[
            "The raw file is pure hex digits in pairs -- that's always your outermost layer here, "
            "decode it first with bytes.fromhex(...).",
            "What's left after the hex-decode isn't readable text yet, but it IS printable-looking "
            "base64-alphabet-ish bytes once XORed against the right single-byte key -- try keys "
            "0x00-0xFF programmatically and check which one produces valid base64 characters only.",
            "The correct key for the XOR layer is 0x11; after XOR-ing, base64-decode what remains to "
            "get the final plaintext.",
        ],
        answer=(
            "Full decode script: <code>d = bytes.fromhex(open('layered_encoding_challenge.txt').read())"
            "<br>x = bytes(b ^ 0x11 for b in d)<br>import base64; "
            "print(base64.b64decode(x).decode())</code><br>Result: <code>flag practice this is not a "
            "real flag just text for you to decode</code> -- the same hidden sentence as Level 5, "
            "proving your script actually works end to end."
        ),
        files=["layered_encoding_challenge.txt"],
    ),
]

TOOLS_ARSENAL = [
    ("Static recon", [
        ("file <bin>", "Identify file type, architecture, linking, stripped/not-stripped at a glance."),
        ("strings [-n 8] <bin>", "Print embedded human-readable text, works even on stripped binaries."),
        ("objdump -d [-M intel] <bin>", "Full disassembly listing. Add -M intel for Intel-syntax asm."),
        ("readelf -h / -d / -S <bin>", "Inspect ELF header, dynamic section, or section headers."),
        ("nm <bin>", "List symbol table (function/variable names) -- empty/sparse on stripped binaries."),
        ("ldd <bin>", "List shared library dependencies and where they resolve."),
        ("checksec --file=<bin>", "Report security mitigations: canary, NX, PIE, RELRO (if installed)."),
    ]),
    ("Dynamic analysis", [
        ("gdb <bin>", "Interactive debugger: break, run, next, step, continue, info registers, x/."),
        ("ltrace <bin>", "Trace every library call (strcmp, malloc, printf...) with its arguments."),
        ("strace <bin>", "Trace every system call (read, write, open, connect...) with its arguments."),
    ]),
    ("Forensics", [
        ("file / strings / strings -a / grep -a", "Identify and search files, forcing text mode on binary-looking data."),
        ("xxd <file> / hexdump -C <file>", "Hex + ASCII dump of any file's raw bytes."),
        ("unzip <file> (rename to .zip first if no extension)", "Extract zip archives, including nested ones."),
        ("zip2john <file> > hash.txt && john hash.txt", "Crack a password-protected zip's weak password."),
        ("binwalk <file>", "Scan for embedded file signatures inside another file (if installed)."),
    ]),
    ("Crypto / encoding", [
        ("python3 -c \"import base64; ...\"", "Base64 encode/decode one-liners."),
        ("python3 -c \"bytes.fromhex(...)\"", "Hex-decode raw bytes for further processing."),
        ("rev <file>", "Reverse each line of text (Linux coreutils)."),
        ("echo <text> | tr 'A-Za-z' 'N-ZA-Mn-za-m'", "Quick ROT13 on the command line."),
    ]),
    ("Network", [
        ("nc <host> <port>", "Connect to a live TCP service -- the way every Network-category challenge is solved."),
        ("curl / wget", "Fetch an HTTP resource if a challenge exposes one (not used on this offline platform, but standard real-world recon)."),
    ]),
]
