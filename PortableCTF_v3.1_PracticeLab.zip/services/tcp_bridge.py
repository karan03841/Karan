#!/usr/bin/env python3
"""
Tiny TCP-to-process bridge, no socat required.
Listens on a TCP port and, for each connection, spawns the given program
with its stdin/stdout/stderr wired to the socket -- exactly what socat's
EXEC mode does, and exactly how real CTF 'pwn' challenges are served
(nc host port talks straight to the vulnerable program's stdin/stdout).

Usage: tcp_bridge.py <port> <path-to-binary>
"""
import socket
import subprocess
import sys
import threading


def handle_client(conn, addr, binary_path):
    try:
        proc = subprocess.Popen(
            [binary_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
        )

        def pump(src_read, dst_write):
            try:
                while True:
                    chunk = src_read(4096)
                    if not chunk:
                        break
                    dst_write(chunk)
            except (OSError, BrokenPipeError, ConnectionResetError):
                pass

        t1 = threading.Thread(target=pump, args=(conn.recv, proc.stdin.write))
        t2 = threading.Thread(target=pump, args=(proc.stdout.read, lambda b: conn.sendall(b)))
        t1.daemon = True
        t2.daemon = True
        t1.start()
        t2.start()
        proc.wait(timeout=60)
        t1.join(timeout=1)
        t2.join(timeout=1)
    except Exception:
        pass
    finally:
        try:
            proc.kill()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass


def main():
    if len(sys.argv) != 3:
        print("Usage: tcp_bridge.py <port> <path-to-binary>", file=sys.stderr)
        sys.exit(1)
    port = int(sys.argv[1])
    binary_path = sys.argv[2]

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(5)
    print(f"[tcp_bridge] serving {binary_path} on 127.0.0.1:{port}")

    while True:
        conn, addr = srv.accept()
        th = threading.Thread(target=handle_client, args=(conn, addr, binary_path))
        th.daemon = True
        th.start()


if __name__ == "__main__":
    main()
