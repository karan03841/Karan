#!/usr/bin/env python3
"""PortableCTF v3 - database seed script. Safe to re-run (upserts)."""
import sqlite3, hashlib, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ctf.db")

def flag_hash(flag):
    return hashlib.sha256(flag.strip().encode()).hexdigest()

CHALLENGES = [
    {
        "id": 1,
        "title": """Vault Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """A tiny gatekeeper checks a password you give it on the command line.

This binary has 2 stages. Run it as:
    ./chal1 <stage_number 1-2> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal1""",
        "hint": """Run it in Ghidra/strings and work out each stage's decode transform from the code -- the secret is never stored plain, only its encoded bytes.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Run it in Ghidra/strings and work out each stage's decode transform from the code -- the secret is never stored plain, only its encoded bytes.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 2 stages:
  Stage 1: flag{re1_s1_xor_ok}
  Stage 2: flag{re1_s2_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (xor)""",
                "points": 20,
                "flag_hash": """d97f8c4ecfd00aa5f631257b54ea979d4f48e46785168d3a1653c3c7ffd72ac0""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (caesar)""",
                "points": 20,
                "flag_hash": """146992266613415ec217b33516c00c831af35c0c12ed6234495bb9c1ff821b0d""",
            },
        ],
    },
    {
        "id": 2,
        "title": """Mirror Check""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """Something about this program reads its input backwards before deciding.

This binary has 2 stages. Run it as:
    ./chal2 <stage_number 1-2> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal2""",
        "hint": """Each stage uses a different byte transform. Decompile and spot which one (reverse/xor/caesar/bit-rotate/substitution) each stage applies.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Each stage uses a different byte transform. Decompile and spot which one (reverse/xor/caesar/bit-rotate/substitution) each stage applies.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 2 stages:
  Stage 1: flag{re2_s1_caesar_ok}
  Stage 2: flag{re2_s2_rotbits_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (caesar)""",
                "points": 22,
                "flag_hash": """49ae8be4deb12fc5a789e991ee8834453e286a2a089a58f2a38ac46b3d175621""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (rotbits)""",
                "points": 23,
                "flag_hash": """2c6a09def7c8f1420135e7b09a851d85e87cb1e5c4660bd8ca0ee092e1207680""",
            },
        ],
    },
    {
        "id": 3,
        "title": """Checksum Gate v1""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """A simple gatekeeper, but every stage hides its secret a different way.

This binary has 2 stages. Run it as:
    ./chal3 <stage_number 1-2> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal3""",
        "hint": """There is no plaintext flag anywhere in this binary -- it's all encoded bytes decoded at runtime. Reverse the decode loop per stage.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy | 2 stages

Approach that solves this challenge:
There is no plaintext flag anywhere in this binary -- it's all encoded bytes decoded at runtime. Reverse the decode loop per stage.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 2 stages:
  Stage 1: flag{re3_s1_rotbits_ok}
  Stage 2: flag{re3_s2_substitution_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (rotbits)""",
                "points": 22,
                "flag_hash": """3ee263a49590039d787211a901710fb0a57b0e6ba716c28f41c517e7cbb97b79""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (substitution)""",
                "points": 23,
                "flag_hash": """b395ba8a7602d43373e7dc1557b7cb73505e354f12d860d0c12e20af4178957e""",
            },
        ],
    },
    {
        "id": 4,
        "title": """Checksum Gate v2""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 80,
        "hint_cost": 12,
        "description": """The harder sibling of Checksum Gate v1 -- more stages, same idea.

This binary has 3 stages. Run it as:
    ./chal4 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal4""",
        "hint": """Three distinct decode techniques stacked in one binary. Work them out one at a time via argv[1] = stage number.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Three distinct decode techniques stacked in one binary. Work them out one at a time via argv[1] = stage number.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re4_s1_substitution_ok}
  Stage 2: flag{re4_s2_reverse_ok}
  Stage 3: flag{re4_s3_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (substitution)""",
                "points": 26,
                "flag_hash": """53a99f01c06a4fde347636ac3934c7de73eec6eccb89e4cddcc40625087d848d""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (reverse)""",
                "points": 26,
                "flag_hash": """771516b2c0c5a9b443c9a7258cfd5585667c363e2c90ba8c00c043e3cb5df56f""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (xor)""",
                "points": 28,
                "flag_hash": """c006269cd18f13aa71fb7759430174098f59e313204caa1dc49ee564119b8763""",
            },
        ],
    },
    {
        "id": 5,
        "title": """Case Confusion""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """Case folding was a trap before -- now every stage has its own trap.

This binary has 2 stages. Run it as:
    ./chal5 <stage_number 1-2> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal5""",
        "hint": """Decompile each stage block separately; don't assume they all use the same trick.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Decompile each stage block separately; don't assume they all use the same trick.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 2 stages:
  Stage 1: flag{re5_s1_reverse_ok}
  Stage 2: flag{re5_s2_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (reverse)""",
                "points": 20,
                "flag_hash": """ed92fbf193f8f46656b6e24e866a585b6246599b3c749b5a4ca50c108c27adad""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (xor)""",
                "points": 20,
                "flag_hash": """1ec08719b767bca1b8609a5d7b39ab155e6f05551781cc21e2cc64db15b59db3""",
            },
        ],
    },
    {
        "id": 6,
        "title": """Multi-Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 55,
        "hint_cost": 8,
        "description": """Multiple independent gates live in one binary now, staged.

This binary has 2 stages. Run it as:
    ./chal6 <stage_number 1-2> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal6""",
        "hint": """Call with ./chal6 <stage> <input> -- stage picks which decode logic runs.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Call with ./chal6 <stage> <input> -- stage picks which decode logic runs.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 2 stages:
  Stage 1: flag{re6_s1_xor_ok}
  Stage 2: flag{re6_s2_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (xor)""",
                "points": 27,
                "flag_hash": """ca4644402a330a1f62c51023ad2143c6912b5522f0c154b19fd1c6165d63e7bb""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (caesar)""",
                "points": 28,
                "flag_hash": """51203cb00bb2e7e1b162bc770a832bde4b645b2fa80ce2771dfccd24b66d8d8f""",
            },
        ],
    },
    {
        "id": 7,
        "title": """XOR Lock Alpha""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 85,
        "hint_cost": 13,
        "description": """XOR is only one of several transforms chained across this binary's stages.

This binary has 3 stages. Run it as:
    ./chal7 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal7""",
        "hint": """Find the XOR key for the XOR stage; the other stages use entirely different transforms.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Find the XOR key for the XOR stage; the other stages use entirely different transforms.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re7_s1_caesar_ok}
  Stage 2: flag{re7_s2_rotbits_ok}
  Stage 3: flag{re7_s3_substitution_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (caesar)""",
                "points": 28,
                "flag_hash": """b6d998e2ac5ff9c0bf35219ae2821ef438f59cc07416df396d3a3aeb1f3a1c98""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (rotbits)""",
                "points": 28,
                "flag_hash": """47e882f8a6797d7a7dfdafce9eb22804f3c60aa8dbe79b3a15a75920cde2b2ca""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (substitution)""",
                "points": 29,
                "flag_hash": """7bb8d56cd02c660205dd07d0aaf4b877212beee99d1b4beab5e766f7df7411c9""",
            },
        ],
    },
    {
        "id": 8,
        "title": """XOR Lock Beta""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 85,
        "hint_cost": 13,
        "description": """A second, harder XOR-flavoured lock, now multi-stage.

This binary has 3 stages. Run it as:
    ./chal8 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal8""",
        "hint": """Same idea as Alpha but more stages -- Medium tier means 3 distinct techniques to crack.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Same idea as Alpha but more stages -- Medium tier means 3 distinct techniques to crack.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re8_s1_rotbits_ok}
  Stage 2: flag{re8_s2_substitution_ok}
  Stage 3: flag{re8_s3_reverse_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (rotbits)""",
                "points": 28,
                "flag_hash": """bbdfb7f9f8f785a537a77bc12d68774de71c3089d6e0bb136950bba9b012c75c""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (substitution)""",
                "points": 28,
                "flag_hash": """c46b3d739253a37de8a7e231a03e9dfe93b8f982fe7d2b5f8d3273dae07bc54f""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (reverse)""",
                "points": 29,
                "flag_hash": """aea5a42f7398a3d57fb5c4a0697b03b54ebddf77088f0235be15af8a477907c5""",
            },
        ],
    },
    {
        "id": 9,
        "title": """Caesar Gate I""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 85,
        "hint_cost": 13,
        "description": """A Caesar-shift flavoured lock, staged.

This binary has 3 stages. Run it as:
    ./chal9 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal9""",
        "hint": """Only one of the stages is actually Caesar -- decompile each stage separately to see which transform it runs.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Only one of the stages is actually Caesar -- decompile each stage separately to see which transform it runs.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re9_s1_substitution_ok}
  Stage 2: flag{re9_s2_reverse_ok}
  Stage 3: flag{re9_s3_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (substitution)""",
                "points": 28,
                "flag_hash": """8fb01c2e71a2cf698ef8f7907af41c527bb84af7971fa84b236e7f9856cb4dc7""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (reverse)""",
                "points": 28,
                "flag_hash": """8e1de80413cf38fc744b943672e72f76b42483908e03731f579744479cf1c9a9""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (xor)""",
                "points": 29,
                "flag_hash": """13cb130ff0ecc851020f2eafc3d7812c83fe4f9f82d324709c07df4903035cf6""",
            },
        ],
    },
    {
        "id": 10,
        "title": """Caesar Gate II (ROT13)""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 80,
        "hint_cost": 12,
        "description": """The ROT13-flavoured sibling, staged.

This binary has 3 stages. Run it as:
    ./chal10 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal10""",
        "hint": """ROT13 is just Caesar shift 13 -- but remember other stages in this binary use different transforms entirely.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
ROT13 is just Caesar shift 13 -- but remember other stages in this binary use different transforms entirely.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re10_s1_reverse_ok}
  Stage 2: flag{re10_s2_xor_ok}
  Stage 3: flag{re10_s3_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (reverse)""",
                "points": 26,
                "flag_hash": """74b6920ac6eaf65c2e1d06af7acfe6361754ef8c3a0b248814895e487a649fd6""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (xor)""",
                "points": 26,
                "flag_hash": """bad6f959040fac972938112e18ea1262ba18c455c7e4062d4c6cb5a09d480543""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (caesar)""",
                "points": 28,
                "flag_hash": """9246ef8fabb5b4481d98b71914e5ae3e5a03cdb6f08168bbd805194ed59f59a4""",
            },
        ],
    },
    {
        "id": 11,
        "title": """Substitution Table""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 95,
        "hint_cost": 14,
        "description": """A substitution-cipher flavoured lock, staged.

This binary has 3 stages. Run it as:
    ./chal11 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal11""",
        "hint": """The substitution stage swaps case and shifts digits -- work out the exact rule from the decompiled loop.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
The substitution stage swaps case and shifts digits -- work out the exact rule from the decompiled loop.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re11_s1_xor_ok}
  Stage 2: flag{re11_s2_caesar_ok}
  Stage 3: flag{re11_s3_rotbits_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (xor)""",
                "points": 31,
                "flag_hash": """fa926f37237b1c4e69788e37bc24d0ebf0450836a133d94b9af11d77d75be8d4""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (caesar)""",
                "points": 31,
                "flag_hash": """d5d9df35c373b113ef9e8da93a20f208949f2d28c5554cc9bb2bd6d2c2c018c6""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (rotbits)""",
                "points": 33,
                "flag_hash": """1442d45179cab9e9b774adf04eb83726dfb69eaeaf87804465b4a2a3df3797cd""",
            },
        ],
    },
    {
        "id": 12,
        "title": """Bitwise OR Puzzle""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 70,
        "hint_cost": 10,
        "description": """Originally a bitwise puzzle -- now staged like the rest.

This binary has 3 stages. Run it as:
    ./chal12 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal12""",
        "hint": """Every stage in this binary hides its secret with a different reversible byte transform; none are stored plain.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Every stage in this binary hides its secret with a different reversible byte transform; none are stored plain.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re12_s1_caesar_ok}
  Stage 2: flag{re12_s2_rotbits_ok}
  Stage 3: flag{re12_s3_substitution_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (caesar)""",
                "points": 23,
                "flag_hash": """597d4e0dd45222433ab85872c6fb3a805ce9670e4349c09364123ddeec5f4d10""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (rotbits)""",
                "points": 23,
                "flag_hash": """2a5799bed942600ce787652c6106586ec95d5c72e4c9e1defb84697e881a23bc""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (substitution)""",
                "points": 24,
                "flag_hash": """af993ca32b67f7cd9bde3d7b12859fa2ebfca3c15e4d31235244a86b6edbbe99""",
            },
        ],
    },
    {
        "id": 13,
        "title": """Transform Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """A gate built entirely around chained byte transforms, staged.

This binary has 3 stages. Run it as:
    ./chal13 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal13""",
        "hint": """Five transform families exist across the whole platform: reverse, xor, caesar, bit-rotate, substitution.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Five transform families exist across the whole platform: reverse, xor, caesar, bit-rotate, substitution.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re13_s1_rotbits_ok}
  Stage 2: flag{re13_s2_substitution_ok}
  Stage 3: flag{re13_s3_reverse_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (rotbits)""",
                "points": 33,
                "flag_hash": """4639ecc034fbf1a30ac4e5630daf135eade6024a17a3703665492f8387a80d24""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (substitution)""",
                "points": 33,
                "flag_hash": """619f50b0deba01bbc09b3f477ebb17bac19aa1d34d90fb94a8172f7a42d23284""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (reverse)""",
                "points": 34,
                "flag_hash": """cc9f6767d5196fefac7f9083b5fad7c909f04cedd3ac0969621697890ccf9ead""",
            },
        ],
    },
    {
        "id": 14,
        "title": """Environment Check""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 75,
        "hint_cost": 11,
        "description": """Still reads an environment variable for one stage; others read argv.

This binary has 3 stages. Run it as:
    ./chal14 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal14""",
        "hint": """Check argv[1] for the stage number -- one of the stages may ask you to set an env var instead of passing argv[2].""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Check argv[1] for the stage number -- one of the stages may ask you to set an env var instead of passing argv[2].

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re14_s1_substitution_ok}
  Stage 2: flag{re14_s2_reverse_ok}
  Stage 3: flag{re14_s3_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (substitution)""",
                "points": 25,
                "flag_hash": """32893320f4944ca900e363070ba57a73e65762731a21da82e3edbdb8bf201f91""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (reverse)""",
                "points": 25,
                "flag_hash": """43c4382b1da253d2fb212a82a158bde3e83b254a5962a98239df32e9097bb97f""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (xor)""",
                "points": 25,
                "flag_hash": """da73bc709435f98af9ac3078c98ac3b1f8a441a6d6b193578efe96648ec77c16""",
            },
        ],
    },
    {
        "id": 15,
        "title": """Interactive Prompt""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 75,
        "hint_cost": 11,
        "description": """One stage prompts interactively on stdin instead of taking argv.

This binary has 3 stages. Run it as:
    ./chal15 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal15""",
        "hint": """If a stage doesn't take a 2nd argv, try running it directly and typing your answer when prompted.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
If a stage doesn't take a 2nd argv, try running it directly and typing your answer when prompted.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 3 stages:
  Stage 1: flag{re15_s1_reverse_ok}
  Stage 2: flag{re15_s2_xor_ok}
  Stage 3: flag{re15_s3_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (reverse)""",
                "points": 25,
                "flag_hash": """614e00860470dff685a49ea9ed4550d6a54b1c098032fcba99ed44c4c3e5ad71""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (xor)""",
                "points": 25,
                "flag_hash": """4dfd7d1aae64d77a4f04c70987b7ca01bf3cbe5870ae3900e8d8672fc08adb70""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (caesar)""",
                "points": 25,
                "flag_hash": """d40ed092e33b895ad209520804cf9dfd3eb361fb14b60249f074ae3a0d883771""",
            },
        ],
    },
    {
        "id": 16,
        "title": """Two-Stage Pipeline""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 140,
        "hint_cost": 21,
        "description": """A pipeline-flavoured binary, now with 5 real stages.

This binary has 5 stages. Run it as:
    ./chal16 <stage_number 1-5> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal16""",
        "hint": """Hard tier: 5 distinct decode techniques stacked in one binary. Take it stage by stage.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard | 5 stages

Approach that solves this challenge:
Hard tier: 5 distinct decode techniques stacked in one binary. Take it stage by stage.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 5 stages:
  Stage 1: flag{re16_s1_xor_ok}
  Stage 2: flag{re16_s2_caesar_ok}
  Stage 3: flag{re16_s3_rotbits_ok}
  Stage 4: flag{re16_s4_substitution_ok}
  Stage 5: flag{re16_s5_reverse_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (xor)""",
                "points": 28,
                "flag_hash": """b6d786b10fe09c38b9a5ddafe54e2d9958364d083ef828050060852dfafc58c2""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (caesar)""",
                "points": 28,
                "flag_hash": """a4d654b4dd295ed94aeb3a0d9b147db9580920aa260066f8e738e165eb1563f9""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (rotbits)""",
                "points": 28,
                "flag_hash": """fdff166d7e2f21a0691c0ee050e5f1a67423908cad5534a714cc00081b212acf""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (substitution)""",
                "points": 28,
                "flag_hash": """861da773c9d42c83fef13cbc41cd179023155065827e3b2d8ebe126d032cf302""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (reverse)""",
                "points": 28,
                "flag_hash": """f000635c3af5a379619ca41bf0c23a63f6263ee731bbaad296717b91fd174215""",
            },
        ],
    },
    {
        "id": 17,
        "title": """Caesar-Then-Add Pipeline""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 150,
        "hint_cost": 22,
        "description": """Another pipeline-flavoured Hard binary.

This binary has 5 stages. Run it as:
    ./chal17 <stage_number 1-5> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal17""",
        "hint": """Don't assume stage order maps to technique order from other challenges -- decompile each one.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard | 5 stages

Approach that solves this challenge:
Don't assume stage order maps to technique order from other challenges -- decompile each one.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 5 stages:
  Stage 1: flag{re17_s1_caesar_ok}
  Stage 2: flag{re17_s2_rotbits_ok}
  Stage 3: flag{re17_s3_substitution_ok}
  Stage 4: flag{re17_s4_reverse_ok}
  Stage 5: flag{re17_s5_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (caesar)""",
                "points": 30,
                "flag_hash": """33e7b6b0c38d36f997435fcef2cb9f1fd7301ea40595afe23957415076979633""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (rotbits)""",
                "points": 30,
                "flag_hash": """3ac78dd28b82c77d37f022f5c010abbceff4e87f0bf990d22f24826c7a8978e5""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (substitution)""",
                "points": 30,
                "flag_hash": """288c8888f0479ec82103868355f96d68c5b70d61413cf0bd6e9af893cac30a7d""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (reverse)""",
                "points": 30,
                "flag_hash": """6c1ab7c99d5e7bb1956c15e66c415597681d580ccf763d5e259864b6349eaebc""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (xor)""",
                "points": 30,
                "flag_hash": """404c6fca3f9a015eb66e8d53e8bc0e76d75eccd90bcfa3ce572fa75946388e42""",
            },
        ],
    },
    {
        "id": 18,
        "title": """Mystery Recursion""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 120,
        "hint_cost": 18,
        "description": """Previously recursion-themed; now a 5-stage transform gauntlet.

This binary has 5 stages. Run it as:
    ./chal18 <stage_number 1-5> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal18""",
        "hint": """Patience pays off here -- five stages, five different reversible transforms.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard | 5 stages

Approach that solves this challenge:
Patience pays off here -- five stages, five different reversible transforms.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 5 stages:
  Stage 1: flag{re18_s1_rotbits_ok}
  Stage 2: flag{re18_s2_substitution_ok}
  Stage 3: flag{re18_s3_reverse_ok}
  Stage 4: flag{re18_s4_xor_ok}
  Stage 5: flag{re18_s5_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (rotbits)""",
                "points": 24,
                "flag_hash": """b3dc73e23b38a59d7631e7aeca33a8b953aee888711452ebefe565641cefcd1d""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (substitution)""",
                "points": 24,
                "flag_hash": """cca5aba23c22a45c25f29c7763ba36effca2be309df2c80ea842a28bc15cb51b""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (reverse)""",
                "points": 24,
                "flag_hash": """f983aec80ca602b078629b4f7081ba61f2b5ab0eb736ec158b95d9a7685c7f7b""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (xor)""",
                "points": 24,
                "flag_hash": """b249a291da97db64a6532c6e7ee7effccf3c3a1a8c3c2882c00729ab73d77324""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (caesar)""",
                "points": 24,
                "flag_hash": """e6eb50675a3bc8c36d388c1f85c1e1f73cfb42e23ee0898604a0d02ca2e015a9""",
            },
        ],
    },
    {
        "id": 19,
        "title": """Finite State Gate""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 130,
        "hint_cost": 20,
        "description": """Previously an FSM; now a 5-stage transform gauntlet.

This binary has 5 stages. Run it as:
    ./chal19 <stage_number 1-5> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal19""",
        "hint": """Same five-technique family as every other RE challenge, just a harder flavour text.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard | 5 stages

Approach that solves this challenge:
Same five-technique family as every other RE challenge, just a harder flavour text.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 5 stages:
  Stage 1: flag{re19_s1_substitution_ok}
  Stage 2: flag{re19_s2_reverse_ok}
  Stage 3: flag{re19_s3_xor_ok}
  Stage 4: flag{re19_s4_caesar_ok}
  Stage 5: flag{re19_s5_rotbits_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (substitution)""",
                "points": 26,
                "flag_hash": """6253003f6ffc0e2f5490d9dc313a84ec35ee9741829e42713e9b0cf56d6b829e""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (reverse)""",
                "points": 26,
                "flag_hash": """c63b0b2a933ead0aed1c95840aebf644e3dead93b3f28942725d68438a267261""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (xor)""",
                "points": 26,
                "flag_hash": """5d6f9d89b554a08637d0b88c9652d25e9cb586bbb5e4600050b2ecd271ff6d99""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (caesar)""",
                "points": 26,
                "flag_hash": """b0f8efb828f30aa191b69ae48bcb73f28ead0b24be3e0ee27216b9d10e7dfc97""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (rotbits)""",
                "points": 26,
                "flag_hash": """ffb80da43fb3d6d942903c37425f2343df5cdfc673f7acdc38f86482868e0fa3""",
            },
        ],
    },
    {
        "id": 20,
        "title": """Rule Table""",
        "category": """Reverse Engineering""",
        "difficulty": """Hard""",
        "points": 110,
        "hint_cost": 16,
        "description": """The final RE challenge -- a full 5-stage gauntlet.

This binary has 5 stages. Run it as:
    ./chal20 <stage_number 1-5> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal20""",
        "hint": """This is the last and hardest RE binary. Work through all 5 stages one at a time.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Hard | 5 stages

Approach that solves this challenge:
This is the last and hardest RE binary. Work through all 5 stages one at a time.

Every stage in this binary hides its secret with a genuinely different reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the compiled file -- the plaintext only ever exists transiently on the stack once you've correctly reconstructed it.

This challenge had 5 stages:
  Stage 1: flag{re20_s1_reverse_ok}
  Stage 2: flag{re20_s2_xor_ok}
  Stage 3: flag{re20_s3_caesar_ok}
  Stage 4: flag{re20_s4_rotbits_ok}
  Stage 5: flag{re20_s5_substitution_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (reverse)""",
                "points": 22,
                "flag_hash": """126a352ca2753dc16a049f17e31d3830fd0b151b9a98c42c84571c5b071b9a0f""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (xor)""",
                "points": 22,
                "flag_hash": """8b6c4b37e3124eca81f5d10cb18fcf75a804a4a15880ea650d07bfdfa0d231f4""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (caesar)""",
                "points": 22,
                "flag_hash": """5cd103f68fbc867a7754664c487c982c25c7879c9a31bfbcbf1947e30b3f1150""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (rotbits)""",
                "points": 22,
                "flag_hash": """dfb3afe86f5fb598b1ff29d526e5c4fa0c4b7bac9729a2c70d31fb70bd45aa59""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (substitution)""",
                "points": 22,
                "flag_hash": """5d7f23cffd54dcbfa059792aa2b28ef6c05f5de85feb33957ffbbda0a0dd3926""",
            },
        ],
    },
    {
        "id": 21,
        "title": """Overflow I: Name Tag""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This program reads your name into a fixed-size stack buffer using scanf("%s", buf) -- which does NOT check length. Right after the buffer, it declares THREE integers (authenticated, is_admin, god_mode) at increasing stack depth, each starting at 0. Overflowing the buffer by different amounts overwrites them one at a time -- the deeper the overflow, the more variables flip nonzero, each one printing its own stage flag.

Run it interactively (./chal21) and feed progressively longer strings of a repeated character to find the 3 overflow depths (one per stage).""",
        "filename": """chal21""",
        "hint": """The buffer is 64 bytes. Try feeding it strings of 'A'*N for increasing N and watch which stage message appears. Each stage you unlock prints that stage's flag directly -- copy it exactly into that stage's submit box.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium | 3 stages

Approach that solves this challenge:
The buffer is 64 bytes. Try feeding it strings of 'A'*N for increasing N and watch which stage message appears. Each stage you unlock prints that stage's flag directly -- copy it exactly into that stage's submit box.

Bounds-unchecked reads let anything placed after the buffer on the stack be overwritten the further you overflow -- each stage's variable sits a little deeper, so longer overflows unlock more stages at once.

This challenge had 3 stages:
  Stage 1: flag{pwn21_s1_ok}
  Stage 2: flag{pwn21_s2_ok}
  Stage 3: flag{pwn21_s3_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (overwrite authenticated)""",
                "points": 33,
                "flag_hash": """24226aa71002861ddfcf95d80661b128541263da26dfed2450b2a31b1eb7afd8""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (overwrite is_admin)""",
                "points": 33,
                "flag_hash": """afcf1708c1c12315550a499e1fc870acd2521a495471d3e032fee73bcb0f1378""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (overwrite god_mode)""",
                "points": 34,
                "flag_hash": """3137abb59b52769a661fc4122f5d10c39133230a06cd056144b0252f25b6ef5c""",
            },
        ],
    },
    {
        "id": 22,
        "title": """Overflow II: Short Buffer""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 110,
        "hint_cost": 16,
        "description": """This program reads your name into a fixed-size stack buffer using scanf("%s", buf) -- which does NOT check length. Right after the buffer, it declares THREE integers (access_granted, is_root, bypass_all) at increasing stack depth, each starting at 0. Overflowing the buffer by different amounts overwrites them one at a time -- the deeper the overflow, the more variables flip nonzero, each one printing its own stage flag.

Run it interactively (./chal22) and feed progressively longer strings of a repeated character to find the 3 overflow depths (one per stage).""",
        "filename": """chal22""",
        "hint": """The buffer is 32 bytes. Try feeding it strings of 'A'*N for increasing N and watch which stage message appears. Each stage you unlock prints that stage's flag directly -- copy it exactly into that stage's submit box.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium | 3 stages

Approach that solves this challenge:
The buffer is 32 bytes. Try feeding it strings of 'A'*N for increasing N and watch which stage message appears. Each stage you unlock prints that stage's flag directly -- copy it exactly into that stage's submit box.

Bounds-unchecked reads let anything placed after the buffer on the stack be overwritten the further you overflow -- each stage's variable sits a little deeper, so longer overflows unlock more stages at once.

This challenge had 3 stages:
  Stage 1: flag{pwn22_s1_ok}
  Stage 2: flag{pwn22_s2_ok}
  Stage 3: flag{pwn22_s3_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (overwrite access_granted)""",
                "points": 36,
                "flag_hash": """4928e789cdd397b27496b2c2612d8030722944a2a524c4f70222fec21d514511""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (overwrite is_root)""",
                "points": 36,
                "flag_hash": """f726eed61aace6e657e64595058156303505e1fed11693e36c5b6a195bd01624""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (overwrite bypass_all)""",
                "points": 38,
                "flag_hash": """7febc85ae371f2368fd47b8d494c17a20c5b2e5c54dba2b4dfb11dcf37788cbf""",
            },
        ],
    },
    {
        "id": 23,
        "title": """Overflow III: Admin Flag""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 110,
        "hint_cost": 16,
        "description": """This program reads your name into a fixed-size stack buffer using scanf("%s", buf) -- which does NOT check length. Right after the buffer, it declares THREE integers (is_admin, trusted, super_user) at increasing stack depth, each starting at 0. Overflowing the buffer by different amounts overwrites them one at a time -- the deeper the overflow, the more variables flip nonzero, each one printing its own stage flag.

Run it interactively (./chal23) and feed progressively longer strings of a repeated character to find the 3 overflow depths (one per stage).""",
        "filename": """chal23""",
        "hint": """The buffer is 48 bytes. Try feeding it strings of 'A'*N for increasing N and watch which stage message appears. Each stage you unlock prints that stage's flag directly -- copy it exactly into that stage's submit box.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium | 3 stages

Approach that solves this challenge:
The buffer is 48 bytes. Try feeding it strings of 'A'*N for increasing N and watch which stage message appears. Each stage you unlock prints that stage's flag directly -- copy it exactly into that stage's submit box.

Bounds-unchecked reads let anything placed after the buffer on the stack be overwritten the further you overflow -- each stage's variable sits a little deeper, so longer overflows unlock more stages at once.

This challenge had 3 stages:
  Stage 1: flag{pwn23_s1_ok}
  Stage 2: flag{pwn23_s2_ok}
  Stage 3: flag{pwn23_s3_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (overwrite is_admin)""",
                "points": 36,
                "flag_hash": """4f0da8f1147ad6ef4b240af5369d143acb1f394f8fc6c029e9b8ce8ffa5a90c5""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (overwrite trusted)""",
                "points": 36,
                "flag_hash": """7b4869a89823cd267bfa0b4e6ef91d6f2c062dff0c2e943ffbd2b3cddf069226""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (overwrite super_user)""",
                "points": 38,
                "flag_hash": """35da7b725040b0510e4adf080e84ff294341a8d691179ca0d9e4eab0b0c2b0eb""",
            },
        ],
    },
    {
        "id": 24,
        "title": """Format String I: Loose Lips""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """This program takes a line of text and passes it DIRECTLY to printf() as the format string, instead of safely using printf("%s", buf). Classic format string bug: if your input contains %x / %s specifiers, printf reads them off the stack -- leaking whatever local variables happen to sit nearby, including THREE separate secret strings declared just before your buffer (each one is a different stage's flag).

Feed it a chain of %x (or positional %N$x) specifiers to walk the stack and find all three. They sit at different depths, so you'll need to keep extending your %x chain (or use %N$s / %N$x with different N) to reach the 2nd and 3rd one.""",
        "filename": """chal24""",
        "hint": """A chain like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (lots of repeated %x) dumps raw stack words as hex -- convert hex back to ASCII (x86-64 is little-endian, so reverse byte order within each 8-byte word) to read each leaked secret. Or use positional args directly, e.g. %7$s, %8$s, %9$s, trying different numbers until readable text comes out.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium | 3 stages

Approach that solves this challenge:
A chain like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (lots of repeated %x) dumps raw stack words as hex -- convert hex back to ASCII (x86-64 is little-endian, so reverse byte order within each 8-byte word) to read each leaked secret. Or use positional args directly, e.g. %7$s, %8$s, %9$s, trying different numbers until readable text comes out.

Format string bugs are dangerous because the attacker controls what printf reads as arguments, letting you read arbitrary stack memory. Each stage's secret sits at a different stack depth, so you must extend your %x/%N$s chain further to reach the later stages.

This challenge had 3 stages:
  Stage 1: flag{pwn24_s1_ok}
  Stage 2: flag{pwn24_s2_ok}
  Stage 3: flag{pwn24_s3_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (leak secret #1)""",
                "points": 33,
                "flag_hash": """81a05ec1f701e64bc4841f2f70e6efa1be84f7d76d4fcfb6e0b1f705b65f2260""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (leak secret #2)""",
                "points": 33,
                "flag_hash": """821262b46e30347e472ef2b05ab05980e8e5bf3b8152fb5cb3a10ce8df11b204""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (leak secret #3)""",
                "points": 34,
                "flag_hash": """e4ef835d8997bf919269ca9e5f9b12feee1e12a3298bcad2fe3c07ee1fe5277c""",
            },
        ],
    },
    {
        "id": 25,
        "title": """Format String II: Stack Peek""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 110,
        "hint_cost": 16,
        "description": """This program takes a line of text and passes it DIRECTLY to printf() as the format string, instead of safely using printf("%s", buf). Classic format string bug: if your input contains %x / %s specifiers, printf reads them off the stack -- leaking whatever local variables happen to sit nearby, including THREE separate secret strings declared just before your buffer (each one is a different stage's flag).

Feed it a chain of %x (or positional %N$x) specifiers to walk the stack and find all three. They sit at different depths, so you'll need to keep extending your %x chain (or use %N$s / %N$x with different N) to reach the 2nd and 3rd one.""",
        "filename": """chal25""",
        "hint": """A chain like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (lots of repeated %x) dumps raw stack words as hex -- convert hex back to ASCII (x86-64 is little-endian, so reverse byte order within each 8-byte word) to read each leaked secret. Or use positional args directly, e.g. %7$s, %8$s, %9$s, trying different numbers until readable text comes out.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium | 3 stages

Approach that solves this challenge:
A chain like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (lots of repeated %x) dumps raw stack words as hex -- convert hex back to ASCII (x86-64 is little-endian, so reverse byte order within each 8-byte word) to read each leaked secret. Or use positional args directly, e.g. %7$s, %8$s, %9$s, trying different numbers until readable text comes out.

Format string bugs are dangerous because the attacker controls what printf reads as arguments, letting you read arbitrary stack memory. Each stage's secret sits at a different stack depth, so you must extend your %x/%N$s chain further to reach the later stages.

This challenge had 3 stages:
  Stage 1: flag{pwn25_s1_ok}
  Stage 2: flag{pwn25_s2_ok}
  Stage 3: flag{pwn25_s3_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (leak secret #1)""",
                "points": 36,
                "flag_hash": """6d5c1093f29d3b2e77a94a4aaec6fb23143607d18b80e26cfe609689c2e4c517""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (leak secret #2)""",
                "points": 36,
                "flag_hash": """a745a63470fba4389963776ecd7ee83da918c76742f1b0b472a6fc5d95f9bfa7""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (leak secret #3)""",
                "points": 38,
                "flag_hash": """2a83a63416de212096e7d25ebe77ae4eeadaff2354515f60d2291ca0e3b3fc9b""",
            },
        ],
    },
    {
        "id": 26,
        "title": """Format String III: Deep Leak""",
        "category": """Binary Exploitation""",
        "difficulty": """Medium""",
        "points": 120,
        "hint_cost": 18,
        "description": """This program takes a line of text and passes it DIRECTLY to printf() as the format string, instead of safely using printf("%s", buf). Classic format string bug: if your input contains %x / %s specifiers, printf reads them off the stack -- leaking whatever local variables happen to sit nearby, including THREE separate secret strings declared just before your buffer (each one is a different stage's flag).

Feed it a chain of %x (or positional %N$x) specifiers to walk the stack and find all three. They sit at different depths, so you'll need to keep extending your %x chain (or use %N$s / %N$x with different N) to reach the 2nd and 3rd one.""",
        "filename": """chal26""",
        "hint": """A chain like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (lots of repeated %x) dumps raw stack words as hex -- convert hex back to ASCII (x86-64 is little-endian, so reverse byte order within each 8-byte word) to read each leaked secret. Or use positional args directly, e.g. %7$s, %8$s, %9$s, trying different numbers until readable text comes out.""",
        "writeup": """Category: Binary Exploitation | Difficulty: Medium | 3 stages

Approach that solves this challenge:
A chain like %x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x (lots of repeated %x) dumps raw stack words as hex -- convert hex back to ASCII (x86-64 is little-endian, so reverse byte order within each 8-byte word) to read each leaked secret. Or use positional args directly, e.g. %7$s, %8$s, %9$s, trying different numbers until readable text comes out.

Format string bugs are dangerous because the attacker controls what printf reads as arguments, letting you read arbitrary stack memory. Each stage's secret sits at a different stack depth, so you must extend your %x/%N$s chain further to reach the later stages.

This challenge had 3 stages:
  Stage 1: flag{pwn26_s1_ok}
  Stage 2: flag{pwn26_s2_ok}
  Stage 3: flag{pwn26_s3_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (leak secret #1)""",
                "points": 40,
                "flag_hash": """4b1d73b30d614144926efa8b69f0de275a5c3f338460900d7a8d9a7fc279326f""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (leak secret #2)""",
                "points": 40,
                "flag_hash": """f8b2bc6558bb744d676af95e20ccb1313e3aba396c428f90e155493da7c95a07""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (leak secret #3)""",
                "points": 40,
                "flag_hash": """8ea79a1d35ec8f3eb5803293b306b8cdda4eb019c5309dce791005c5a499caf7""",
            },
        ],
    },
    {
        "id": 27,
        "title": """Ret2Win I: Redirect""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 140,
        "hint_cost": 21,
        "description": """This binary has FIVE separate 'win' functions (win1..win5), each printing a different stage's flag -- but main() never calls any of them. vuln() reads your input into a 40-byte stack buffer with ZERO bounds checking. On this non-PIE binary, every function lives at a fixed, predictable address.

Classic ret2win, five times over: overflow the buffer far enough to overwrite the saved return address, and point it at winN's address to 'return' into that function instead of main(). The offset from the start of the buffer to the saved return address is THE SAME every run -- only the target address changes per stage. Run the exploit 5 times, once per winN address, to collect all 5 stage flags.""",
        "filename": """chal27""",
        "hint": """objdump -d chal27 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal27""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard | 5 stages

Approach that solves this challenge:
objdump -d chal27 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal27

This is the classic 'ret2win' primitive, repeated once per stage: a non-PIE binary has functions that are never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into one of them. The offset to the saved return address is the same every run; only the target address changes per stage.

This challenge had 5 stages:
  Stage 1: flag{pwn27_s1_ok}
  Stage 2: flag{pwn27_s2_ok}
  Stage 3: flag{pwn27_s3_ok}
  Stage 4: flag{pwn27_s4_ok}
  Stage 5: flag{pwn27_s5_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (land on win1)""",
                "points": 28,
                "flag_hash": """408dba3221868879d9504f79efa2b420cf5ba24e0d1a67a555cc98dfee7d273b""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (land on win2)""",
                "points": 28,
                "flag_hash": """2befa0816f983d55810cb5777702155433c8d9537588524acc7e8f84c6df26a7""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (land on win3)""",
                "points": 28,
                "flag_hash": """983870303b926d13b09cbd4a530af78445fe0a23a5a222b748070325661e4ee1""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (land on win4)""",
                "points": 28,
                "flag_hash": """bc4b773253d3432cdd624cef81864c42371a4c1c785ee1d4bf56bbe3f070678a""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (land on win5)""",
                "points": 28,
                "flag_hash": """364898aac83829d0cc43f571faea970edd65f8adbf5ad2ebc9425d12a824d4ea""",
            },
        ],
    },
    {
        "id": 28,
        "title": """Ret2Win II: Longer Jump""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 150,
        "hint_cost": 22,
        "description": """This binary has FIVE separate 'win' functions (win1..win5), each printing a different stage's flag -- but main() never calls any of them. vuln() reads your input into a 56-byte stack buffer with ZERO bounds checking. On this non-PIE binary, every function lives at a fixed, predictable address.

Classic ret2win, five times over: overflow the buffer far enough to overwrite the saved return address, and point it at winN's address to 'return' into that function instead of main(). The offset from the start of the buffer to the saved return address is THE SAME every run -- only the target address changes per stage. Run the exploit 5 times, once per winN address, to collect all 5 stage flags.""",
        "filename": """chal28""",
        "hint": """objdump -d chal28 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal28""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard | 5 stages

Approach that solves this challenge:
objdump -d chal28 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal28

This is the classic 'ret2win' primitive, repeated once per stage: a non-PIE binary has functions that are never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into one of them. The offset to the saved return address is the same every run; only the target address changes per stage.

This challenge had 5 stages:
  Stage 1: flag{pwn28_s1_ok}
  Stage 2: flag{pwn28_s2_ok}
  Stage 3: flag{pwn28_s3_ok}
  Stage 4: flag{pwn28_s4_ok}
  Stage 5: flag{pwn28_s5_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (land on win1)""",
                "points": 30,
                "flag_hash": """b73646aac1c07ec6f0fcf669d4f62385205d17e15cd4c8fe17124597096967c3""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (land on win2)""",
                "points": 30,
                "flag_hash": """a23c8ced88944db8cddecb3c9ae9b2ed7ba3176c9031fd3fb60bd3ebc33fc49d""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (land on win3)""",
                "points": 30,
                "flag_hash": """0374a1017eeb2949799225542292fa7afdcafec5a3bc864a7d0f30ce617c37ff""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (land on win4)""",
                "points": 30,
                "flag_hash": """15c569476cb2d59edb0b356714b72c1222a1270513c7e93422f1c896c49124e6""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (land on win5)""",
                "points": 30,
                "flag_hash": """2f09503e7b799fce7c1e06c62e0a3b03fb760304ba3b63ce766597bed96cac0a""",
            },
        ],
    },
    {
        "id": 29,
        "title": """Ret2Win III: Tight Buffer""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 160,
        "hint_cost": 24,
        "description": """This binary has FIVE separate 'win' functions (win1..win5), each printing a different stage's flag -- but main() never calls any of them. vuln() reads your input into a 24-byte stack buffer with ZERO bounds checking. On this non-PIE binary, every function lives at a fixed, predictable address.

Classic ret2win, five times over: overflow the buffer far enough to overwrite the saved return address, and point it at winN's address to 'return' into that function instead of main(). The offset from the start of the buffer to the saved return address is THE SAME every run -- only the target address changes per stage. Run the exploit 5 times, once per winN address, to collect all 5 stage flags.""",
        "filename": """chal29""",
        "hint": """objdump -d chal29 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal29""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard | 5 stages

Approach that solves this challenge:
objdump -d chal29 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal29

This is the classic 'ret2win' primitive, repeated once per stage: a non-PIE binary has functions that are never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into one of them. The offset to the saved return address is the same every run; only the target address changes per stage.

This challenge had 5 stages:
  Stage 1: flag{pwn29_s1_ok}
  Stage 2: flag{pwn29_s2_ok}
  Stage 3: flag{pwn29_s3_ok}
  Stage 4: flag{pwn29_s4_ok}
  Stage 5: flag{pwn29_s5_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (land on win1)""",
                "points": 32,
                "flag_hash": """ab4f2994686920c24c5713878062235b23c87a80f6041faf7bff08a5d8017c6d""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (land on win2)""",
                "points": 32,
                "flag_hash": """819487ca95379aebdc63abc9ecdb695918f0b9a4171062e887d57d329e3e97e6""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (land on win3)""",
                "points": 32,
                "flag_hash": """4226175a8dfb4fc892a16d65b52460d752e78f61aac7e7c6b7e0aa68676c38d1""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (land on win4)""",
                "points": 32,
                "flag_hash": """ff4beedaa89c75f072b0ce8b5ae630d1523f0de8d40f27ad00d264402413f179""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (land on win5)""",
                "points": 32,
                "flag_hash": """5c0ecd3749e6f7e569c1f9813e9de2c58b46b86a7366df9a97570f77dbd9ccc0""",
            },
        ],
    },
    {
        "id": 30,
        "title": """Ret2Win IV: Final Boss""",
        "category": """Binary Exploitation""",
        "difficulty": """Hard""",
        "points": 170,
        "hint_cost": 26,
        "description": """This binary has FIVE separate 'win' functions (win1..win5), each printing a different stage's flag -- but main() never calls any of them. vuln() reads your input into a 72-byte stack buffer with ZERO bounds checking. On this non-PIE binary, every function lives at a fixed, predictable address.

Classic ret2win, five times over: overflow the buffer far enough to overwrite the saved return address, and point it at winN's address to 'return' into that function instead of main(). The offset from the start of the buffer to the saved return address is THE SAME every run -- only the target address changes per stage. Run the exploit 5 times, once per winN address, to collect all 5 stage flags.""",
        "filename": """chal30""",
        "hint": """objdump -d chal30 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal30""",
        "writeup": """Category: Binary Exploitation | Difficulty: Hard | 5 stages

Approach that solves this challenge:
objdump -d chal30 | grep -A5 '<win1>:' (and win2..win5) gives you each function's address. gdb-peda / pwndbg 'pattern create' + 'pattern offset' finds the offset to the saved return address once -- it's the same for every stage. Then for each stage: python3 -c "import sys,struct; sys.stdout.buffer.write(b'A'*OFFSET + struct.pack('<Q', WINN_ADDR))" | ./chal30

This is the classic 'ret2win' primitive, repeated once per stage: a non-PIE binary has functions that are never called by normal control flow, and an unchecked read lets you overwrite the saved return address to jump straight into one of them. The offset to the saved return address is the same every run; only the target address changes per stage.

This challenge had 5 stages:
  Stage 1: flag{pwn30_s1_ok}
  Stage 2: flag{pwn30_s2_ok}
  Stage 3: flag{pwn30_s3_ok}
  Stage 4: flag{pwn30_s4_ok}
  Stage 5: flag{pwn30_s5_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (land on win1)""",
                "points": 34,
                "flag_hash": """9f80a0604f0e3ebce858a24e0a9635945153053eb9bb8a6c842afc17f9a0de2d""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (land on win2)""",
                "points": 34,
                "flag_hash": """d4d4c3fdf5398bebff1fcc574adaef32e459bb8c76409b74475d8985bd12ffb3""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (land on win3)""",
                "points": 34,
                "flag_hash": """1ed7d6ec2ab425727bf1d4ddb4f2f596e8de830554ac5c141878c8de0f084b1c""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (land on win4)""",
                "points": 34,
                "flag_hash": """8e33b019421af79b031ff006134b9dc608c911f87a1ca100eed53d392f593d23""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (land on win5)""",
                "points": 34,
                "flag_hash": """e5b474519502843373367a4615d2d9a3b88448797720e3564b19f941f3b6b48f""",
            },
        ],
    },
    {
        "id": 31,
        "title": """Encoded Note I""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 30,
        "hint_cost": 5,
        "description": """A short set of notes, each encoded in a common text-safe way.

Download the file -- it has 2 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal31.txt""",
        "hint": """Each stage's ciphertext alphabet gives it away -- base64 uses A-Z/a-z/0-9/+//=, hex uses only 0-9a-f in pairs, rot13 stays letters-only and readable once shifted back.""",
        "writeup": """Category: Cryptography | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Each stage's ciphertext alphabet gives it away -- base64 uses A-Z/a-z/0-9/+//=, hex uses only 0-9a-f in pairs, rot13 stays letters-only and readable once shifted back.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 2 stages:
  Stage 1: flag{crypto31_s1_caesar_ok}
  Stage 2: flag{crypto31_s2_substitution_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 15,
                "flag_hash": """fb17cad732869ac432d62db2c3ab305e5b159c7162f59d3e62c4bde21184acdc""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 15,
                "flag_hash": """b42835a7da92a0e4618d7de2e169688edd5d835ac91b144147c61548f59ab4a6""",
            },
        ],
    },
    {
        "id": 32,
        "title": """Encoded Note II""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 30,
        "hint_cost": 5,
        "description": """A second set of short encoded notes.

Download the file -- it has 2 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal32.txt""",
        "hint": """Look at the character set used in each stage block -- that narrows down which encoding it is immediately.""",
        "writeup": """Category: Cryptography | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Look at the character set used in each stage block -- that narrows down which encoding it is immediately.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 2 stages:
  Stage 1: flag{crypto32_s1_substitution_ok}
  Stage 2: flag{crypto32_s2_vigenere_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 15,
                "flag_hash": """d855c2042ac558cf3b8f91b1e9b61fe3352138d82a513e0e25eaaa36af9808b6""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 15,
                "flag_hash": """d545d7e4fa59847f5c3f8cfc3ef24b622e706a57c506ec27788ae72c53e5ab4d""",
            },
        ],
    },
    {
        "id": 33,
        "title": """Rotated Letters""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 35,
        "hint_cost": 5,
        "description": """Letters have been rotated by fixed, classic amounts across these stages.

Download the file -- it has 2 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal33.txt""",
        "hint": """Caesar-family ciphers (including rot13) only ever shift letters -- try every shift 0-25 per stage if the technique isn't obvious.""",
        "writeup": """Category: Cryptography | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Caesar-family ciphers (including rot13) only ever shift letters -- try every shift 0-25 per stage if the technique isn't obvious.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 2 stages:
  Stage 1: flag{crypto33_s1_vigenere_ok}
  Stage 2: flag{crypto33_s2_bitrotate_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 17,
                "flag_hash": """9a1405f159543fae20c88be43185f3460c2a0f48232fc4e2e3157c3894c358bb""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 18,
                "flag_hash": """92b6dc7d6bacdbc9cd99c6196be34b21de7540bbb9d24254ce2a5cedd0dddae9""",
            },
        ],
    },
    {
        "id": 34,
        "title": """Shifting Keys""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 90,
        "hint_cost": 14,
        "description": """This set of notes uses repeating-key letter shifting (Vigenere) among other techniques.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal34.txt""",
        "hint": """For a Vigenere stage: you know plaintext starts with 'flag{' (braces aren't letters, so they pass through unshifted) -- that reveals key letters directly.""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
For a Vigenere stage: you know plaintext starts with 'flag{' (braces aren't letters, so they pass through unshifted) -- that reveals key letters directly.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 3 stages:
  Stage 1: flag{crypto34_s1_base64_ok}
  Stage 2: flag{crypto34_s2_bitrotate_ok}
  Stage 3: flag{crypto34_s3_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 30,
                "flag_hash": """39cbdb9cc6a1a0c353c2b9ffc3eb6512bae2f26a428e605fcd2aabc96abfee30""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 30,
                "flag_hash": """2bdef5028f0d64478634ee39a101d78011079ee9dd8e7ea56e899777963f8e7c""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 30,
                "flag_hash": """45147769dd0e3379e546c64a160ac61e1f6c7eab4d11b62a2302433ca0f2aa5a""",
            },
        ],
    },
    {
        "id": 35,
        "title": """Repeating XOR""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """Some of these stages XOR the flag against a short repeating key before hex-encoding it.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal35.txt""",
        "hint": """For an XOR stage: you know plaintext starts with 'flag{' -- XOR the first 5 ciphertext bytes against that crib to recover the key, then repeat it across the rest.""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
For an XOR stage: you know plaintext starts with 'flag{' -- XOR the first 5 ciphertext bytes against that crib to recover the key, then repeat it across the rest.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 3 stages:
  Stage 1: flag{crypto35_s1_base64_ok}
  Stage 2: flag{crypto35_s2_hex_ok}
  Stage 3: flag{crypto35_s3_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 33,
                "flag_hash": """f3ef4f6443ba848d0413570377b4579477be49a7293efdf1c31f2aa969065c91""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 33,
                "flag_hash": """9e0420c294d1f754022157955706609918c76c18c72b3d759036a6bf0dd50f3d""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 34,
                "flag_hash": """f88f1c467e16f4482224b942cdfa3de0cca5a90011525251761c158f5abf01be""",
            },
        ],
    },
    {
        "id": 36,
        "title": """Scrambled Alphabet""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 95,
        "hint_cost": 14,
        "description": """Some stages here use a substitution cipher -- every letter swapped for a different fixed letter throughout.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal36.txt""",
        "hint": """Frequency analysis works per-stage: the most common cipher letter usually maps to 'e'. Each stage is independent -- don't reuse one stage's table on another.""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Frequency analysis works per-stage: the most common cipher letter usually maps to 'e'. Each stage is independent -- don't reuse one stage's table on another.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 3 stages:
  Stage 1: flag{crypto36_s1_base64_ok}
  Stage 2: flag{crypto36_s2_hex_ok}
  Stage 3: flag{crypto36_s3_reverse_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 31,
                "flag_hash": """75203a605a4b1961d77eb3f183d4f857b9468c8925aa11459c0074bf433926f6""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 31,
                "flag_hash": """d9be37f10742735c03539b5999cb4e8c51b7aaa61e484d07411cd62df875cfcd""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 33,
                "flag_hash": """3798df0db8da3f7195deea460e36325d672be2b3988b6538250847c1f9bf6b9d""",
            },
        ],
    },
    {
        "id": 37,
        "title": """Bit Rotation""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 95,
        "hint_cost": 14,
        "description": """Some stages rotate every byte's bits by a small fixed amount before hex-encoding.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal37.txt""",
        "hint": """A left bit-rotation by N undoes with a right bit-rotation by the same N (mod 8). Brute-force N from 1-7 per stage until you get readable ASCII starting with 'flag{'.""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
A left bit-rotation by N undoes with a right bit-rotation by the same N (mod 8). Brute-force N from 1-7 per stage until you get readable ASCII starting with 'flag{'.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 3 stages:
  Stage 1: flag{crypto37_s1_hex_ok}
  Stage 2: flag{crypto37_s2_reverse_ok}
  Stage 3: flag{crypto37_s3_rot13_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 31,
                "flag_hash": """e42514e42fb4ba4c234a1883c61e722eac7c467ef3ec61103632e99b4b16ede5""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 31,
                "flag_hash": """77ff2b3c5eea6d0d3eabdd190065c9c9b065b2ecc2252a30b2bfc7605e20128b""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 33,
                "flag_hash": """ba9fc2e4abe87bc170d2cc844e584b0d902940139e50b0dccedb72e016114b7f""",
            },
        ],
    },
    {
        "id": 38,
        "title": """Two Layers Deep""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """Every stage here uses one of the platform's core single-layer techniques -- decode each independently.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal38.txt""",
        "hint": """Identify each stage's encoding from its character set and structure, same as the other crypto challenges -- nothing here is double-wrapped, each stage stands alone.""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Identify each stage's encoding from its character set and structure, same as the other crypto challenges -- nothing here is double-wrapped, each stage stands alone.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 3 stages:
  Stage 1: flag{crypto38_s1_reverse_ok}
  Stage 2: flag{crypto38_s2_rot13_ok}
  Stage 3: flag{crypto38_s3_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 33,
                "flag_hash": """71d490393d747d6db574a034b813deb99437e927d12ed1e7a6b1f8913fba32eb""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 33,
                "flag_hash": """cfa5e10e81b781417486c99e2073abd29b9625116ec4cbb88dd595097237f04d""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 34,
                "flag_hash": """fc36dedb34fa23c8fc0ceb561d3544e68b45bcd87e361170451e0a9bc29659c1""",
            },
        ],
    },
    {
        "id": 39,
        "title": """Triple Wrap""",
        "category": """Cryptography""",
        "difficulty": """Hard""",
        "points": 140,
        "hint_cost": 21,
        "description": """Five independently-encoded stages, each a different classic cipher -- this is the hardest crypto binary on the platform.

Download the file -- it has 5 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal39.txt""",
        "hint": """Hard tier: five distinct stages, five distinct techniques. Take them one at a time; none depend on each other.""",
        "writeup": """Category: Cryptography | Difficulty: Hard | 5 stages

Approach that solves this challenge:
Hard tier: five distinct stages, five distinct techniques. Take them one at a time; none depend on each other.

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 5 stages:
  Stage 1: flag{crypto39_s1_rot13_ok}
  Stage 2: flag{crypto39_s2_caesar_ok}
  Stage 3: flag{crypto39_s3_substitution_ok}
  Stage 4: flag{crypto39_s4_vigenere_ok}
  Stage 5: flag{crypto39_s5_bitrotate_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 28,
                "flag_hash": """a4553e4c8fcbebd94ac458942ba4ef384cdee4ff35730b1ee37d7f1b5232882a""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 28,
                "flag_hash": """528aeb5991c684350af81f9dd2813fdda138696a177e24ed80410dd6efdca694""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 28,
                "flag_hash": """e81e98001b9cbc40f191e8ccf646999775d8b7166cf8f7e96cf5095cbac94ab1""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4""",
                "points": 28,
                "flag_hash": """75d820f7970218aa8f9e6b3ebcdf592a28ee0a9ae02d713a1415f5dd728bc5b1""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5""",
                "points": 28,
                "flag_hash": """8affba105b18c18eb61125576b78127a93ff5f08619d19b59292edf3886e1506""",
            },
        ],
    },
    {
        "id": 40,
        "title": """Raw Bytes""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 70,
        "hint_cost": 10,
        "description": """A set of encoded notes -- work out each stage's technique from its ciphertext shape.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal40.txt""",
        "hint": """If a stage's ciphertext is all hex digits in pairs, decode the hex first, then look at what's left (it may itself be XORed or bit-rotated bytes).""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
If a stage's ciphertext is all hex digits in pairs, decode the hex first, then look at what's left (it may itself be XORed or bit-rotated bytes).

Each stage uses a different classic cipher/encoding. Identifying the technique from the ciphertext's shape (character set, structure) is half the battle; the other half is applying the right known-plaintext crib ('flag{' is a very strong one).

This challenge had 3 stages:
  Stage 1: flag{crypto40_s1_caesar_ok}
  Stage 2: flag{crypto40_s2_substitution_ok}
  Stage 3: flag{crypto40_s3_vigenere_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 23,
                "flag_hash": """06125c42d2af478c9ab2f03f05752433d15f0feeaa39fe89a279712c20ddbd99""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 23,
                "flag_hash": """740689c23cc6e4c1ab33f21730ab02f53bfd945371d188008f3b53363254204f""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 24,
                "flag_hash": """39cc31055a8f2c560c67feb494851a52f827462c09c4078303c42ffdc581b0ec""",
            },
        ],
    },
    {
        "id": 41,
        "title": """Needle in the Binary""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """A small set of mystery files -- no extensions, no hints from the filename.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal41.zip""",
        "hint": """`file partN` first, always -- it tells you what you're actually dealing with regardless of the (missing) name. `strings` finds readable text hiding in binary noise.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
`file partN` first, always -- it tells you what you're actually dealing with regardless of the (missing) name. `strings` finds readable text hiding in binary noise.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 2 stages:
  Stage 1: flag{forensics41_s1_strings_in_binary_ok}
  Stage 2: flag{forensics41_s2_password_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 20,
                "flag_hash": """c3d2f9212ea421bae62487f6da950c1ed4550350c7badb708d81accc17565366""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 20,
                "flag_hash": """d7b41bb021b02081ca7a4931dc60c28c8f1a940a160137672dce70841c3922ff""",
            },
        ],
    },
    {
        "id": 42,
        "title": """Past the End""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """Some of these files look like they end cleanly. Don't trust that.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal42.zip""",
        "hint": """Open raw bytes (cat -A, hexdump, or just `strings`) -- content appended after a file's apparent natural end is still there.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Open raw bytes (cat -A, hexdump, or just `strings`) -- content appended after a file's apparent natural end is still there.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 2 stages:
  Stage 1: flag{forensics42_s1_strings_in_binary_ok}
  Stage 2: flag{forensics42_s2_past_eof_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 20,
                "flag_hash": """eb77809cd74f3f9f1ebae3c5a0f42bfcab89b65f6b08edfaf6297b1b53db522f""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 20,
                "flag_hash": """1a21560890131b93be1b881ccb202693c316e157e3973e12f1abc0932231d864""",
            },
        ],
    },
    {
        "id": 43,
        "title": """Backwards File""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 30,
        "hint_cost": 5,
        "description": """Simple-looking parts that might not be what they seem once reversed.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal43.zip""",
        "hint": """`rev` reverses each line on Linux, or just do text[::-1] in Python once you know a part is plain reversed text.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
`rev` reverses each line on Linux, or just do text[::-1] in Python once you know a part is plain reversed text.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 2 stages:
  Stage 1: flag{forensics43_s1_past_eof_ok}
  Stage 2: flag{forensics43_s2_reversed_text_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 15,
                "flag_hash": """498ac37525aa94e93fb4621ca711cf4704b637649feedf832afcc126cf8e2d94""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 15,
                "flag_hash": """f04c1bc9d8dd1311ac03125198eed1cfd4fed0517fcace24ad7a91f7401f3d31""",
            },
        ],
    },
    {
        "id": 44,
        "title": """Not Actually a Text File""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """None of the parts have extensions -- the whole point is you can't assume anything.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal44.zip""",
        "hint": """Run `file partN` on every part before opening anything in a text editor.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Run `file partN` on every part before opening anything in a text editor.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 2 stages:
  Stage 1: flag{forensics44_s1_reversed_text_ok}
  Stage 2: flag{forensics44_s2_grep_noise_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 22,
                "flag_hash": """1aa250cfce4926b0faf8a42f4e68db2b96443c3e82541c32a25491f31747d309""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 23,
                "flag_hash": """e83d11435ab5f11f36a8fc49f5933cad8ef27c64ee13253376444e6d951b4d37""",
            },
        ],
    },
    {
        "id": 45,
        "title": """Matryoshka Archive""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 70,
        "hint_cost": 10,
        "description": """Some parts are archives inside archives. Keep extracting until there's nothing left to extract.

Download the zip and extract it -- it has 3 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal45.zip""",
        "hint": """`unzip partN` (you may need to rename/copy it with a .zip extension first since it has none), then unzip whatever comes out, and repeat.""",
        "writeup": """Category: Forensics | Difficulty: Medium | 3 stages

Approach that solves this challenge:
`unzip partN` (you may need to rename/copy it with a .zip extension first since it has none), then unzip whatever comes out, and repeat.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 3 stages:
  Stage 1: flag{forensics45_s1_grep_noise_ok}
  Stage 2: flag{forensics45_s2_hexdump_ok}
  Stage 3: flag{forensics45_s3_nested_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 23,
                "flag_hash": """fd152276fbe5e4a82c0264976e126f10bcf915732343cfeda1fd8e03db615e75""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 23,
                "flag_hash": """4b2e5306869960bc160130172ea311917336101eb163dfffbbc386f04567e4db""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (part3)""",
                "points": 24,
                "flag_hash": """0c7fb879602c294986fd3cfce63894983950a7ebe23175ce4f68f7fe5309e25a""",
            },
        ],
    },
    {
        "id": 46,
        "title": """Weak Password Zip""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 65,
        "hint_cost": 10,
        "description": """Some parts are password-protected archives with short, weak, reused passwords.

Download the zip and extract it -- it has 3 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal46.zip""",
        "hint": """Try `zip2john partN > hash.txt && john hash.txt`, or just guess common offline-CTF-style passwords by hand with `unzip -P <guess> partN`.""",
        "writeup": """Category: Forensics | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Try `zip2john partN > hash.txt && john hash.txt`, or just guess common offline-CTF-style passwords by hand with `unzip -P <guess> partN`.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 3 stages:
  Stage 1: flag{forensics46_s1_hexdump_ok}
  Stage 2: flag{forensics46_s2_nested_zip_ok}
  Stage 3: flag{forensics46_s3_password_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 21,
                "flag_hash": """472c74298c378daf4ac0600101c08674904122bdff2e851b48ab94257ea3e74e""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 21,
                "flag_hash": """b453abe7f4cb613a59ba4a44287295f7780dc86938307f12ccb5335a2ff7e753""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (part3)""",
                "points": 23,
                "flag_hash": """c42e465ea3d97ca760ed5d1e47e085f6faf9b858b9b79aecaad80d7257cd9a87""",
            },
        ],
    },
    {
        "id": 47,
        "title": """Haystack Log""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """Some parts are noisy text where the flag is one line among many near-identical ones.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal47.zip""",
        "hint": """`grep flag partN` or `grep -i flag partN` instantly finds the one different line.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
`grep flag partN` or `grep -i flag partN` instantly finds the one different line.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 2 stages:
  Stage 1: flag{forensics47_s1_nested_zip_ok}
  Stage 2: flag{forensics47_s2_password_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 22,
                "flag_hash": """07f4ab7fa10a1ad3fad857791d9e9baa94a35e7a20a3bdd32af2b9060007b68a""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 23,
                "flag_hash": """8b1e718441776cdc850adaa2db78ded9de40ca4d16bde72c15fad1415fdcdc6e""",
            },
        ],
    },
    {
        "id": 48,
        "title": """Hexdump Reconstruction""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 60,
        "hint_cost": 9,
        "description": """Some parts are hex dumps (offset, hex bytes, ASCII preview) you need to reconstruct by hand.

Download the zip and extract it -- it has 3 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal48.zip""",
        "hint": """The ASCII column already shows most of it; convert any '.' bytes from their hex pairs to be exact.""",
        "writeup": """Category: Forensics | Difficulty: Medium | 3 stages

Approach that solves this challenge:
The ASCII column already shows most of it; convert any '.' bytes from their hex pairs to be exact.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 3 stages:
  Stage 1: flag{forensics48_s1_strings_in_binary_ok}
  Stage 2: flag{forensics48_s2_past_eof_ok}
  Stage 3: flag{forensics48_s3_password_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 20,
                "flag_hash": """507600d4826b8637e06608bdaf9fd4e991033561496b4becb0481d32386e6d93""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 20,
                "flag_hash": """45b1ea60aca9c3d7d28c4ac3eb3938fcc6cf4672b959fa497b34009ad5bafc28""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (part3)""",
                "points": 20,
                "flag_hash": """c19fda943f195a483373ade0943c94b59eac8c442e7bbf4a77a9c401056da694""",
            },
        ],
    },
    {
        "id": 49,
        "title": """Binary Noise""",
        "category": """Forensics""",
        "difficulty": """Medium""",
        "points": 55,
        "hint_cost": 8,
        "description": """Some parts are mostly random binary noise with a marker-wrapped flag buried inside.

Download the zip and extract it -- it has 3 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal49.zip""",
        "hint": """`grep -a flag partN` forces grep to treat a binary-looking file as text, or `strings partN | grep flag`.""",
        "writeup": """Category: Forensics | Difficulty: Medium | 3 stages

Approach that solves this challenge:
`grep -a flag partN` forces grep to treat a binary-looking file as text, or `strings partN | grep flag`.

Each part in the archive needs a different forensics technique -- `file` first, always, then strings/grep, checking past EOF, unzipping (sometimes more than once), or cracking a weak zip password.

This challenge had 3 stages:
  Stage 1: flag{forensics49_s1_strings_in_binary_ok}
  Stage 2: flag{forensics49_s2_past_eof_ok}
  Stage 3: flag{forensics49_s3_reversed_text_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 18,
                "flag_hash": """32ac52cc79f3ec8ba52c9d9afd0039ee8b9051e04d011af438fe45a4c1420ee2""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 18,
                "flag_hash": """522247bbbe37ab8f66b6e8c4eb1d8080fc6d820f370f4e5b2b1e4b04b71993a5""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (part3)""",
                "points": 19,
                "flag_hash": """75f5a69e2bc03cfe66422ce342952202d6e1ec6206b89449b19182be26b51ee2""",
            },
        ],
    },
    {
        "id": 50,
        "title": """The Full Chain""",
        "category": """Forensics""",
        "difficulty": """Hard""",
        "points": 120,
        "hint_cost": 18,
        "description": """The hardest forensics archive -- five parts, five different techniques, no shortcuts.

Download the zip and extract it -- it has 5 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal50.zip""",
        "hint": """Hard tier: this one has all five forensics techniques used across the platform in a single archive. Work through part1..part5 one at a time.""",
        "writeup": """Category: Forensics | Difficulty: Hard | 5 stages

Approach that solves this challenge:
Hard tier: this one has all five forensics techniques used across the platform in a single archive. Work through part1..part5 one at a time.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 5 stages:
  Stage 1: flag{forensics50_s1_past_eof_ok}
  Stage 2: flag{forensics50_s2_reversed_text_ok}
  Stage 3: flag{forensics50_s3_grep_noise_ok}
  Stage 4: flag{forensics50_s4_hexdump_ok}
  Stage 5: flag{forensics50_s5_nested_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 24,
                "flag_hash": """c8c5f3fd24969dab6ecc898a143fec81fe123200ecee76aff3686c2667b3d006""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 24,
                "flag_hash": """e1d476d865a94f45ced902423b4101281ae3b30b95d1636293da2522cc613a4e""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (part3)""",
                "points": 24,
                "flag_hash": """2ac9a81fceb7628226c1c06479e0144cfff2f804443196b28915c6db60a64ef5""",
            },
            {
                "stage_index": 4,
                "label": """Stage 4 (part4)""",
                "points": 24,
                "flag_hash": """02c761088a6e7ef006b2c133bef67b53b07c7bfcc3ab6da171e83fccc4ca18ee""",
            },
            {
                "stage_index": 5,
                "label": """Stage 5 (part5)""",
                "points": 24,
                "flag_hash": """b165cf592a1788277bcc7d7d026ee36d9b621d9cb6beb35b850a8ae7eb2c3f37""",
            },
        ],
    },
    {
        "id": 51,
        "title": """Chain Gate I: The Easy Door""",
        "category": """Reverse Engineering""",
        "difficulty": """Easy""",
        "points": 50,
        "hint_cost": 8,
        "description": """A gate built specifically to make you carry a finding from one stage into the next mindset -- in practice it's the same multi-stage transform gauntlet as the rest of RE.

This binary has 2 stages. Run it as:
    ./chal51 <stage_number 1-2> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal51""",
        "hint": """Same five-technique family as every RE binary: reverse/xor/caesar/bit-rotate/substitution, chained.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Same five-technique family as every RE binary: reverse/xor/caesar/bit-rotate/substitution, chained.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 2 stages:
  Stage 1: flag{re51_s1_xor_ok}
  Stage 2: flag{re51_s2_caesar_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (xor)""",
                "points": 25,
                "flag_hash": """d4021524cb4988c7c0f666a32313fdcb0e8114890b9dab4bdc899cf41970db2b""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (caesar)""",
                "points": 25,
                "flag_hash": """dc39b5b5db06d071e67fa8848abdad1ce58abb512f9945ce1858837ca4e9655a""",
            },
        ],
    },
    {
        "id": 52,
        "title": """Chain Gate II: Going Deeper""",
        "category": """Reverse Engineering""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """The harder sibling of Chain Gate I -- more stages, same chaining mindset.

This binary has 3 stages. Run it as:
    ./chal52 <stage_number 1-3> <your_answer>

Each stage hides its own secret with a DIFFERENT reversible byte transform (reverse / xor / caesar-shift / bit-rotate / substitution). None of them are stored as plain text anywhere in the file -- decompile the stage's decode loop, work out the transform, and reconstruct the secret. Whatever string makes a stage print 'Correct' IS that stage's flag -- submit it on the web page for that stage.""",
        "filename": """chal52""",
        "hint": """Three distinct decode techniques stacked in one binary -- work them stage by stage.""",
        "writeup": """Category: Reverse Engineering | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Three distinct decode techniques stacked in one binary -- work them stage by stage.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 3 stages:
  Stage 1: flag{re52_s1_caesar_ok}
  Stage 2: flag{re52_s2_rotbits_ok}
  Stage 3: flag{re52_s3_substitution_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (caesar)""",
                "points": 33,
                "flag_hash": """5029bc7cea7becd2ae25a5fe44b0fd6a7450008c3eb3e6da8944c133d27a393c""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (rotbits)""",
                "points": 33,
                "flag_hash": """6620468b66c77c66cfabb2e75f0f75526d969d6c959d256027ed90d6901b4088""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (substitution)""",
                "points": 34,
                "flag_hash": """dac17ec17915d82247af46f83c3157f0054bde2ec19e0db3e2a6fd98f82bff20""",
            },
        ],
    },
    {
        "id": 53,
        "title": """Chain Cipher I: The Key Inside""",
        "category": """Cryptography""",
        "difficulty": """Easy""",
        "points": 45,
        "hint_cost": 7,
        "description": """A set of notes built around the idea that one clue leads to the next -- in practice, independent classic-cipher stages like the rest of the Crypto category.

Download the file -- it has 2 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal53.txt""",
        "hint": """Identify each stage's encoding from its character set, same approach as every other crypto challenge.""",
        "writeup": """Category: Cryptography | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Identify each stage's encoding from its character set, same approach as every other crypto challenge.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 2 stages:
  Stage 1: flag{crypto53_s1_base64_ok}
  Stage 2: flag{crypto53_s2_xor_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 22,
                "flag_hash": """f0987809a6f9b796fe100def63a1aacdff0594676c1497de030df78870636783""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 23,
                "flag_hash": """1fbff2cfeef743c16785c071dec97aebf16c40167779499fe015006be04d7351""",
            },
        ],
    },
    {
        "id": 54,
        "title": """Chain Cipher II: Using the Clue""",
        "category": """Cryptography""",
        "difficulty": """Medium""",
        "points": 90,
        "hint_cost": 14,
        "description": """The harder sibling of Chain Cipher I.

Download the file -- it has 3 independently-encoded stages, each a different classic cipher/encoding. Decode each one for its own flag.""",
        "filename": """chal54.txt""",
        "hint": """Three stages, three techniques -- work through them one at a time.""",
        "writeup": """Category: Cryptography | Difficulty: Medium | 3 stages

Approach that solves this challenge:
Three stages, three techniques -- work through them one at a time.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 3 stages:
  Stage 1: flag{crypto54_s1_base64_ok}
  Stage 2: flag{crypto54_s2_hex_ok}
  Stage 3: flag{crypto54_s3_reverse_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1""",
                "points": 30,
                "flag_hash": """c6283331908fd16185f0e0a5a6b0cd3c8c7ea94f5743a85125d772f5d2f78901""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2""",
                "points": 30,
                "flag_hash": """af740fdfbd105f0c43e3ba8b01794193ec2c7ac1df09551e4967d87cfd6fa405""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3""",
                "points": 30,
                "flag_hash": """cac91cc10c7ee48041f7219e405f8d4ff5f0513338d8e6426bd862cb790d32e5""",
            },
        ],
    },
    {
        "id": 55,
        "title": """Chain Box I: The Outer Box""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 40,
        "hint_cost": 6,
        "description": """An archive built around the idea of carrying one discovery into the next step -- in practice, independent forensics-technique parts like the rest of the Forensics category.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal55.zip""",
        "hint": """`file` every part first, then apply whichever technique it actually needs.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
`file` every part first, then apply whichever technique it actually needs.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 2 stages:
  Stage 1: flag{forensics55_s1_strings_in_binary_ok}
  Stage 2: flag{forensics55_s2_password_zip_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 20,
                "flag_hash": """3112a50365793d239512ce2d0ed4674383e6aaee4d979adc6d249fd8eacc6fdb""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 20,
                "flag_hash": """e4c47800c5119e759c944b0d83047a3f9304368a7eb6a65446707dc86c56dc0d""",
            },
        ],
    },
    {
        "id": 56,
        "title": """Chain Box II: The Inner Vault""",
        "category": """Forensics""",
        "difficulty": """Easy""",
        "points": 55,
        "hint_cost": 8,
        "description": """The harder sibling of Chain Box I.

Download the zip and extract it -- it has 2 extensionless parts, each needing a different forensics technique to recover its own flag.""",
        "filename": """chal56.zip""",
        "hint": """Same forensics technique pool as the rest of the platform, just two parts this time.""",
        "writeup": """Category: Forensics | Difficulty: Easy | 2 stages

Approach that solves this challenge:
Same forensics technique pool as the rest of the platform, just two parts this time.

This is deliberate multi-stage practice: a real vulnerability research engagement rarely ends at one finding. Training yourself to work through several distinct techniques inside one artifact, rather than stopping at the first one, is exactly the muscle real zero-day hunting needs.

This challenge had 2 stages:
  Stage 1: flag{forensics56_s1_strings_in_binary_ok}
  Stage 2: flag{forensics56_s2_past_eof_ok}""",
        "is_network": 0,
        "port": 0,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (part1)""",
                "points": 27,
                "flag_hash": """a00762f3f0c96e1cac68ed1c88f024e62e379fa175898ef917dd3f511f16a255""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (part2)""",
                "points": 28,
                "flag_hash": """d8c1ca1ea378d84ca3d9d39ec382e88f10f432ea431ebc50aae5bb21670d81d5""",
            },
        ],
    },
    {
        "id": 57,
        "title": """Remote Access Gate""",
        "category": """Network""",
        "difficulty": """Easy""",
        "points": 60,
        "hint_cost": 9,
        "description": """This is NOT a file to download -- it's a live service. Connect with:

    nc 127.0.0.1 9101

It first asks which stage (1 or 2), then asks for that stage's access code. Each stage hides its password via a different reversible byte transform (same transform family used across the RE challenges). The exact same binary is also sitting in challenges/net57 for offline static analysis -- decompile it to work out each stage's transform and password, then connect and answer each stage's prompt.""",
        "filename": """net57""",
        "hint": """The binary at challenges/net57 is the exact same program the live service runs. Decompile it exactly like an RE challenge -- two stages, two different transforms, neither password stored as plain text anywhere in the file.""",
        "writeup": """Category: Network | Difficulty: Easy | 2 stages

Approach that solves this challenge:
The binary at challenges/net57 is the exact same program the live service runs. Decompile it exactly like an RE challenge -- two stages, two different transforms, neither password stored as plain text anywhere in the file.

This is exactly how real remote CTF infrastructure works: a vulnerable program's stdin/stdout piped straight to a TCP socket. Everything you know about exploiting a local binary transfers directly -- you just send your input over the wire.

This challenge had 2 stages:
  Stage 1: flag{net57_s1_caesar_ok}
  Stage 2: flag{net57_s2_rotbits_ok}""",
        "is_network": 1,
        "port": 9101,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (caesar)""",
                "points": 30,
                "flag_hash": """698c07b7b23a49ee7d27ad55b0858e72a995d34a059159c71402fc8a9f3bd622""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (rotbits)""",
                "points": 30,
                "flag_hash": """99454c3a67c7855bae1d370460033869142a55ee2e5e033e4bb4f2582eb8937c""",
            },
        ],
    },
    {
        "id": 58,
        "title": """Remote Overflow""",
        "category": """Network""",
        "difficulty": """Medium""",
        "points": 100,
        "hint_cost": 15,
        "description": """Another live service, no file to download:

    nc 127.0.0.1 9102

The exact same unbounded scanf() stack-overflow pattern as the local 'Overflow' pwn challenges -- 3 staged integer variables at increasing stack depth. Send your overflow payload over the socket instead of piping to a local binary; feed it progressively longer input and watch which stage messages (and flags) appear.""",
        "filename": """net58""",
        "hint": """python3 -c "print('A'*N)" | nc 127.0.0.1 9102 for increasing N (try 50-100) -- each stage prints its flag directly once you've overflowed far enough to reach it.""",
        "writeup": """Category: Network | Difficulty: Medium | 3 stages

Approach that solves this challenge:
python3 -c "print('A'*N)" | nc 127.0.0.1 9102 for increasing N (try 50-100) -- each stage prints its flag directly once you've overflowed far enough to reach it.

This is exactly how real remote CTF infrastructure works: a vulnerable program's stdin/stdout piped straight to a TCP socket. Everything you know about exploiting a local binary transfers directly -- you just send your input over the wire.

This challenge had 3 stages:
  Stage 1: flag{net58_s1_overwrite_ok}
  Stage 2: flag{net58_s2_overwrite_ok}
  Stage 3: flag{net58_s3_overwrite_ok}""",
        "is_network": 1,
        "port": 9102,
        "stages": [
            {
                "stage_index": 1,
                "label": """Stage 1 (overwrite is_admin)""",
                "points": 33,
                "flag_hash": """7148eb526ec2956d58848b64d35924535433d9d501b8dca01b91db8683cfb56a""",
            },
            {
                "stage_index": 2,
                "label": """Stage 2 (overwrite is_root)""",
                "points": 33,
                "flag_hash": """0875000475c1bc97f183eb64858a0b1a13eacfd8ad4b13f2955e92771fae492c""",
            },
            {
                "stage_index": 3,
                "label": """Stage 3 (overwrite god_mode)""",
                "points": 34,
                "flag_hash": """27834e39f7a3ac08bc50902b422bd0d980ec1745e4c22fe2701d688815bcbcdb""",
            },
        ],
    },
]

def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS challenges (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            difficulty TEXT NOT NULL,
            points INTEGER NOT NULL,
            hint_cost INTEGER NOT NULL DEFAULT 0,
            description TEXT NOT NULL,
            filename TEXT NOT NULL,
            hint TEXT,
            writeup TEXT,
            is_network INTEGER NOT NULL DEFAULT 0,
            port INTEGER NOT NULL DEFAULT 0,
            stage_count INTEGER NOT NULL DEFAULT 1
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS subflags (
            challenge_id INTEGER NOT NULL,
            stage_index INTEGER NOT NULL,
            label TEXT NOT NULL,
            points INTEGER NOT NULL,
            flag_hash TEXT NOT NULL,
            PRIMARY KEY (challenge_id, stage_index)
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS stage_solves (
            challenge_id INTEGER NOT NULL,
            stage_index INTEGER NOT NULL,
            solved_at TEXT NOT NULL,
            PRIMARY KEY (challenge_id, stage_index)
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS hints_used (
            challenge_id INTEGER PRIMARY KEY,
            used_at TEXT NOT NULL
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS views (
            challenge_id INTEGER PRIMARY KEY,
            first_viewed_at TEXT NOT NULL
        )
    ''')
    for c in CHALLENGES:
        cur.execute('''
            INSERT INTO challenges
                (id, title, category, difficulty, points, hint_cost, description, filename,
                 hint, writeup, is_network, port, stage_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title=excluded.title, category=excluded.category, difficulty=excluded.difficulty,
                points=excluded.points, hint_cost=excluded.hint_cost, description=excluded.description,
                filename=excluded.filename, hint=excluded.hint, writeup=excluded.writeup,
                is_network=excluded.is_network, port=excluded.port, stage_count=excluded.stage_count
        ''', (c["id"], c["title"], c["category"], c["difficulty"], c["points"], c["hint_cost"],
              c["description"], c["filename"], c["hint"], c["writeup"], c["is_network"], c["port"],
              len(c["stages"])))
        for st in c["stages"]:
            cur.execute('''
                INSERT INTO subflags (challenge_id, stage_index, label, points, flag_hash)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(challenge_id, stage_index) DO UPDATE SET
                    label=excluded.label, points=excluded.points, flag_hash=excluded.flag_hash
            ''', (c["id"], st["stage_index"], st["label"], st["points"], st["flag_hash"]))
    conn.commit()
    conn.close()
    print(f"Seeded {len(CHALLENGES)} challenges (with sub-flag stages) into {DB_PATH}")

if __name__ == "__main__":
    main()
