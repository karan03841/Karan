PortableCTF v2 — one-command launcher for your Kali laptop
=============================================================

This creates a single "ctf" command on your KALI LAPTOP (not the pendrive)
so you never have to type the mount/cd/run sequence again.

It relies on the ext4 filesystem label "CTFDRIVE" you already set when you
ran:   sudo mkfs.ext4 -L CTFDRIVE /dev/sda1
That label stays the same even if the pendrive shows up as /dev/sdb or
/dev/sdc next time (USB port/letter can change — the label never does).

ONE-TIME SETUP on Kali:
------------------------
1. Create the launcher script:

   mkdir -p ~/bin
   cat > ~/bin/ctf << 'EOF'
   #!/usr/bin/env bash
   set -e
   MOUNT=/mnt/pendrive
   sudo mkdir -p "$MOUNT"
   if ! mountpoint -q "$MOUNT"; then
       sudo mount /dev/disk/by-label/CTFDRIVE "$MOUNT"
   fi
   cd "$MOUNT/PortableCTF"
   ./start_ctf.sh
   EOF
   chmod +x ~/bin/ctf

2. Make sure ~/bin is on your PATH (usually already is on Kali; if not):

   echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
   source ~/.bashrc

EVERY TIME YOU WANT TO USE IT:
-------------------------------
1. Plug in the pendrive.
2. Open a terminal and just type:

       ctf

   That's it. It mounts the drive (asks for your sudo password once),
   cd's into the right folder, and runs start_ctf.sh — which starts both
   the network challenge services (nc 127.0.0.1 9101 / 9102) and the web
   app automatically.
3. Open http://127.0.0.1:5000 in your browser.
4. When you're done, Ctrl+C in that terminal to stop everything cleanly
   (it will also shut down the two network services), then:

       sudo umount /mnt/pendrive

   ...and you can safely unplug the pendrive.

If "ctf" ever says it can't find /dev/disk/by-label/CTFDRIVE, run `lsblk -f`
to confirm the pendrive's partition still carries that label.
